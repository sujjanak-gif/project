<?php
// api/update_booking.php
// ให้ผู้ใช้แก้ไขรายการจองของตัวเอง ได้เฉพาะรายการที่ยัง "pending" และยังไม่ถึงเวลาเริ่ม
header('Content-Type: application/json; charset=utf-8');
if (session_status() == PHP_SESSION_NONE) { session_start(); }
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';

function respond($success, $message, $extra = []) {
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

if (!is_logged_in()) { respond(false, 'กรุณาเข้าสู่ระบบ'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { respond(false, 'Invalid request method.'); }
if (!csrf_verify($_POST['csrf_token'] ?? null)) {
    respond(false, 'เซสชันหมดอายุหรือคำขอไม่ถูกต้อง กรุณารีเฟรชหน้าแล้วลองใหม่');
}

// --- รับค่า (ไม่รับ user_id จากฟอร์ม ใช้จาก session เท่านั้น) ---
$my_id           = (int)$_SESSION['user_id'];
$booking_id      = (int)($_POST['id'] ?? 0);
$room_id         = (int)($_POST['room_id'] ?? 0);
$title           = trim($_POST['title'] ?? '');
$instructor_name = trim($_POST['instructor_name'] ?? '');
$contact_person  = trim($_POST['contact_person'] ?? '');
$contact_phone   = trim($_POST['contact_phone'] ?? '');
$doc_number      = trim($_POST['doc_number'] ?? '');
$description     = trim($_POST['description'] ?? '');
$student_raw     = trim($_POST['student_count'] ?? '');
$date_str        = trim($_POST['booking_date'] ?? '');
$start_str       = trim($_POST['start_time_only'] ?? '');
$end_str         = trim($_POST['end_time_only'] ?? '');

$doc_number  = ($doc_number === '') ? null : $doc_number;
$description = ($description === '') ? null : $description;

// --- Validation ---
if ($booking_id <= 0 || $room_id <= 0 || $title === '' || $instructor_name === ''
    || $contact_person === '' || $contact_phone === '' || $date_str === '' || $start_str === '' || $end_str === '') {
    respond(false, 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน');
}
if (mb_strlen($title) > 255 || mb_strlen($instructor_name) > 255 || mb_strlen($contact_person) > 255
    || mb_strlen($contact_phone) > 50 || ($doc_number !== null && mb_strlen($doc_number) > 100)) {
    respond(false, 'ข้อมูลยาวเกินกำหนด กรุณาตรวจสอบอีกครั้ง');
}

$student_count = null;
if ($student_raw !== '') {
    if (!ctype_digit($student_raw) || (int)$student_raw > 100000) {
        respond(false, 'จำนวนนักศึกษาไม่ถูกต้อง');
    }
    $student_count = (int)$student_raw;
}

if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $start_str) || !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $end_str)) {
    respond(false, 'รูปแบบเวลาไม่ถูกต้อง');
}
$start_hm = substr($start_str, 0, 5);
$end_hm   = substr($end_str, 0, 5);
$start = DateTime::createFromFormat('Y-m-d H:i', "$date_str $start_hm");
$end   = DateTime::createFromFormat('Y-m-d H:i', "$date_str $end_hm");
if (!$start || !$end || $start->format('Y-m-d H:i') !== "$date_str $start_hm" || $end->format('Y-m-d H:i') !== "$date_str $end_hm") {
    respond(false, 'รูปแบบวันที่หรือเวลาไม่ถูกต้อง');
}
if ($end <= $start) {
    respond(false, 'เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น');
}

$now      = new DateTime('now');
$is_staff = can_manage_bookings();
$start_sql = $start->format('Y-m-d H:i:s');
$end_sql   = $end->format('Y-m-d H:i:s');

try {
    $pdo->beginTransaction();

    // ล็อกแถวที่จะแก้ไข กันการอนุมัติ/แก้ไขซ้อนกัน
    $stmt = $pdo->prepare("SELECT id, user_id, status, is_deleted, start_time FROM bookings WHERE id = ? FOR UPDATE");
    $stmt->execute([$booking_id]);
    $booking = $stmt->fetch();

    if (!$booking || $booking['is_deleted'] || (int)$booking['user_id'] !== $my_id) {
        $pdo->rollBack();
        respond(false, 'คุณไม่มีสิทธิ์แก้ไขรายการนี้');
    }
    if ($booking['status'] !== 'pending') {
        $pdo->rollBack();
        respond(false, 'แก้ไขได้เฉพาะรายการที่ยังรออนุมัติเท่านั้น');
    }

    $old_start = new DateTime($booking['start_time']);
    if ($old_start <= $now) {
        $pdo->rollBack();
        respond(false, 'ไม่สามารถแก้ไขรายการที่ถึงหรือเลยเวลาเริ่มไปแล้ว');
    }
    if ($start <= $now) {
        $pdo->rollBack();
        respond(false, 'ไม่สามารถเลือกเวลาที่ผ่านมาแล้ว');
    }

    // กติกาจองล่วงหน้า 7 วัน (ผู้ใช้ทั่วไป) บังคับเมื่อมีการเปลี่ยนวัน/เวลา
    if (!$is_staff && $start_sql !== $old_start->format('Y-m-d H:i:s')) {
        $min_day   = new DateTime('today');
        $min_day->modify('+7 days');
        $start_day = (clone $start)->setTime(0, 0, 0);
        if ($start_day < $min_day) {
            $pdo->rollBack();
            respond(false, 'ผู้ใช้งานทั่วไปต้องจองล่วงหน้าอย่างน้อย 7 วัน');
        }
    }

    // ห้องต้องมีอยู่จริง
    $stmt = $pdo->prepare("SELECT id FROM rooms WHERE id = ?");
    $stmt->execute([$room_id]);
    if (!$stmt->fetch()) {
        $pdo->rollBack();
        respond(false, 'ไม่พบห้องที่เลือก');
    }

    // ตรวจเวลาทับกับรายการที่อนุมัติแล้ว (ไม่นับรายการของตัวเอง)
    $stmt = $pdo->prepare(
        "SELECT id FROM bookings
         WHERE room_id = ? AND id <> ? AND status = 'approved' AND is_deleted = 0
           AND ? < end_time AND ? > start_time
         LIMIT 1 FOR UPDATE"
    );
    $stmt->execute([$room_id, $booking_id, $start_sql, $end_sql]);
    if ($stmt->fetch()) {
        $pdo->rollBack();
        respond(false, 'ขออภัย ช่วงเวลาที่ท่านเลือกมีผู้จองแล้ว');
    }

    $stmt = $pdo->prepare(
        "UPDATE bookings
         SET room_id = ?, title = ?, contact_person = ?, contact_phone = ?,
             start_time = ?, end_time = ?, description = ?, instructor_name = ?,
             student_count = ?, doc_number = ?
         WHERE id = ? AND user_id = ? AND status = 'pending' AND is_deleted = 0"
    );
    $stmt->execute([
        $room_id, $title, $contact_person, $contact_phone,
        $start_sql, $end_sql, $description, $instructor_name,
        $student_count, $doc_number,
        $booking_id, $my_id
    ]);

    $pdo->commit();
    respond(true, 'บันทึกการแก้ไขเรียบร้อยแล้ว');

} catch (PDOException $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    error_log('update_booking error: ' . $e->getMessage());
    respond(false, 'เกิดข้อผิดพลาดในการบันทึกข้อมูล กรุณาลองใหม่อีกครั้ง');
}

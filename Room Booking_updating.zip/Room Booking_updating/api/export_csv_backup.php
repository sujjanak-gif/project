<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db.php';
include_once '../includes/functions.php';

if (!is_admin()) { die("Permission Denied."); }

$filename = "teaching_report_" . date('Y-m-d') . ".csv";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');
fputs($output, "\xEF\xBB\xBF"); // เพิ่ม BOM สำหรับ UTF-8 เพื่อให้ Excel เปิดได้ถูกต้อง

// กำหนดหัวข้อคอลัมน์ใน CSV
fputcsv($output, ['ลำดับ', 'เลขที่หนังสือ', 'รายวิชา', 'ห้อง', 'อาจารย์ผู้สอน', 'จำนวน นศ.', 'ช่วงเวลา (รวม)', 'หมายเหตุ']);

// SQL Query เพื่อดึงข้อมูลแบบ Grouped
$sql = "
    SELECT
        (SELECT doc_number FROM teaching_reports WHERE id = MIN(tr.id)) as doc_number,
        b.title as course_code,
        r.name as room_name,
        (SELECT student_count FROM bookings WHERE id = MIN(b.id)) as student_count, -- ดึงจำนวน นศ. จาก booking ID แรกในกลุ่ม
        b.instructor_name,
        MIN(b.start_time) as overall_start_time, -- ช่วงเวลาเริ่มต้นรวม
        MAX(b.end_time) as overall_end_time,     -- ช่วงเวลาสิ้นสุดรวม
        (SELECT remarks FROM teaching_reports WHERE id = MIN(tr.id)) as remarks
    FROM teaching_reports tr
    JOIN bookings b ON tr.booking_id = b.id
    JOIN rooms r ON b.room_id = r.id -- ต้อง Join rooms เพื่อดึงชื่อห้อง
    JOIN users u ON b.user_id = u.id -- ยังคง Join users ไว้เผื่อใช้ในอนาคต (ใน SQL query นี้ไม่ได้ใช้โดยตรง)
    GROUP BY b.title, b.room_id, b.instructor_name
    ORDER BY MIN(tr.id) ASC
";
$stmt = $pdo->query($sql);

$index = 1;
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // จัดรูปแบบวันที่สำหรับคอลัมน์ 'ช่วงเวลา (รวม)'
    $overall_time_range = date('d/m/Y', strtotime($row['overall_start_time'])) . ' - ' . date('d/m/Y', strtotime($row['overall_end_time']));

    $csv_row = [
        $index,
        $row['doc_number'],
        $row['course_code'],
        $row['room_name'], // เพิ่มชื่อห้อง
        $row['instructor_name'],
        $row['student_count'], // ใช้ student_count ที่ดึงมาแบบไม่รวม
        $overall_time_range, // ใช้ช่วงเวลาที่จัดรูปแบบแล้ว
        $row['remarks']
    ];
    fputcsv($output, $csv_row);
    $index++;
}

fclose($output);
exit();
?>
<?php
header('Content-Type: application/json; charset=utf-8');
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db.php';
include_once '../includes/functions.php';

function au_out($success, $message = '') {
    echo json_encode(['success' => $success, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
function au_str($key, $max) {
    $v = isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : '';
    if ((function_exists('mb_strlen') ? mb_strlen($v) : strlen($v)) > $max) { au_out(false, 'ข้อมูลบางช่องยาวเกินกำหนด'); }
    return $v;
}

if (!is_admin()) { au_out(false, 'Permission Denied.'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { au_out(false, 'Invalid request method.'); }

$full_name  = au_str('full_name', 255);
$username   = au_str('username', 50);
$email      = au_str('email', 255);
$department = au_str('department', 255);
$password   = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';
$role       = isset($_POST['role']) && is_string($_POST['role']) ? $_POST['role'] : '';
$status     = isset($_POST['status']) && is_string($_POST['status']) ? $_POST['status'] : '';

if ($full_name === '' || $username === '' || $email === '' || $password === '' || $department === '') {
    au_out(false, 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน');
}
if (!preg_match('/^[\p{L}\p{N}._-]{3,50}$/u', $username)) {
    au_out(false, 'ชื่อผู้ใช้ต้องยาว 3-50 ตัวอักษร ใช้ได้เฉพาะตัวอักษร ตัวเลข จุด ขีดกลาง และขีดล่าง');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { au_out(false, 'รูปแบบอีเมลไม่ถูกต้อง'); }
if (strlen($password) < 8 || strlen($password) > 72) { au_out(false, 'รหัสผ่านต้องยาว 8-72 ตัวอักษร'); }
if (!in_array($role, ['admin', 'officer', 'user'], true)) { au_out(false, 'สิทธิ์ที่เลือกไม่ถูกต้อง'); }
if (!in_array($status, ['approved', 'pending', 'inactive', 'suspended'], true)) { au_out(false, 'สถานะที่เลือกไม่ถูกต้อง'); }

try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) { au_out(false, 'ชื่อผู้ใช้หรืออีเมลนี้มีอยู่ในระบบแล้ว'); }

    $stmt = $pdo->prepare("INSERT INTO users (full_name, username, email, password, department, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$full_name, $username, $email, password_hash($password, PASSWORD_DEFAULT), $department, $role, $status]);
    au_out(true, 'เพิ่มผู้ใช้งานเรียบร้อย');
} catch (PDOException $e) {
    error_log('add_user error: ' . $e->getMessage());
    au_out(false, ($e->getCode() == '23000') ? 'ชื่อผู้ใช้หรืออีเมลนี้มีอยู่ในระบบแล้ว' : 'เกิดข้อผิดพลาดในการบันทึกข้อมูล กรุณาลองใหม่อีกครั้ง');
}
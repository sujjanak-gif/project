<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db.php';
include_once '../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

function sd_out($success, $message = '') {
    echo json_encode(['success' => $success, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit();
}
function sd_str($key, $max) {
    $v = isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : '';
    if ((function_exists('mb_strlen') ? mb_strlen($v) : strlen($v)) > $max) { sd_out(false, 'ข้อมูลบางช่องยาวเกินกำหนด'); }
    return $v;
}

if (!is_admin()) { sd_out(false, 'ไม่อนุญาตให้เข้าถึง'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { sd_out(false, 'คำขอไม่ถูกต้อง'); }

$user_id    = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$full_name  = sd_str('full_name', 255);
$username   = sd_str('username', 50);
$email      = sd_str('email', 255);
$department = sd_str('department', 255);
$role       = isset($_POST['role']) && is_string($_POST['role']) ? $_POST['role'] : '';
$status     = isset($_POST['status']) && is_string($_POST['status']) ? $_POST['status'] : '';
$password   = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';

if ($user_id <= 0 || $full_name === '' || $username === '' || $email === '' || $department === '') {
    sd_out(false, 'ข้อมูลไม่ครบถ้วน');
}
if (!preg_match('/^[\p{L}\p{N}._-]{3,50}$/u', $username)) {
    sd_out(false, 'ชื่อผู้ใช้ต้องยาว 3-50 ตัวอักษร ใช้ได้เฉพาะตัวอักษร ตัวเลข จุด ขีดกลาง และขีดล่าง');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { sd_out(false, 'รูปแบบอีเมลไม่ถูกต้อง'); }
if ($password !== '' && (strlen($password) < 8 || strlen($password) > 72)) { sd_out(false, 'รหัสผ่านใหม่ต้องยาว 8-72 ตัวอักษร'); }

try {
    $cur = $pdo->prepare("SELECT id, role, status FROM users WHERE id = ?");
    $cur->execute([$user_id]);
    $existing = $cur->fetch(PDO::FETCH_ASSOC);
    if (!$existing) { sd_out(false, 'ไม่พบผู้ใช้งานที่จะอัปเดต'); }

    if ($user_id === (int)$_SESSION['user_id']) {
        // บัญชีของตัวเอง: ไม่ให้เปลี่ยนสิทธิ์/สถานะ กันล็อกตัวเองออกจากระบบ
        $role = $existing['role'];
        $status = $existing['status'];
    } else {
        if (!in_array($role, ['admin', 'officer', 'user'], true)) { sd_out(false, 'สิทธิ์ที่เลือกไม่ถูกต้อง'); }
        if (!in_array($status, ['approved', 'pending', 'inactive', 'suspended'], true)) { sd_out(false, 'สถานะที่เลือกไม่ถูกต้อง'); }
    }

    $sql = "UPDATE users SET full_name = ?, username = ?, email = ?, department = ?, role = ?, status = ?";
    $params = [$full_name, $username, $email, $department, $role, $status];
    if ($password !== '') {
        $sql .= ", password = ?";
        $params[] = password_hash($password, PASSWORD_DEFAULT);
    }
    $sql .= " WHERE id = ?";
    $params[] = $user_id;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    sd_out(true, $stmt->rowCount() ? 'อัปเดตข้อมูลผู้ใช้งานสำเร็จ' : 'ไม่มีการเปลี่ยนแปลงข้อมูล');

} catch (PDOException $e) {
    error_log('save_user_details error: ' . $e->getMessage());
    sd_out(false, ($e->getCode() == '23000') ? 'ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้ไปแล้ว' : 'เกิดข้อผิดพลาดในการอัปเดตข้อมูล กรุณาลองใหม่อีกครั้ง');
}
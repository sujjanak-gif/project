<?php
header('Content-Type: application/json; charset=utf-8');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../includes/db.php';
include_once '../includes/functions.php';

function room_json($success, $message = '', array $extra = []) {
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

if (!is_admin()) {
    room_json(false, 'Permission denied');
}

$action = $_POST['action'] ?? null;
if (!$action || !is_string($action)) {
    room_json(false, 'Invalid input');
}

$id    = (int)($_POST['id'] ?? 0);
$name  = trim((string)($_POST['name'] ?? ''));
$color = trim((string)($_POST['color'] ?? ''));

try {
    switch ($action) {
        case 'add':
        case 'edit':
            if ($name === '' || (function_exists('mb_strlen') ? mb_strlen($name) : strlen($name)) > 255) {
                room_json(false, 'กรุณากรอกชื่อห้อง (ไม่เกิน 255 ตัวอักษร)');
            }
            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
                room_json(false, 'รหัสสีไม่ถูกต้อง');
            }
            if ($action === 'edit' && $id <= 0) {
                room_json(false, 'ไม่พบห้องที่ต้องการแก้ไข');
            }

            // ห้ามชื่อซ้ำกับห้องอื่น
            $dup = $pdo->prepare("SELECT id FROM rooms WHERE name = ? AND id <> ? LIMIT 1");
            $dup->execute([$name, $action === 'edit' ? $id : 0]);
            if ($dup->fetch()) {
                room_json(false, 'มีห้องชื่อนี้อยู่แล้ว');
            }

            if ($action === 'add') {
                $stmt = $pdo->prepare("INSERT INTO rooms (name, color) VALUES (?, ?)");
                $stmt->execute([$name, strtolower($color)]);
                room_json(true, 'เพิ่มห้องเรียบร้อย', ['id' => (int)$pdo->lastInsertId()]);
            }

            $stmt = $pdo->prepare("UPDATE rooms SET name = ?, color = ? WHERE id = ?");
            $stmt->execute([$name, strtolower($color), $id]);
            room_json(true, 'แก้ไขข้อมูลห้องเรียบร้อย');
            break;

        case 'delete':
            if ($id <= 0) {
                room_json(false, 'ไม่พบห้องที่ต้องการลบ');
            }
            // ลบได้เฉพาะห้องที่ไม่มีการจองเลย (รวมรายการในประวัติ) เพื่อไม่ให้ข้อมูลเก่าอ้างถึงห้องที่หายไป
            $chk = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE room_id = ?");
            $chk->execute([$id]);
            if ((int)$chk->fetchColumn() > 0) {
                room_json(false, 'ลบห้องไม่ได้ เนื่องจากห้องนี้มีประวัติการจอง');
            }
            $stmt = $pdo->prepare("DELETE FROM rooms WHERE id = ?");
            $stmt->execute([$id]);
            room_json(true, 'ลบห้องเรียบร้อย');
            break;

        default:
            room_json(false, 'Invalid action');
    }
} catch (PDOException $e) {
    error_log('manage_room error: ' . $e->getMessage());
    room_json(false, 'เกิดข้อผิดพลาดในการบันทึกข้อมูล กรุณาลองใหม่อีกครั้ง');
}
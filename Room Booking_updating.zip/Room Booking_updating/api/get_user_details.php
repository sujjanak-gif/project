<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../includes/db.php';
include_once '../includes/functions.php';

header('Content-Type: application/json');

if (!is_admin()) { // ตรวจสอบให้แน่ใจว่าเป็น admin เท่านั้นที่เข้าถึงได้
    echo json_encode(['success' => false, 'message' => 'ไม่อนุญาตให้เข้าถึง']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];

    try {
        $stmt = $pdo->prepare("SELECT id, full_name, username, email, department, role, status FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'message' => 'ไม่พบผู้ใช้งาน']);
        }
    } catch (PDOException $e) {
        error_log("Error fetching user details: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'เกิดข้อผิดพลาดในการดึงข้อมูล กรุณาลองใหม่อีกครั้ง']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'คำขอไม่ถูกต้อง']);
}
?>
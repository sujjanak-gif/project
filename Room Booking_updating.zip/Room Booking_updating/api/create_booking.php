<?php
// api/create_booking.php
// สร้างคำขอจอง (เดี่ยวหรือเกิดซ้ำ) ตรวจกติกาทั้งหมดที่ฝั่งเซิร์ฟเวอร์
header('Content-Type: application/json; charset=utf-8');
if (session_status() == PHP_SESSION_NONE) { session_start(); }
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';

// ข้อความที่ปลอดภัยพอจะแสดงให้ผู้ใช้เห็น (ข้อผิดพลาดอื่นจะถูกบันทึกลง log แทน)
class BookingInputException extends Exception {}

function respond($success, $message, array $extra = []) {
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

const MAX_OCCURRENCES = 120;      // จองซ้ำได้สูงสุดกี่ครั้งต่อคำขอ
const ADVANCE_DAYS_FOR_USER = 7;  // ผู้ใช้ทั่วไปต้องจองล่วงหน้ากี่วัน (ผู้ดูแล/เจ้าหน้าที่ไม่จำกัด)

if (!is_logged_in()) { respond(false, 'กรุณาเข้าสู่ระบบ'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { respond(false, 'Invalid request method.'); }
if (function_exists('csrf_verify') && !csrf_verify($_POST['csrf_token'] ?? null)) {
    respond(false, 'เซสชันหมดอายุหรือคำขอไม่ถูกต้อง กรุณารีเฟรชหน้าแล้วลองใหม่');
}

function post_str($key, $max) {
    $v = isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : '';
    $len = function_exists('mb_strlen') ? mb_strlen($v) : strlen($v);
    if ($len > $max) { throw new BookingInputException('ข้อมูลบางช่องยาวเกินกำหนด กรุณาตรวจสอบอีกครั้ง'); }
    return $v;
}

function parse_dt($str, $label) {
    try { return new DateTime($str); }
    catch (Exception $e) { throw new BookingInputException('รูปแบบ' . $label . 'ไม่ถูกต้อง'); }
}

// ช่วงเวลาของวันที่หนึ่งๆ โดยใช้เวลาเริ่ม/สิ้นสุดจากต้นแบบ
function make_entry(DateTime $day, DateTime $tpl_start, DateTime $tpl_end) {
    $s = (clone $day)->setTime((int)$tpl_start->format('H'), (int)$tpl_start->format('i'), 0);
    $e = (clone $day)->setTime((int)$tpl_end->format('H'), (int)$tpl_end->format('i'), 0);
    return ['start' => $s->format('Y-m-d H:i:s'), 'end' => $e->format('Y-m-d H:i:s')];
}

try {
    // ผู้จองคือผู้ที่ล็อกอินเท่านั้น (ไม่รับ user_id จากฟอร์ม)
    $user_id = (int)$_SESSION['user_id'];
    $room_id = (int)($_POST['room_id'] ?? 0);
    $title = post_str('title', 255);
    $department = isset($_SESSION['user_department']) && $_SESSION['user_department'] !== '' ? (string)$_SESSION['user_department'] : post_str('department', 255);
    $contact_person = post_str('contact_person', 255);
    $contact_phone = post_str('contact_phone', 50);
    $instructor_name = post_str('instructor_name', 255);
    $student_count = max(0, (int)($_POST['student_count'] ?? 0));
    $doc_number = post_str('doc_number', 100);
    $doc_number = ($doc_number === '') ? null : $doc_number;
    $description = post_str('description', 5000);
    $description = ($description === '') ? null : $description;
    $is_recurring = isset($_POST['is_recurring']) && $_POST['is_recurring'] == 1;

    if ($user_id <= 0 || $room_id <= 0 || $title === '' || empty($_POST['start_time']) || empty($_POST['end_time'])) {
        throw new BookingInputException('กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน');
    }

    $chk = $pdo->prepare("SELECT id FROM rooms WHERE id = ?");
    $chk->execute([$room_id]);
    if (!$chk->fetch()) { throw new BookingInputException('ไม่พบห้องที่เลือก'); }

    $start_obj = parse_dt((string)$_POST['start_time'], 'เวลาเริ่มต้น');
    $end_obj = parse_dt((string)$_POST['end_time'], 'เวลาสิ้นสุด');

    /* ---------- สร้างรายการวันเวลาทั้งหมดที่จะจอง ---------- */
    $occurrences = [];

    if (!$is_recurring) {
        if ($end_obj <= $start_obj) { throw new BookingInputException('เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น'); }
        $occurrences[] = ['start' => $start_obj->format('Y-m-d H:i:s'), 'end' => $end_obj->format('Y-m-d H:i:s')];
    } else {
        if ($end_obj->format('H:i') <= $start_obj->format('H:i')) {
            throw new BookingInputException('เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น');
        }
        $rec_end_str = isset($_POST['recurrence_end_date']) && is_string($_POST['recurrence_end_date']) ? trim($_POST['recurrence_end_date']) : '';
        if ($rec_end_str === '') { throw new BookingInputException('กรุณาเลือกวันที่สิ้นสุดการเกิดซ้ำ'); }
        $rec_end = parse_dt($rec_end_str, 'วันที่สิ้นสุดการเกิดซ้ำ');
        $rec_end->setTime(23, 59, 59);
        if ($rec_end < $start_obj) { throw new BookingInputException('วันที่สิ้นสุดการเกิดซ้ำต้องไม่อยู่ก่อนวันเริ่มต้น'); }

        $type = isset($_POST['recurrence_type']) && is_string($_POST['recurrence_type']) ? $_POST['recurrence_type'] : 'weekly';
        $too_many = function () {
            return new BookingInputException('จองซ้ำได้สูงสุด ' . MAX_OCCURRENCES . ' ครั้งต่อหนึ่งคำขอ กรุณาลดช่วงวันที่หรือแบ่งเป็นหลายคำขอ');
        };

        if ($type === 'daily' || $type === 'weekly') {
            $weekdays = [];
            if ($type === 'weekly') {
                $raw = isset($_POST['weekdays']) && is_string($_POST['weekdays']) ? explode(',', $_POST['weekdays']) : [];
                foreach ($raw as $w) {
                    $w = trim($w);
                    if ($w !== '' && ctype_digit($w) && (int)$w >= 0 && (int)$w <= 6) { $weekdays[] = (int)$w; }
                }
                if (empty($weekdays)) { throw new BookingInputException('กรุณาเลือกวันในสัปดาห์ที่ต้องการจองซ้ำ'); }
            }
            $cur = clone $start_obj;
            while ($cur <= $rec_end) {
                if ($type === 'daily' || in_array((int)$cur->format('w'), $weekdays, true)) {
                    $occurrences[] = make_entry($cur, $start_obj, $end_obj);
                    if (count($occurrences) > MAX_OCCURRENCES) { throw $too_many(); }
                }
                $cur->modify('+1 day');
            }
        } elseif ($type === 'monthly') {
            // วันที่เดิมของทุกเดือน ถ้าเดือนนั้นไม่มีวันที่นั้น (เช่น 31) ใช้วันสุดท้ายของเดือนแทน
            $dom = (int)$start_obj->format('j');
            $y0 = (int)$start_obj->format('Y');
            $m0 = (int)$start_obj->format('n');
            for ($i = 0; $i <= MAX_OCCURRENCES + 1; $i++) {
                $first = (clone $start_obj)->setDate($y0, $m0 + $i, 1);
                $day = min($dom, (int)$first->format('t'));
                $d = (clone $first)->setDate((int)$first->format('Y'), (int)$first->format('n'), $day);
                if ($d > $rec_end) { break; }
                $occurrences[] = make_entry($d, $start_obj, $end_obj);
                if (count($occurrences) > MAX_OCCURRENCES) { throw $too_many(); }
            }
        } else {
            throw new BookingInputException('รูปแบบการเกิดซ้ำไม่ถูกต้อง');
        }

        if (empty($occurrences)) {
            throw new BookingInputException('ไม่พบวันที่ตรงตามเงื่อนไขการเกิดซ้ำในช่วงเวลาที่เลือก');
        }
    }

    /* ---------- กติกาเรื่องเวลา (ตรวจรายการแรก รายการที่เหลืออยู่หลังจากนั้นเสมอ) ---------- */
    $first_start = new DateTime($occurrences[0]['start']);
    if ($first_start <= new DateTime('now')) {
        throw new BookingInputException('ไม่สามารถจองเวลาที่ผ่านมาแล้วได้');
    }
    if (!can_manage_bookings()) {
        $min_day = new DateTime('today');
        $min_day->modify('+' . ADVANCE_DAYS_FOR_USER . ' days');
        $first_day = (clone $first_start)->setTime(0, 0, 0);
        if ($first_day < $min_day) {
            throw new BookingInputException('ผู้ใช้งานทั่วไปต้องจองล่วงหน้าอย่างน้อย ' . ADVANCE_DAYS_FOR_USER . ' วัน');
        }
    }

    /* ---------- ตรวจเวลาทับกับรายการที่อนุมัติแล้ว ---------- */
    $conflicts = [];
    $cq = $pdo->prepare("SELECT start_time FROM bookings WHERE room_id = ? AND status = 'approved' AND is_deleted = 0 AND (? < end_time AND ? > start_time) LIMIT 1");
    foreach ($occurrences as $o) {
        $cq->execute([$room_id, $o['start'], $o['end']]);
        if ($c = $cq->fetch(PDO::FETCH_ASSOC)) {
            $conflicts[] = (new DateTime($c['start_time']))->format('d/m/Y');
        }
    }
    if (!empty($conflicts)) {
        $conflicts = array_values(array_unique($conflicts));
        if (!$is_recurring) { throw new BookingInputException('ขออภัย ช่วงเวลาที่ท่านเลือกมีผู้จองแล้ว'); }
        $shown = array_slice($conflicts, 0, 10);
        $more = count($conflicts) - count($shown);
        throw new BookingInputException('ไม่สามารถจองได้ เนื่องจากมีวันทับซ้อน: ' . implode(', ', $shown) . ($more > 0 ? ' และอีก ' . $more . ' วัน' : ''));
    }

    /* ---------- บันทึก ---------- */
    $group_id = $is_recurring ? uniqid('recur_') : null;
    $pdo->beginTransaction();
    $ins = $pdo->prepare("INSERT INTO bookings (user_id, room_id, title, department, contact_person, contact_phone, start_time, end_time, description, instructor_name, student_count, doc_number, event_group_id)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($occurrences as $o) {
        $ins->execute([$user_id, $room_id, $title, $department, $contact_person, $contact_phone, $o['start'], $o['end'], $description, $instructor_name, $student_count, $doc_number, $group_id]);
    }
    $pdo->commit();

    respond(true, $is_recurring
        ? 'สร้างการจองแบบเกิดซ้ำเรียบร้อยแล้ว จำนวน ' . count($occurrences) . ' รายการ'
        : 'ส่งคำขอจองเรียบร้อยแล้ว');

} catch (BookingInputException $e) {
    if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
    respond(false, $e->getMessage());
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
    error_log('create_booking error: ' . $e->getMessage());
    respond(false, 'เกิดข้อผิดพลาดในการบันทึกข้อมูล กรุณาลองใหม่อีกครั้ง');
}
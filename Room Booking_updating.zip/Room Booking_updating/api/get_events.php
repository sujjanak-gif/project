<?php
header('Content-Type: application/json');
include_once '../includes/db.php';

$room_id = $_GET['room_id'] ?? 'all';

$query = "SELECT 
            b.id, 
            b.title, 
            b.start_time, 
            b.end_time, 
            b.status,
            b.instructor_name,  
            b.student_count,    
            b.department,       
            r.name as room_name, 
            u.full_name as user_name
          FROM bookings b
          JOIN rooms r ON b.room_id = r.id
          JOIN users u ON b.user_id = u.id
          WHERE b.is_deleted = 0 AND (b.status = 'approved' OR b.status = 'pending')";

$params = [];
if ($room_id !== 'all') {
    $query .= " AND b.room_id = ?";
    $params[] = $room_id;
}

// กรองตามช่วงวันที่ที่ปฏิทินกำลังแสดง (FullCalendar ส่ง start/end มาให้) เพื่อไม่ต้องโหลดการจองทั้งหมด
foreach (['start' => 'b.end_time >= ?', 'end' => 'b.start_time < ?'] as $key => $cond) {
    $val = (isset($_GET[$key]) && is_string($_GET[$key])) ? substr($_GET[$key], 0, 10) : '';
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) {
        $query .= " AND " . $cond;
        $params[] = $val . ($key === 'start' ? ' 00:00:00' : ' 23:59:59');
    }
}
$query .= " ORDER BY b.start_time, b.id";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

$events = [];
$currentTime = new DateTime();
foreach ($bookings as $booking) {
    
    $bgColor = '';
    // Set color based on status
    if ($booking['status'] == 'approved') {
        $bgColor = '#28a745'; // Green for all approved bookings
    } else { // 'pending'
        $bgColor = '#deae0c'; // Orange for all pending bookings
    }
    
    // Check if the event has passed and add a CSS class
    $eventClasses = [];
    $endTime = new DateTime($booking['end_time']);
    if ($endTime < $currentTime) {
        $eventClasses[] = 'past-event';
    }

    $events[] = [
        'id' => $booking['id'],
        'title' => $booking['title'],
        'start' => $booking['start_time'],
        'end' => $booking['end_time'],
        'backgroundColor' => $bgColor,
        'borderColor' => $bgColor, // Match border color to background
        'textColor' => '#ffffff', // Set text color to white
        'classNames' => $eventClasses,
        'extendedProps' => [
            'room_name' => $booking['room_name'],
            'user_name' => $booking['user_name'],
            'instructor_name' => $booking['instructor_name'], 
        'student_count' => $booking['student_count'],   
        'department' => $booking['department'],         
            'status' => $booking['status']
        ]
    ];
}

echo json_encode($events);
?>
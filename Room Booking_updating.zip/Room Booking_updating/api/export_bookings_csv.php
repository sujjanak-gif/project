<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../includes/db.php';
include_once '../includes/functions.php';

// ตรวจสอบสิทธิ์ (ต้องเป็น Admin หรือ Officer)
if (!can_manage_bookings()) {
    exit('ไม่มีสิทธิ์เข้าถึงข้อมูลนี้');
}

// รับค่าตัวกรองที่ส่งมาจากหน้า manage_bookings
$filter_room = $_GET['room_id'] ?? 'all';
$filter_status = $_GET['status'] ?? 'all';
$filter_start_date = $_GET['start_date'] ?? '';
$filter_end_date = $_GET['end_date'] ?? '';

// สร้างเงื่อนไข Query (ลอกมาจากหน้า manage_bookings เพื่อให้ข้อมูลตรงกันเป๊ะ)
$where_clauses = ["b.is_deleted = 0"];
$params = [];

if (is_officer()) {
    $where_clauses[] = "u.department = ?";
    $params[] = $_SESSION['user_department'];
}
if ($filter_status !== 'all') {
    $where_clauses[] = "b.status = ?";
    $params[] = $filter_status;
}
if ($filter_room !== 'all') {
    $where_clauses[] = "b.room_id = ?";
    $params[] = $filter_room;
}
if (!empty($filter_start_date)) {
    $where_clauses[] = "DATE(b.start_time) >= ?";
    $params[] = $filter_start_date;
}
if (!empty($filter_end_date)) {
    $where_clauses[] = "DATE(b.start_time) <= ?";
    $params[] = $filter_end_date;
}

$where_sql = count($where_clauses) > 0 ? "WHERE " . implode(" AND ", $where_clauses) : "";

try {
    // เรียงจากวันที่จองล่าสุด
    $sql = "SELECT b.id, b.title, b.department, b.contact_person, b.contact_phone, 
                   b.start_time, b.end_time, b.status, b.student_count, b.instructor_name,
                   r.name as room_name, u.full_name as user_name
            FROM bookings b 
            JOIN rooms r ON b.room_id = r.id 
            JOIN users u ON b.user_id = u.id 
            $where_sql 
            ORDER BY b.start_time DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ตั้งค่าไฟล์ CSV
    $filename = "All_Bookings_" . date('Y-m-d_H-i-s') . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // ป้องกันภาษาไทย

    // หัวตาราง
    fputcsv($output, ['ID', 'หัวข้อ/รายวิชา', 'ห้อง', 'ผู้จอง', 'หน่วยงาน', 'ผู้ติดต่อ', 'เบอร์โทร', 'อาจารย์ผู้สอน', 'จำนวน นศ.', 'เริ่ม', 'สิ้นสุด', 'สถานะ']);

    if(empty($bookings)) {
        fputcsv($output, ['ไม่มีข้อมูลการจอง', '', '', '', '', '', '', '', '', '', '', '']);
    } else {
        foreach($bookings as $row) {
            // แปลงสถานะเป็นภาษาไทย
            $status_th = '';
            switch($row['status']) {
                case 'approved': $status_th = 'อนุมัติ'; break;
                case 'pending': $status_th = 'รออนุมัติ'; break;
                case 'rejected': $status_th = 'ไม่อนุมัติ'; break;
                default: $status_th = $row['status'];
            }

            fputcsv($output, [
                $row['id'],
                $row['title'],
                $row['room_name'],
                $row['user_name'],
                $row['department'],
                $row['contact_person'],
                $row['contact_phone'],
                $row['instructor_name'],
                $row['student_count'],
                date('d/m/Y H:i', strtotime($row['start_time'])),
                date('d/m/Y H:i', strtotime($row['end_time'])),
                $status_th
            ]);
        }
    }
    fclose($output);
    exit();

} catch (Exception $e) {
    echo "เกิดข้อผิดพลาด: " . $e->getMessage();
}
?>
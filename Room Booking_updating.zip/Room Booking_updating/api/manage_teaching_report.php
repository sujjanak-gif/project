<?php
// manage_teaching_report.php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db.php';
include_once '../includes/functions.php';

// Ensure user is admin and request method is POST
if (!is_admin() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json'); // Set header for JSON response
    echo json_encode(['success' => false, 'message' => 'Permission Denied']);
    exit;
}

header('Content-Type: application/json'); // Set header for JSON response
$response = ['success' => false, 'message' => ''];

$action = $_POST['action'] ?? '';

try {
    if ($action === 'update') {
        // รับได้ทั้ง report_ids (หลายแถวในกลุ่มเดียวกัน) และ report_id (แถวเดียวแบบเดิม)
        $ids_raw = $_POST['report_ids'] ?? ($_POST['report_id'] ?? []);
        if (!is_array($ids_raw)) { $ids_raw = explode(',', (string)$ids_raw); }
        $report_ids = array_values(array_filter(array_map('intval', $ids_raw)));
        $doc_number = trim($_POST['doc_number'] ?? '');
        $remarks = trim($_POST['remarks'] ?? '');

        if (empty($report_ids)) {
            $response['message'] = 'ไม่พบ Report ID';
            echo json_encode($response);
            exit();
        }

        $placeholders = implode(',', array_fill(0, count($report_ids), '?'));
        $stmt = $pdo->prepare("UPDATE teaching_reports SET doc_number = ?, remarks = ?, updated_at = NOW() WHERE id IN ({$placeholders})");
        $stmt->execute(array_merge([$doc_number, $remarks], $report_ids));

        if ($stmt->rowCount() > 0) {
            $response['success'] = true;
            $response['message'] = 'แก้ไขข้อมูลรายงานเรียบร้อยแล้ว';
        } else {
            // ไม่มีแถวที่ค่าเปลี่ยน: ตรวจว่ารายงานยังอยู่หรือไม่
            $chk = $pdo->prepare("SELECT COUNT(*) FROM teaching_reports WHERE id IN ({$placeholders})");
            $chk->execute($report_ids);
            if ((int)$chk->fetchColumn() > 0) {
                $response['success'] = true;
                $response['message'] = 'ไม่มีการเปลี่ยนแปลงข้อมูล';
            } else {
                $response['message'] = 'ไม่พบรายงานที่ต้องการแก้ไข';
            }
        }
    } elseif ($action === 'delete_multiple') { // New action for deleting multiple reports
        $report_ids_raw = $_POST['report_ids'] ?? [];
        if (!is_array($report_ids_raw)) {
            $report_ids_raw = explode(',', $report_ids_raw);
        }
        $report_ids = array_map('intval', $report_ids_raw);
        $report_ids = array_filter($report_ids); // Remove any non-numeric or empty values

        if (empty($report_ids)) {
            $response['message'] = 'ไม่พบ ID รายงานที่ต้องการลบ';
            echo json_encode($response);
            exit();
        }

        $placeholders = implode(',', array_fill(0, count($report_ids), '?'));
        $sql = "DELETE FROM teaching_reports WHERE id IN ({$placeholders})";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($report_ids);

        if ($stmt->rowCount() > 0) {
            $response['success'] = true;
            $response['message'] = 'ลบรายงานสำเร็จ ' . $stmt->rowCount() . ' รายการ';
        } else {
            $response['message'] = 'ไม่พบรายงานที่ต้องการลบ';
        }
    } else {
        $response['message'] = 'Invalid action.';
    }
} catch (PDOException $e) {
    error_log("Error managing teaching report: " . $e->getMessage()); // Log error for debugging
    $response['message'] = 'เกิดข้อผิดพลาดในการประมวลผลข้อมูล กรุณาลองใหม่อีกครั้ง';
}

echo json_encode($response);
?>
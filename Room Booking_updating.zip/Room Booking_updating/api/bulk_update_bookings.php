<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../includes/db.php';
include_once '../includes/functions.php';
require_admin();

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    // ตรวจสอบว่า booking_ids เป็น array หรือ string ที่เป็น comma-separated
    // และแปลงให้เป็น array ของ integers
    $booking_ids_raw = $_POST['booking_ids'] ?? [];
    if (!is_array($booking_ids_raw)) {
        $booking_ids_raw = explode(',', $booking_ids_raw);
    }
    $booking_ids = array_map('intval', $booking_ids_raw);
    $booking_ids = array_filter($booking_ids); // Remove any non-numeric or empty values

    if (empty($action) || empty($booking_ids)) {
        $response['message'] = 'ข้อมูลไม่ครบถ้วนสำหรับการทำรายการ';
        echo json_encode($response);
        exit();
    }

    $placeholders = implode(',', array_fill(0, count($booking_ids), '?'));
    $sql = "";
    $status_to_set = '';

    try {
        switch ($action) {
            case 'approve':
                $status_to_set = 'approved';
                $sql = "UPDATE bookings SET status = ?, updated_at = NOW() WHERE id IN ({$placeholders})";
                break;
            case 'reject':
                $status_to_set = 'rejected';
                $sql = "UPDATE bookings SET status = ?, updated_at = NOW() WHERE id IN ({$placeholders})";
                break;
            case 'delete':
                // Assuming 'is_deleted' flag is used for soft delete
                $sql = "UPDATE bookings SET is_deleted = 1, updated_at = NOW() WHERE id IN ({$placeholders})";
                break;
            default:
                $response['message'] = 'การกระทำไม่ถูกต้อง';
                echo json_encode($response);
                exit();
        }

        $stmt = $pdo->prepare($sql);
        if ($action === 'delete') {
            $stmt->execute($booking_ids); // No status param for delete
        } else {
            $stmt->execute(array_merge([$status_to_set], $booking_ids));
        }

        if ($stmt->rowCount() > 0) {
            $response['success'] = true;
            $response['message'] = 'ทำรายการสำเร็จ ' . $stmt->rowCount() . ' รายการ';
        } else {
            $response['message'] = 'ไม่พบรายการที่ตรงกับเงื่อนไข หรือไม่มีการเปลี่ยนแปลงสถานะ';
        }

    } catch (PDOException $e) {
        error_log("Error in bulk_update_bookings: " . $e->getMessage());
        $response['message'] = 'เกิดข้อผิดพลาดในการประมวลผลข้อมูล: ' . $e->getMessage();
    }

} else {
    $response['message'] = 'Invalid request method.';
}

echo json_encode($response);
?>
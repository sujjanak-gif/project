<?php
header('Content-Type: application/json; charset=utf-8');
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db.php';
include_once '../includes/functions.php';

function uu_out(array $data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!is_admin()) { uu_out(['success' => false, 'message' => 'Permission denied']); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { uu_out(['success' => false, 'message' => 'Invalid request method.']); }

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$action = isset($_POST['action']) && is_string($_POST['action']) ? $_POST['action'] : '';

if ($id <= 0 || $action === '') { uu_out(['success' => false, 'message' => 'Invalid input']); }

// การกระทำกับบัญชีของตัวเองถูกห้ามไว้ตรงนี้ จึงมีผู้ดูแลระบบที่อนุมัติแล้วเหลืออยู่อย่างน้อยหนึ่งคน (ตัวคุณเอง) เสมอ
if ($id === (int)$_SESSION['user_id']) {
    uu_out(['success' => false, 'message' => 'ไม่สามารถดำเนินการกับบัญชีของตัวเองได้']);
}

try {
    $response = ['success' => true];
    $new_status_badge = '';
    $new_action_buttons = '';

    switch ($action) {
        case 'update_role':
            $role = isset($_POST['role']) && is_string($_POST['role']) ? $_POST['role'] : '';
            if (!in_array($role, ['admin', 'officer', 'user'], true)) {
                uu_out(['success' => false, 'message' => 'สิทธิ์ที่เลือกไม่ถูกต้อง']);
            }
            $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->execute([$role, $id]);
            $response['message'] = 'อัปเดตสิทธิ์เรียบร้อย';
            break;

        case 'approve':
        case 'reactivate':
            $stmt = $pdo->prepare("UPDATE users SET status = 'approved' WHERE id = ?");
            $stmt->execute([$id]);
            $response['message'] = 'เปิดใช้งานผู้ใช้เรียบร้อย';
            $new_status_badge = format_user_status_badge('approved');
            break;

        case 'deactivate':
            $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
            $stmt->execute([$id]);
            $response['message'] = 'ปิดใช้งานผู้ใช้เรียบร้อย';
            $new_status_badge = format_user_status_badge('inactive');
            break;

        case 'suspend':
            $stmt = $pdo->prepare("UPDATE users SET status = 'suspended' WHERE id = ?");
            $stmt->execute([$id]);
            $response['message'] = 'ระงับผู้ใช้เรียบร้อย';
            $new_status_badge = format_user_status_badge('suspended');
            break;

        case 'delete':
            $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE user_id = ?");
            $stmt_check->execute([$id]);
            if ($stmt_check->fetchColumn() > 0) {
                uu_out(['success' => false, 'message' => 'ไม่สามารถลบผู้ใช้ได้ เนื่องจากผู้ใช้ยังมีประวัติการจองอยู่ ให้ใช้ "ปิดใช้งาน" แทน']);
            }
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $response['message'] = 'ลบผู้ใช้เรียบร้อยแล้ว';
            break;

        default:
            uu_out(['success' => false, 'message' => 'Invalid action']);
    }

    $response['new_status_badge'] = $new_status_badge;
    $response['new_action_buttons'] = $new_action_buttons; // คงไว้เพื่อความเข้ากันได้กับหน้าเดิม
    uu_out($response);

} catch (PDOException $e) {
    error_log('update_user error: ' . $e->getMessage());
    if ($e->getCode() == '23000') {
        uu_out(['success' => false, 'message' => 'ไม่สามารถลบผู้ใช้ได้ เนื่องจากผู้ใช้ยังมีข้อมูลที่เกี่ยวข้องอยู่ในระบบ']);
    }
    uu_out(['success' => false, 'message' => 'เกิดข้อผิดพลาดในการประมวลผลข้อมูล กรุณาลองใหม่อีกครั้ง']);
}
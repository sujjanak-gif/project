<?php
// create_teaching_report.php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db.php';
include_once '../includes/functions.php';

// Ensure user is admin and request method is POST
if (!is_admin() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json'); // Set header for JSON response
    echo json_encode(['success' => false, 'message' => 'Permission Denied']);
    exit;
}

header('Content-Type: application/json'); // Set header for JSON response
$response = ['success' => false, 'message' => ''];

// booking_ids_selected will be a string like "1,2,3" from the single select dropdown
// or an array of strings if 'multiple' attribute was used.
$selected_input = $_POST['booking_ids_selected'] ?? ''; // รับค่าจาก POST

$all_booking_ids_to_create_report = [];

// ตรวจสอบว่าเป็น array หรือ string
if (is_array($selected_input)) {
    // ถ้าเป็น array (กรณี multiple select)
    foreach ($selected_input as $group_string) {
        $ids_in_group = explode(',', $group_string);
        $all_booking_ids_to_create_report = array_merge($all_booking_ids_to_create_report, $ids_in_group);
    }
} else {
    // ถ้าเป็น string (กรณี single select)
    $ids_in_group = explode(',', $selected_input);
    $all_booking_ids_to_create_report = array_merge($all_booking_ids_to_create_report, $ids_in_group);
}

// Remove duplicates and convert to int
$all_booking_ids_to_create_report = array_map('intval', array_unique($all_booking_ids_to_create_report));
$all_booking_ids_to_create_report = array_filter($all_booking_ids_to_create_report); // Remove any 0 or empty after intval

if (empty($all_booking_ids_to_create_report)) {
    $response['message'] = 'ไม่พบ ID การจองที่ถูกต้องสำหรับสร้างรายงาน';
    echo json_encode($response);
    exit();
}

$doc_number = trim($_POST['doc_number'] ?? '');
$remarks = trim($_POST['remarks'] ?? '');

$pdo->beginTransaction(); // Start transaction for atomicity
try {
    $stmt_insert = $pdo->prepare("INSERT INTO teaching_reports (booking_id, doc_number, remarks, created_at) VALUES (?, ?, ?, NOW())");
    $inserted_count = 0;

    foreach ($all_booking_ids_to_create_report as $booking_id) {
        // Check if this booking_id is already in a report to avoid duplicates
        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM teaching_reports WHERE booking_id = ?");
        $check_stmt->execute([$booking_id]);
        if ($check_stmt->fetchColumn() == 0) { // Only insert if not already reported
            $stmt_insert->execute([$booking_id, $doc_number, $remarks]);
            $inserted_count++;
        }
    }

    $pdo->commit(); // Commit transaction if all inserts are successful
    $response['success'] = true;
    $response['message'] = "สร้างรายงานสำเร็จ {$inserted_count} รายการ";

} catch (PDOException $e) {
    $pdo->rollBack(); // Rollback on error
    error_log("Error creating teaching report: " . $e->getMessage());
    $response['message'] = 'เกิดข้อผิดพลาดในการบันทึกรายงาน: ' . $e->getMessage();
}

echo json_encode($response);
?>
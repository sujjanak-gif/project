<?php
include_once '../includes/db.php';


date_default_timezone_set('Asia/Bangkok');


$sql = "SELECT b.*, r.name as room_name 
        FROM bookings b 
        JOIN rooms r ON b.room_id = r.id 
        WHERE b.status = 'approved' AND b.is_deleted = 0";
$stmt = $pdo->query($sql);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);


header('Content-Type: text/calendar; charset=utf-8');
header('Content-Disposition: attachment; filename="bookings.ics"');


echo "BEGIN:VCALENDAR\r\n";
echo "VERSION:2.0\r\n";
echo "PRODID:-//MyOrg//BookingSystem//TH\r\n";
echo "X-WR-CALNAME:ระบบจองห้อง\r\n"; 
echo "X-WR-TIMEZONE:Asia/Bangkok\r\n";
echo "CALSCALE:GREGORIAN\r\n";

foreach ($bookings as $row) {
    
    $dtStart = date('Ymd\THis', strtotime($row['start_time']));
    $dtEnd = date('Ymd\THis', strtotime($row['end_time']));
    $dtStamp = date('Ymd\THis\Z');

    echo "BEGIN:VEVENT\r\n";
    echo "UID:booking_" . $row['id'] . "@yourdomain.com\r\n";
    echo "DTSTAMP:" . $dtStamp . "\r\n";
    echo "DTSTART:" . $dtStart . "\r\n";
    echo "DTEND:" . $dtEnd . "\r\n";
    echo "SUMMARY:" . $row['title'] . " (" . $row['room_name'] . ")\r\n";
    echo "DESCRIPTION:ผู้จอง: " . $row['contact_person'] . "\\nภาควิชา: " . $row['department'] . "\r\n";
    echo "LOCATION:" . $row['room_name'] . "\r\n";
    echo "END:VEVENT\r\n";
}

echo "END:VCALENDAR";
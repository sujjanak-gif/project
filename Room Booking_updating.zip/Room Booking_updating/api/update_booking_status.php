<?php
// update_booking_status.php
header('Content-Type: application/json');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../includes/db.php';
include_once '../includes/functions.php';
include_once '../includes/mailer.php';

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'กรุณาเข้าสู่ระบบ']);
    exit;
}

$booking_ids_raw = $_POST['booking_ids'] ?? null;
$single_id = $_POST['id'] ?? null;
$action = $_POST['action'] ?? null;

$target_ids = [];

if ($booking_ids_raw !== null) {
    if (is_array($booking_ids_raw)) {
        $target_ids = $booking_ids_raw;
    } else {
        $target_ids = explode(',', $booking_ids_raw);
    }
    $target_ids = array_map('intval', $target_ids);
    $target_ids = array_filter($target_ids);
} elseif ($single_id !== null) {
    $target_ids = [intval($single_id)];
}

if (empty($target_ids) || !$action) {
    echo json_encode(['success' => false, 'message' => 'ข้อมูลไม่ถูกต้องหรือไม่ครบถ้วน']);
    exit;
}

/**
 * ตรวจว่าการอนุมัติรายการเหล่านี้จะทำให้จองซ้อนเวลากันหรือไม่
 * - ชนกับรายการที่อนุมัติแล้ว (ห้องเดียวกัน เวลาทับกัน)
 * - รายการที่กำลังจะอนุมัติพร้อมกันเองทับกัน
 * คืนข้อความอธิบาย หรือ null ถ้าไม่มีปัญหา
 */
function approval_conflicts(PDO $pdo, array $ids) {
    $ids = array_values(array_map('intval', $ids));
    if (empty($ids)) { return null; }
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT id, room_id, start_time, end_time, title, status FROM bookings WHERE id IN ($ph) AND is_deleted = 0");
    $st->execute($ids);
    $targets = $st->fetchAll(PDO::FETCH_ASSOC);

    $fmt = function ($row) {
        $s = strtotime($row['start_time']); $e = strtotime($row['end_time']);
        return $row['title'] . ' (' . date('d/m/Y H:i', $s) . '-' . date('H:i', $e) . ')';
    };
    $found = [];

    // 1) ชนกับรายการที่อนุมัติแล้ว
    $q = $pdo->prepare("SELECT title, start_time, end_time FROM bookings
        WHERE room_id = ? AND id <> ? AND status = 'approved' AND is_deleted = 0 AND start_time < ? AND end_time > ? LIMIT 1");
    $pending = [];
    foreach ($targets as $t) {
        if ($t['status'] === 'approved') { continue; } // อนุมัติอยู่แล้ว ไม่เปลี่ยนแปลง
        $pending[] = $t;
        $q->execute([$t['room_id'], $t['id'], $t['end_time'], $t['start_time']]);
        if ($c = $q->fetch(PDO::FETCH_ASSOC)) {
            $found[] = $fmt($t) . ' ชนกับ ' . $fmt($c);
        }
    }

    // 2) รายการที่เลือกอนุมัติพร้อมกันทับกันเอง
    for ($i = 0; $i < count($pending); $i++) {
        for ($j = $i + 1; $j < count($pending); $j++) {
            $a = $pending[$i]; $b = $pending[$j];
            if ($a['room_id'] == $b['room_id'] && $a['start_time'] < $b['end_time'] && $a['end_time'] > $b['start_time']) {
                $found[] = $fmt($a) . ' ทับกับ ' . $fmt($b) . ' (ที่เลือกอนุมัติพร้อมกัน)';
            }
        }
    }

    if (empty($found)) { return null; }
    $shown = array_slice($found, 0, 5);
    $more = count($found) - count($shown);
    return 'อนุมัติไม่ได้ เพราะจะทำให้จองซ้อนเวลากัน: ' . implode(' / ', $shown) . ($more > 0 ? ' และอีก ' . $more . ' รายการ' : '');
}

try {
    $response = ['success' => true];

    // --- User Actions ---
    if ($action === 'cancel') {
        if (count($target_ids) !== 1) {
            echo json_encode(['success' => false, 'message' => 'การยกเลิกสามารถทำได้ทีละรายการเท่านั้น']);
            exit;
        }
        $id_to_cancel = $target_ids[0];

        $stmt_check = $pdo->prepare("SELECT user_id, status FROM bookings WHERE id = ?");
        $stmt_check->execute([$id_to_cancel]);
        $booking = $stmt_check->fetch();

        if (!$booking || ($booking['user_id'] != $_SESSION['user_id'] && !is_admin())) { // Allow admin to cancel too
            echo json_encode(['success' => false, 'message' => 'คุณไม่มีสิทธิ์ยกเลิกรายการนี้']);
            exit;
        }
        if ($booking['status'] != 'pending') {
            echo json_encode(['success' => false, 'message' => 'ไม่สามารถยกเลิกรายการที่ได้รับการจัดการแล้ว']);
            exit;
        }
        $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled', updated_at = NOW() WHERE id = ?");
        $stmt->execute([$id_to_cancel]);
        $response['message'] = 'ยกเลิกรายการจองเรียบร้อยแล้ว';
        $response['new_status_badge'] = format_status_badge('cancelled');
    }
    // --- User: ลบรายการจองของตัวเอง (เฉพาะที่ยัง pending) ---
    elseif ($action === 'delete_own') {
        if (!csrf_verify($_POST['csrf_token'] ?? null)) {
            echo json_encode(['success' => false, 'message' => 'เซสชันหมดอายุหรือคำขอไม่ถูกต้อง กรุณารีเฟรชหน้าแล้วลองใหม่']);
            exit;
        }
        if (count($target_ids) !== 1) {
            echo json_encode(['success' => false, 'message' => 'การลบสามารถทำได้ทีละรายการเท่านั้น']);
            exit;
        }
        $scope = $_POST['scope'] ?? 'single';
        $my_id = (int)$_SESSION['user_id'];

        $stmt_check = $pdo->prepare("SELECT user_id, status, is_deleted, event_group_id FROM bookings WHERE id = ?");
        $stmt_check->execute([$target_ids[0]]);
        $booking = $stmt_check->fetch();

        if (!$booking || $booking['is_deleted'] || (int)$booking['user_id'] !== $my_id) {
            echo json_encode(['success' => false, 'message' => 'คุณไม่มีสิทธิ์ลบรายการนี้']);
            exit;
        }
        if ($booking['status'] !== 'pending') {
            echo json_encode(['success' => false, 'message' => 'ลบได้เฉพาะรายการที่ยังรออนุมัติเท่านั้น']);
            exit;
        }

        if ($scope === 'series' && !empty($booking['event_group_id'])) {
            // ลบทั้งชุดที่เกิดซ้ำ เฉพาะรายการของตัวเองที่ยัง pending
            $stmt_ids = $pdo->prepare("SELECT id FROM bookings WHERE event_group_id = ? AND user_id = ? AND status = 'pending' AND is_deleted = 0");
            $stmt_ids->execute([$booking['event_group_id'], $my_id]);
            $ids_to_delete = array_map('intval', $stmt_ids->fetchAll(PDO::FETCH_COLUMN));
        } else {
            $ids_to_delete = [(int)$target_ids[0]];
        }

        if (empty($ids_to_delete)) {
            echo json_encode(['success' => false, 'message' => 'ไม่พบรายการที่ต้องการลบ']);
            exit;
        }

        $ph = implode(',', array_fill(0, count($ids_to_delete), '?'));
        $stmt = $pdo->prepare("UPDATE bookings SET is_deleted = 1, updated_at = NOW() WHERE id IN ($ph) AND user_id = ? AND status = 'pending' AND is_deleted = 0");
        $stmt->execute(array_merge($ids_to_delete, [$my_id]));

        $response['message'] = 'ลบรายการจองเรียบร้อยแล้ว ' . $stmt->rowCount() . ' รายการ';
        $response['deleted_ids'] = $ids_to_delete;
    }
    // --- Admin & Officer Actions ---
    else if (can_manage_bookings()) {
        
        // **Security Check for Officers**
        if (is_officer()) { // <-- แก้ไขจาก is_editor() เป็น is_officer()
            $placeholders_check = implode(',', array_fill(0, count($target_ids), '?'));
            $sql_check = "SELECT COUNT(b.id) FROM bookings b JOIN users u ON b.user_id = u.id WHERE b.id IN ($placeholders_check) AND u.department = ?";
            $check_params = array_merge($target_ids, [$_SESSION['user_department']]);
            
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute($check_params);
            
            if ($stmt_check->fetchColumn() != count($target_ids)) {
                echo json_encode(['success' => false, 'message' => 'คุณมีสิทธิ์จัดการเฉพาะการจองในแผนกของคุณเท่านั้น']);
                exit;
            }
        }

        // การลบถาวรเป็นสิทธิ์ของผู้ดูแลระบบเท่านั้น
        if ($action === 'perm_delete' && !is_admin()) {
            echo json_encode(['success' => false, 'message' => 'เฉพาะผู้ดูแลระบบเท่านั้นที่ลบถาวรได้']);
            exit;
        }

        // อนุมัติ: ตรวจเวลาชนก่อนเสมอ และล็อกไม่ให้มีการอนุมัติซ้อนกันจากหลายคนในเวลาเดียวกัน
        if ($action === 'approve') {
            $got_lock = (int)$pdo->query("SELECT GET_LOCK('bk_approve_lock', 5)")->fetchColumn();
            if ($got_lock !== 1) {
                echo json_encode(['success' => false, 'message' => 'ระบบกำลังประมวลผลการอนุมัติของผู้อื่นอยู่ กรุณาลองใหม่อีกครั้ง']);
                exit;
            }
            register_shutdown_function(function () use ($pdo) {
                try { $pdo->query("SELECT RELEASE_LOCK('bk_approve_lock')"); } catch (Throwable $e) { /* ignore */ }
            });

            // ผู้ดูแลระบบอนุมัติทั้งที่ชนได้ ถ้ายืนยันเอง (ส่ง force=1) เจ้าหน้าที่ทำไม่ได้
            $force = !empty($_POST['force']) && is_admin();
            if (!$force) {
                $conflict_msg = approval_conflicts($pdo, $target_ids);
                if ($conflict_msg !== null) {
                    echo json_encode(['success' => false, 'message' => $conflict_msg]);
                    exit;
                }
            }
        }

        $placeholders = implode(',', array_fill(0, count($target_ids), '?'));
        $sql = "";
        $status_to_set = '';

        switch ($action) {
            case 'approve':
                $status_to_set = 'approved';
                $sql = "UPDATE bookings SET status = ?, updated_at = NOW() WHERE id IN ({$placeholders})";
                break;
            case 'reject':
                $status_to_set = 'rejected';
                $sql = "UPDATE bookings SET status = ?, updated_at = NOW() WHERE id IN ({$placeholders})";
                break;
            case 'unapprove':
                $status_to_set = 'pending';
                $sql = "UPDATE bookings SET status = ?, updated_at = NOW() WHERE id IN ({$placeholders})";
                break;
            case 'delete':
                $sql = "UPDATE bookings SET is_deleted = 1, updated_at = NOW() WHERE id IN ({$placeholders})";
                break;
            case 'restore':
                $status_to_set = 'pending';
                $sql = "UPDATE bookings SET status = ?, updated_at = NOW(), is_deleted = 0 WHERE id IN ({$placeholders})";
                break;
            case 'perm_delete':
                $sql = "DELETE FROM bookings WHERE id IN ({$placeholders})";
                break;
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid admin action']);
                exit;
        }

        $stmt = $pdo->prepare($sql);
        if ($action === 'delete' || $action === 'perm_delete') {
            $stmt->execute($target_ids);
        } else {
            $stmt->execute(array_merge([$status_to_set], $target_ids));
        }

        if ($stmt->rowCount() > 0) {
            $response['success'] = true;
            $response['message'] = 'ทำรายการสำเร็จ ' . $stmt->rowCount() . ' รายการ';
            if ($action === 'approve' || $action === 'reject') {
                foreach ($target_ids as $id) {
                    send_booking_notification($id, $action);
                }
            }
        } else {
            $response['success'] = false;
            $response['message'] = 'ไม่พบรายการที่ตรงกับเงื่อนไข หรือไม่มีการเปลี่ยนแปลงสถานะ';
        }

    } else {
        echo json_encode(['success' => false, 'message' => 'คุณไม่มีสิทธิ์ดำเนินการ']);
        exit;
    }

    echo json_encode($response);

} catch (PDOException $e) {
    error_log("Error in update_booking_status: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'เกิดข้อผิดพลาดในการประมวลผลข้อมูล กรุณาลองใหม่อีกครั้ง']);
}
?>
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once 'includes/db.php';
include_once 'includes/functions.php';

$page_title = "ปฏิทินรายปี";
include 'includes/header.php';

// --- PHP Logic for Yearly Calendar ---
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$buddhist_year = $year + 543;

// 1. Fetch ALL relevant bookings for the year and store in a structured array
$all_bookings_by_date = [];
$stmt = $pdo->prepare("
    SELECT 
        b.title, 
        r.name as room_name, 
        b.start_time, 
        b.end_time
    FROM bookings b
    JOIN rooms r ON b.room_id = r.id
    WHERE YEAR(b.start_time) = ? AND b.is_deleted = 0 AND b.status IN ('approved', 'pending')
    ORDER BY b.start_time ASC
");
$stmt->execute([$year]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($results as $booking) {
    $date = date('Y-m-d', strtotime($booking['start_time']));
    if (!isset($all_bookings_by_date[$date])) {
        $all_bookings_by_date[$date] = [];
    }
    $all_bookings_by_date[$date][] = [
        'title' => htmlspecialchars($booking['title']),
        'room_name' => htmlspecialchars($booking['room_name']),
        'start_time' => date('H:i', strtotime($booking['start_time'])),
        'end_time' => date('H:i', strtotime($booking['end_time']))
    ];
}

// Pass the PHP array to JavaScript
$js_bookings = json_encode($all_bookings_by_date);

// 2. Helper function to generate a single month's calendar
function generate_month_calendar($month, $year, $buddhist_year, $booked_dates) {
    // ... (unchanged code for month generation)
    $month_name = date('F', mktime(0, 0, 0, $month, 1, $year));
    // Thai month names array
    $thai_month_names = [
        'January' => 'มกราคม', 'February' => 'กุมภาพันธ์', 'March' => 'มีนาคม',
        'April' => 'เมษายน', 'May' => 'พฤษภาคม', 'June' => 'มิถุนายน',
        'July' => 'กรกฎาคม', 'August' => 'สิงหาคม', 'September' => 'กันยายน',
        'October' => 'ตุลาคม', 'November' => 'พฤศจิกายน', 'December' => 'ธันวาคม'
    ];
    $thai_month = $thai_month_names[$month_name];

    $first_day_of_month = date('w', mktime(0, 0, 0, $month, 1, $year));
    $days_in_month = date('t', mktime(0, 0, 0, $month, 1, $year));

    $calendar_html = "<div class='month-container'>";
    $calendar_html .= "<div class='month-header'>{$thai_month} {$buddhist_year}</div>";
    $calendar_html .= "<div class='day-names'><span>อา</span><span>จ</span><span>อ</span><span>พ</span><span>พฤ</span><span>ศ</span><span>ส</span></div>";
    $calendar_html .= "<div class='day-grid'>";

    for ($i = 0; $i < $first_day_of_month; $i++) {
        $calendar_html .= "<div class='day-cell empty'></div>";
    }

    for ($day = 1; $day <= $days_in_month; $day++) {
        $current_date_str = date('Y-m-d', mktime(0, 0, 0, $month, $day, $year));
        $class = 'day-cell';
        $data_attr = '';
        if (isset($booked_dates[$current_date_str])) {
            $class .= ' booked';
            $data_attr = " data-date='{$current_date_str}'";
        }
        $calendar_html .= "<div class='{$class}'{$data_attr}>{$day}</div>";
    }

    $calendar_html .= "</div></div>";
    return $calendar_html;
}

// Rerun the loop to populate booked_dates for the function call
$booked_dates = [];
foreach ($all_bookings_by_date as $date => $bookings) {
    $booked_dates[$date] = true;
}
?>

<div class="container-fluid py-4 px-lg-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">ภาพรวมปฏิทินปี <?php echo $buddhist_year; ?></h2>
        <div>
            <a href="?year=<?php echo $year - 1; ?>" class="btn btn-outline-secondary">&lt; ปีก่อนหน้า</a>
            <a href="index.php" class="btn btn-secondary">มุมมองปกติ</a>
            <a href="?year=<?php echo $year + 1; ?>" class="btn btn-outline-secondary">ปีถัดไป &gt;</a>
        </div>
    </div>

    <div class="year-view-grid">
        <?php
        for ($month = 1; $month <= 12; $month++) {
            echo generate_month_calendar($month, $year, $buddhist_year, $booked_dates);
        }
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<?php include 'includes/footer.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        
        const allBookings = <?php echo $js_bookings; ?>;

        
        document.querySelectorAll('.day-cell.booked').forEach(cell => {
            const date = cell.dataset.date;
            const bookingsForDate = allBookings[date];

            if (bookingsForDate) {
                // tooltip
                let tooltipContent = '<ul>';
                bookingsForDate.forEach(booking => {
                    tooltipContent += `<li><strong>${booking.room_name}</strong>: ${booking.title} (${booking.start_time} - ${booking.end_time})</li>`;
                });
                tooltipContent += '</ul>';

                
                new bootstrap.Popover(cell, {
                    title: 'รายการจอง',
                    content: tooltipContent,
                    html: true,
                    trigger: 'hover',
                    placement: 'top'
                });
            }
        });
    });
</script>
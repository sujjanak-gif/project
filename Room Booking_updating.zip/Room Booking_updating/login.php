<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once 'includes/db.php';
include_once 'includes/functions.php';

// ถ้า includes/functions.php ยังไม่ได้อัปเดตเป็นเวอร์ชันใหม่ ให้ข้ามการจำกัดการลองผิดแทนที่จะเกิด Fatal error
if (!function_exists('auth_client_ip')) {
    function auth_client_ip() { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }
}
if (!function_exists('auth_throttle_wait')) {
    function auth_throttle_wait($pdo, $action, $ident, $max_ident = 5, $max_ip = 20, $window_min = 15) { return 0; }
}
if (!function_exists('auth_throttle_fail')) {
    function auth_throttle_fail($pdo, $action, $ident) { }
}
if (!function_exists('auth_throttle_clear')) {
    function auth_throttle_clear($pdo, $action, $ident) { }
}

if (is_logged_in()) {
    header('Location: ' . get_redirect_url());
    exit();
}

// แฮชสมมติ (รูปแบบ bcrypt ที่ถูกต้อง) ใช้ตรวจเมื่อไม่พบชื่อผู้ใช้ เพื่อให้ใช้เวลาใกล้เคียงกับกรณีพบ
const LOGIN_DUMMY_HASH = '$2y$10$4r63HZi0ZdgYbYgrj8Hd2LwXKSbbvDVlJvS4tzVCGoHz2oMdUO8dH';

$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) && is_string($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';

    if (function_exists('csrf_verify') && !csrf_verify($_POST['csrf_token'] ?? null)) {
        $error = 'หน้านี้หมดอายุ กรุณาลองเข้าสู่ระบบอีกครั้ง';
    } elseif ($username === '' || $password === '') {
        $error = 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน';
    } elseif (strlen($username) > 100 || strlen($password) > 1000) {
        $error = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
    } else {
        $ident = hash('sha256', function_exists('mb_strtolower') ? mb_strtolower($username) : strtolower($username));
        $wait = auth_throttle_wait($pdo, 'login', $ident);

        if ($wait > 0) {
            $error = 'ลองเข้าสู่ระบบผิดหลายครั้ง กรุณาลองใหม่ในอีก ' . max(1, (int)ceil($wait / 60)) . ' นาที';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            $hash = $user ? $user['password'] : LOGIN_DUMMY_HASH;
            $valid = password_verify($password, $hash) && $user;

            if ($valid) {
                if ($user['status'] === 'approved') {
                    session_regenerate_id(true); // กัน session fixation
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['user_fullname'] = $user['full_name'];
                    $_SESSION['user_department'] = $user['department'];
                    auth_throttle_clear($pdo, 'login', $ident);

                    // อัปเกรดแฮชรหัสผ่านถ้าอัลกอริทึมมาตรฐานของ PHP เปลี่ยน
                    if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
                        $upd = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                        $upd->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
                    }
                    header('Location: ' . get_redirect_url());
                    exit();
                } elseif ($user['status'] === 'pending') {
                    $error = 'บัญชีของคุณยังรอผู้ดูแลระบบอนุมัติ';
                } else {
                    $error = 'บัญชีของคุณถูกระงับหรือปิดใช้งาน กรุณาติดต่อผู้ดูแลระบบ';
                }
            } else {
                auth_throttle_fail($pdo, 'login', $ident);
                $error = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
            }
        }
    }
}

$page_title = "เข้าสู่ระบบ";
include 'includes/header.php';
?>

<style>
.au-wrap { max-width:440px; margin:56px auto; }
.au-card { background:#fff; border:1px solid #e3e8ee; border-radius:18px; box-shadow:0 6px 24px rgba(18,52,86,.10); overflow:hidden; }
.au-head { padding:26px 28px 20px; background:#003399; color:#fff; }
.au-head .ic { width:48px; height:48px; border-radius:14px; background:rgba(255,255,255,.18); display:flex; align-items:center; justify-content:center; font-size:1.3rem; margin-bottom:12px; }
.au-head h1 { font-size:1.45rem; font-weight:600; margin:0; }
.au-head p { margin:4px 0 0; opacity:.85; font-size:.92rem; }
.au-body { padding:26px 28px 8px; }
.au-foot { padding:14px 28px 22px; text-align:center; font-size:.92rem; color:#667587; }
.au-foot a { text-decoration:none; }
.au-body .form-label { font-weight:500; }
.au-body .form-control { padding:.6rem .8rem; }
.au-pw { position:relative; }
.au-pw .toggle { position:absolute; top:50%; right:6px; transform:translateY(-50%); border:0; background:none; padding:6px 10px; color:#667587; cursor:pointer; }
.au-pw .toggle:focus-visible { outline:2px solid #003399; border-radius:6px; }
.au-pw input { padding-right:44px; }
</style>

<div class="au-wrap px-3">
    <div class="au-card">
        <div class="au-head">
            <div class="ic"><i class="fas fa-right-to-bracket"></i></div>
            <h1>เข้าสู่ระบบ</h1>
            <p>ระบบจองห้อง งานเทคโนโลยีดิจิทัล</p>
        </div>
        <div class="au-body">
            <?php if ($error): ?>
                <div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="POST" action="login.php" autocomplete="on">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(function_exists('csrf_token') ? csrf_token() : ''); ?>">
                <div class="mb-3">
                    <label for="username" class="form-label">ชื่อผู้ใช้</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" maxlength="100" autocomplete="username" autofocus required>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label">รหัสผ่าน</label>
                    <div class="au-pw">
                        <input type="password" class="form-control" id="password" name="password" autocomplete="current-password" required>
                        <button type="button" class="toggle" id="pwToggle" aria-label="แสดงหรือซ่อนรหัสผ่าน"><i class="far fa-eye"></i></button>
                    </div>
                </div>
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary btn-lg">เข้าสู่ระบบ</button>
                </div>
            </form>
        </div>
        <div class="au-foot">
            <a href="index.php"><i class="fas fa-home me-1"></i>กลับหน้าปฏิทิน</a>
            <hr class="my-3">
            ยังไม่มีบัญชี? <a href="register.php">ลงทะเบียนที่นี่</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
document.getElementById('pwToggle').addEventListener('click', function () {
    var i = document.getElementById('password');
    var show = i.type === 'password';
    i.type = show ? 'text' : 'password';
    this.querySelector('i').className = show ? 'far fa-eye-slash' : 'far fa-eye';
});
</script>
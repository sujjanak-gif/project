<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';
require_admin();

$page_title = "ประวัติการจอง";
include 'layouts/admin_header.php';

/* =====================================================================
   Helpers (prefix hs_)
   ===================================================================== */
function hs_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function hs_get($key, $default = '') {
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? trim($_GET[$key]) : $default;
}
function hs_url(array $set = [], array $unset = []) {
    $q = $_GET;
    foreach ($unset as $k) { unset($q[$k]); }
    foreach ($set as $k => $v) {
        if ($v === null || $v === '') { unset($q[$k]); } else { $q[$k] = $v; }
    }
    return '?' . http_build_query($q);
}
function hs_date($ts) {
    static $m = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.', 7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    return date('j', $ts) . ' ' . $m[(int)date('n', $ts)] . ' ' . substr((string)(date('Y', $ts) + 543), -2);
}
function hs_period($s, $e) {
    $a = hs_date($s); $b = hs_date($e);
    return $a === $b ? $a : $a . ' ถึง ' . $b;
}
function hs_color($c) { return preg_match('/^#[0-9a-fA-F]{3,8}$/', (string)$c) ? $c : '#9aa7b6'; }

/* =====================================================================
   1) ตัวกรอง
   ===================================================================== */
$status_names = ['pending' => 'รออนุมัติ', 'approved' => 'อนุมัติ', 'rejected' => 'ปฏิเสธ', 'cancelled' => 'ยกเลิก'];
$rooms = $pdo->query("SELECT id, name, color FROM rooms ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$filter_room = hs_get('room_id', 'all');
if ($filter_room !== 'all' && !ctype_digit($filter_room)) { $filter_room = 'all'; }
$filter_start = hs_get('start_date');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_start)) { $filter_start = ''; }
$filter_end = hs_get('end_date');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_end)) { $filter_end = ''; }
$search = hs_get('q');
if ($search !== '') { $search = function_exists('mb_substr') ? mb_substr($search, 0, 100) : substr($search, 0, 100); }
$per_page = 25;
$current_page = max(1, (int)hs_get('page', '1'));
$has_filters = ($filter_room !== 'all' || $filter_start !== '' || $filter_end !== '' || $search !== '');

$common = []; $common_params = [];
if ($filter_room !== 'all') { $common[] = "b.room_id = ?"; $common_params[] = (int)$filter_room; }
if ($filter_start !== '') { $common[] = "DATE(b.start_time) >= ?"; $common_params[] = $filter_start; }
if ($filter_end !== '') { $common[] = "DATE(b.start_time) <= ?"; $common_params[] = $filter_end; }
if ($search !== '') {
    $like = '%' . addcslashes($search, '\\%_') . '%';
    $common[] = "(b.title LIKE ? OR u.full_name LIKE ? OR r.name LIKE ? OR b.instructor_name LIKE ?)";
    for ($k = 0; $k < 4; $k++) { $common_params[] = $like; }
}

$from = "FROM bookings b JOIN rooms r ON r.id = b.room_id JOIN users u ON u.id = b.user_id";
$group_by = "b.title, b.room_id, r.name, r.color, b.user_id, u.full_name, DAYOFWEEK(b.start_time), b.status, b.is_deleted";

// แท็บ: deleted = ถูกลบ (ถังขยะ) / rejected = ถูกปฏิเสธ (ยังไม่ถูกลบ)
$tab_where = [
    'deleted'  => "b.is_deleted = 1",
    'rejected' => "b.is_deleted = 0 AND b.status = 'rejected'",
];

/* ---------- จำนวนในแต่ละแท็บ ---------- */
$counts = [];
foreach ($tab_where as $key => $cond) {
    $w = array_merge([$cond], $common);
    $st = $pdo->prepare("SELECT COUNT(*) FROM (SELECT 1 {$from} WHERE " . implode(" AND ", $w) . " GROUP BY {$group_by}) t");
    $st->execute($common_params);
    $counts[$key] = (int)$st->fetchColumn();
}

$tab = hs_get('tab', $counts['deleted'] > 0 ? 'deleted' : 'rejected');
if (!isset($tab_where[$tab])) { $tab = 'deleted'; }

$total_items = $counts[$tab];
$total_pages = max(1, (int)ceil($total_items / $per_page));
if ($current_page > $total_pages) { $current_page = $total_pages; }
$offset = ($current_page - 1) * $per_page;

/* ---------- รายการของแท็บที่เปิดอยู่ ---------- */
$w = array_merge([$tab_where[$tab]], $common);
$st = $pdo->prepare("
    SELECT MIN(b.id) AS id, b.title, b.room_id, r.name AS room_name, r.color AS room_color,
           u.full_name AS user_name, b.status, b.is_deleted,
           MIN(b.start_time) AS s, MAX(b.end_time) AS e,
           COUNT(*) AS sessions,
           GROUP_CONCAT(b.id ORDER BY b.id) AS booking_ids,
           MAX(b.updated_at) AS changed_at,
           MAX(EXISTS(SELECT 1 FROM teaching_reports t WHERE t.booking_id = b.id)) AS in_report
    {$from}
    WHERE " . implode(" AND ", $w) . "
    GROUP BY {$group_by}
    ORDER BY MAX(b.updated_at) DESC, MIN(b.id) DESC
    LIMIT {$per_page} OFFSET {$offset}");
$st->execute($common_params);
$items = $st->fetchAll(PDO::FETCH_ASSOC);

$first_no = $total_items > 0 ? $offset + 1 : 0;
$last_no = min($offset + $per_page, $total_items);
?>

<style>
.hs-page { --ink:#1c2733; --muted:#667587; --line:#e3e8ee; --navy:#123456; --brand:#003399;
    --bar-del:#8a97a6; --bar-rej:#d6455a; --warn-bg:#fff3d1; --warn-fg:#7a5200;
    color:var(--ink); }
.hs-head { margin-bottom:16px; }
.hs-head h1 { font-size:1.65rem; font-weight:500; margin:0; }
.hs-head p { margin:2px 0 0; color:var(--muted); }
.hs-panel { background:#fff; border:1px solid var(--line); border-radius:14px; box-shadow:0 1px 2px rgba(18,52,86,.04); }
.hs-tabs { display:flex; gap:2px; padding:0 14px; border-bottom:1px solid var(--line); overflow-x:auto; }
.hs-tab { display:inline-flex; align-items:center; gap:8px; padding:14px 12px 12px; border-bottom:3px solid transparent; color:var(--muted); text-decoration:none; font-weight:500; white-space:nowrap; }
.hs-tab:hover { color:var(--ink); }
.hs-tab.is-active { color:var(--ink); border-bottom-color:var(--brand); }
.hs-count { min-width:24px; padding:0 8px; border-radius:999px; background:#eef1f5; color:var(--muted); font-size:.8rem; line-height:22px; text-align:center; }
.hs-tab.is-active .hs-count { background:var(--brand); color:#fff; }
.hs-filters { display:flex; flex-wrap:wrap; align-items:center; gap:10px; padding:14px 18px; background:#fafbfc; border-bottom:1px solid var(--line); }
.hs-filters .hs-search { flex:1 1 240px; min-width:200px; }
.hs-filters .form-select { width:auto; max-width:300px; }
.hs-range { display:inline-flex; align-items:center; gap:6px; }
.hs-note { padding:10px 18px; font-size:.88rem; color:var(--muted); background:#f6f8fb; border-bottom:1px solid var(--line); }
.hs-toolbar { display:flex; justify-content:space-between; align-items:center; padding:10px 18px; font-size:.9rem; color:var(--muted); border-bottom:1px solid var(--line); }
.hs-rows { list-style:none; margin:0; padding:0; }
.hs-row { display:grid; grid-template-columns:32px minmax(0,1.7fr) minmax(0,1fr) 150px 130px auto; grid-template-areas:"check main who period changed actions"; gap:16px; align-items:center; padding:14px 18px; border-bottom:1px solid var(--line); box-shadow:inset 3px 0 0 var(--bar); }
.hs-row.is-deleted { --bar:var(--bar-del); }
.hs-row.is-rejected { --bar:var(--bar-rej); }
.hs-row:hover { background:#f7f9fc; }
.hs-row.is-selected { background:#eef3ff; }
.hs-check { grid-area:check; margin:0; display:flex; }
.hs-main { grid-area:main; min-width:0; }
.hs-title { font-weight:500; font-size:1.02rem; overflow-wrap:anywhere; }
.hs-sub { font-size:.88rem; color:var(--muted); overflow-wrap:anywhere; }
.hs-dot { display:inline-block; width:9px; height:9px; border-radius:50%; margin-right:6px; }
.hs-flags { display:flex; flex-wrap:wrap; gap:6px; margin-top:7px; }
.hs-chip { display:inline-flex; align-items:center; gap:6px; padding:1px 8px; font-size:.78rem; border:1px solid var(--line); background:#f6f8fa; color:var(--muted); border-radius:6px; }
.hs-chip--warn { background:var(--warn-bg); border-color:#f1d78a; color:var(--warn-fg); }
.hs-who { grid-area:who; min-width:0; font-size:.92rem; overflow-wrap:anywhere; }
.hs-period { grid-area:period; font-size:.9rem; }
.hs-changed { grid-area:changed; font-size:.86rem; color:var(--muted); }
.hs-actions { grid-area:actions; display:flex; justify-content:flex-end; align-items:center; gap:6px; }
.hs-empty { padding:56px 18px; text-align:center; color:var(--muted); }
.hs-empty h2 { font-size:1.15rem; font-weight:500; color:var(--ink); margin-bottom:6px; }
.hs-bulk { position:sticky; bottom:0; display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:12px 18px; background:var(--navy); color:#fff; border-radius:0 0 14px 14px; }
.hs-bulk[hidden] { display:none; }
.hs-bulk .grow { flex:1; }
.hs-pager { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:10px; padding:14px 18px; }
.hs-pager .pagination { margin:0; }
.hs-row .btn:focus-visible { outline:2px solid var(--brand); outline-offset:2px; }
@media (max-width: 1199.98px) {
    .hs-row { grid-template-columns:28px 1fr; grid-template-areas:"check main" ". who" ". period" ". changed" ". actions"; gap:6px 12px; }
    .hs-actions { justify-content:flex-start; margin-top:6px; }
}
@media (prefers-reduced-motion: reduce) { .hs-page * { transition:none !important; } }
</style>

<div class="container-fluid px-4 py-4 hs-page">

    <header class="hs-head">
        <h1>ประวัติการจอง</h1>
        <p>รายการที่ถูกลบและรายการที่ถูกปฏิเสธ กู้คืนกลับเป็น "รออนุมัติ" หรือลบถาวรได้ที่นี่</p>
    </header>

    <section class="hs-panel">
        <nav class="hs-tabs" aria-label="ประเภทรายการ">
            <a class="hs-tab <?php echo $tab === 'deleted' ? 'is-active' : ''; ?>" href="<?php echo hs_h(hs_url(['tab' => 'deleted'], ['page'])); ?>" <?php echo $tab === 'deleted' ? 'aria-current="page"' : ''; ?>>
                <i class="fas fa-trash-can"></i> ถูกลบ <span class="hs-count"><?php echo $counts['deleted']; ?></span>
            </a>
            <a class="hs-tab <?php echo $tab === 'rejected' ? 'is-active' : ''; ?>" href="<?php echo hs_h(hs_url(['tab' => 'rejected'], ['page'])); ?>" <?php echo $tab === 'rejected' ? 'aria-current="page"' : ''; ?>>
                <i class="fas fa-ban"></i> ถูกปฏิเสธ <span class="hs-count"><?php echo $counts['rejected']; ?></span>
            </a>
        </nav>

        <form method="GET" id="hsFilters" class="hs-filters">
            <input type="hidden" name="tab" value="<?php echo hs_h($tab); ?>">
            <div class="hs-search">
                <input type="search" name="q" class="form-control form-control-sm" value="<?php echo hs_h($search); ?>" placeholder="ค้นหาหัวข้อ ผู้จอง อาจารย์ หรือห้อง" aria-label="ค้นหา">
            </div>
            <select name="room_id" class="form-select form-select-sm" aria-label="ห้อง">
                <option value="all">ทุกห้อง</option>
                <?php foreach ($rooms as $rm): ?>
                    <option value="<?php echo (int)$rm['id']; ?>" <?php echo ($filter_room == $rm['id']) ? 'selected' : ''; ?>><?php echo hs_h($rm['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <div class="hs-range">
                <input type="date" name="start_date" class="form-control form-control-sm" value="<?php echo hs_h($filter_start); ?>" aria-label="ตั้งแต่วันที่">
                <span class="text-muted">ถึง</span>
                <input type="date" name="end_date" class="form-control form-control-sm" value="<?php echo hs_h($filter_end); ?>" aria-label="ถึงวันที่">
            </div>
            <?php if ($has_filters): ?>
                <a href="<?php echo hs_h(hs_url([], ['q', 'room_id', 'start_date', 'end_date', 'page'])); ?>" class="btn btn-link btn-sm">ล้างตัวกรอง</a>
            <?php endif; ?>
        </form>

        <?php if ($tab === 'deleted'): ?>
            <div class="hs-note"><i class="fas fa-circle-info me-1"></i>รายการที่ลบจากหน้าจัดการการจองหรือที่ผู้ใช้ลบเองจะอยู่ที่นี่ กู้คืนแล้วจะกลับเป็น "รออนุมัติ" ทุกรายการ แม้ก่อนลบจะเคยอนุมัติแล้ว</div>
        <?php else: ?>
            <div class="hs-note"><i class="fas fa-circle-info me-1"></i>กู้คืนรายการที่ถูกปฏิเสธจะเปลี่ยนเป็น "รออนุมัติ" เพื่อให้พิจารณาใหม่</div>
        <?php endif; ?>

        <?php if (empty($items)): ?>
            <div class="hs-empty">
                <?php if ($has_filters): ?>
                    <h2>ไม่พบรายการตามตัวกรอง</h2>
                    <p>ลองเปลี่ยนคำค้น ห้อง หรือช่วงวันที่ หรือล้างตัวกรอง</p>
                    <a class="btn btn-outline-primary btn-sm" href="<?php echo hs_h(hs_url([], ['q', 'room_id', 'start_date', 'end_date', 'page'])); ?>">ล้างตัวกรอง</a>
                <?php elseif ($tab === 'deleted'): ?>
                    <h2>ไม่มีรายการที่ถูกลบ</h2>
                    <p>เมื่อมีการลบรายการจอง จะแสดงที่นี่เพื่อให้กู้คืนได้</p>
                <?php else: ?>
                    <h2>ไม่มีรายการที่ถูกปฏิเสธ</h2>
                    <p>รายการที่ปฏิเสธจากหน้าจัดการการจองจะแสดงที่นี่</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="hs-toolbar">
                <label class="d-flex align-items-center gap-2 mb-0">
                    <input class="form-check-input mt-0" type="checkbox" id="selectAll"> เลือกทั้งหน้า
                </label>
                <span>แสดง <?php echo $first_no; ?>-<?php echo $last_no; ?> จาก <?php echo $total_items; ?> รายการ</span>
            </div>

            <ul class="hs-rows" id="historyList">
            <?php foreach ($items as $it):
                $s = strtotime($it['s']); $e = strtotime($it['e']);
                $in_report = ((int)$it['in_report'] === 1);
                $changed_ts = !empty($it['changed_at']) ? strtotime($it['changed_at']) : null;
            ?>
                <li class="hs-row is-<?php echo $tab; ?>" data-ids="<?php echo hs_h($it['booking_ids']); ?>" data-in-report="<?php echo $in_report ? '1' : '0'; ?>" data-title="<?php echo hs_h($it['title']); ?>">
                    <label class="hs-check"><input class="form-check-input hs-checkbox" type="checkbox" aria-label="เลือก <?php echo hs_h($it['title']); ?>"></label>

                    <div class="hs-main">
                        <div class="hs-title"><?php echo hs_h($it['title']); ?></div>
                        <div class="hs-sub"><span class="hs-dot" style="background:<?php echo hs_h(hs_color($it['room_color'])); ?>"></span><?php echo hs_h($it['room_name']); ?></div>
                        <div class="hs-flags">
                            <span class="hs-chip"><i class="far fa-calendar-check"></i> <?php echo (int)$it['sessions']; ?> ครั้ง</span>
                            <?php if ($tab === 'deleted'): ?>
                                <span class="hs-chip" title="สถานะของรายการก่อนถูกลบ">ก่อนลบ: <?php echo hs_h($status_names[$it['status']] ?? $it['status']); ?></span>
                            <?php endif; ?>
                            <?php if ($in_report): ?>
                                <span class="hs-chip hs-chip--warn" title="ลบถาวรไม่ได้จนกว่าจะเอาออกจากรายงานการสอน"><i class="fas fa-link"></i> อยู่ในรายงานการสอน</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="hs-who"><i class="far fa-user me-1 text-muted"></i><?php echo hs_h($it['user_name']); ?></div>
                    <div class="hs-period"><?php echo hs_h(hs_period($s, $e)); ?></div>
                    <div class="hs-changed"><?php echo $changed_ts ? ($tab === 'deleted' ? 'ลบเมื่อ ' : 'ปฏิเสธเมื่อ ') . hs_h(hs_date($changed_ts)) : ''; ?></div>

                    <div class="hs-actions">
                        <button type="button" class="btn btn-success btn-sm hs-act" data-action="restore"><i class="fas fa-rotate-left me-1"></i>กู้คืน</button>
                        <div class="dropdown">
                            <button type="button" class="btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false" aria-label="เมนูเพิ่มเติม"><i class="fas fa-ellipsis-vertical"></i></button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php if ($in_report): ?>
                                    <li><button type="button" class="dropdown-item" disabled title="เอาออกจากรายงานการสอนก่อน"><i class="fas fa-trash-alt fa-fw me-2"></i>ลบถาวรไม่ได้ (อยู่ในรายงาน)</button></li>
                                <?php else: ?>
                                    <li><button type="button" class="dropdown-item text-danger hs-act" data-action="perm_delete"><i class="fas fa-trash-alt fa-fw me-2"></i>ลบถาวร</button></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
            </ul>

            <div class="hs-bulk" id="hsBulk" hidden>
                <span><strong id="hsSelCount">0</strong> รายการที่เลือก</span>
                <span class="grow"></span>
                <button type="button" class="btn btn-success btn-sm" data-bulk="restore">กู้คืนที่เลือก</button>
                <button type="button" class="btn btn-danger btn-sm" data-bulk="perm_delete">ลบถาวรที่เลือก</button>
                <button type="button" class="btn btn-link btn-sm text-white" id="hsClear">ล้างที่เลือก</button>
            </div>

            <?php if ($total_pages > 1): ?>
            <div class="hs-pager">
                <span class="text-muted small">หน้า <?php echo $current_page; ?> จาก <?php echo $total_pages; ?></span>
                <nav aria-label="เปลี่ยนหน้า">
                    <ul class="pagination pagination-sm">
                        <li class="page-item <?php echo $current_page <= 1 ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo hs_h(hs_url(['page' => $current_page - 1])); ?>">ก่อนหน้า</a></li>
                        <?php
                        $shown = [];
                        for ($p = 1; $p <= $total_pages; $p++) {
                            if ($p === 1 || $p === $total_pages || abs($p - $current_page) <= 2) { $shown[] = $p; }
                        }
                        $prev_p = 0;
                        foreach ($shown as $p) {
                            if ($p - $prev_p > 1) { echo '<li class="page-item disabled"><span class="page-link">…</span></li>'; }
                            echo '<li class="page-item ' . ($p === $current_page ? 'active' : '') . '"><a class="page-link" href="' . hs_h(hs_url(['page' => $p])) . '">' . $p . '</a></li>';
                            $prev_p = $p;
                        }
                        ?>
                        <li class="page-item <?php echo $current_page >= $total_pages ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo hs_h(hs_url(['page' => $current_page + 1])); ?>">ถัดไป</a></li>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
$(function () {
    const API = '../api/update_booking_status.php';
    const parseIds = s => String(s).split(',').map(n => parseInt(n, 10)).filter(n => n > 0);
    const netError = () => Swal.fire('ทำรายการไม่สำเร็จ', 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ลองใหม่อีกครั้ง', 'error');

    function run(action, ids, skipped) {
        ids = Array.from(new Set(ids));
        if (!ids.length) {
            Swal.fire('ทำรายการไม่ได้', 'รายการที่เลือกอยู่ในรายงานการสอนทั้งหมด ลบถาวรไม่ได้ ให้เอาออกจากรายงานก่อน', 'info');
            return;
        }
        const isRestore = action === 'restore';
        let text = isRestore
            ? 'กู้คืน ' + ids.length + ' รายการ จะกลับเป็น "รออนุมัติ" และไปแสดงในหน้าจัดการการจอง'
            : 'ลบถาวร ' + ids.length + ' รายการ ข้อมูลจะหายจากระบบและกู้คืนไม่ได้';
        if (skipped > 0) { text += ' (ข้าม ' + skipped + ' รายการที่อยู่ในรายงานการสอน)'; }

        Swal.fire({
            title: isRestore ? 'ยืนยันการกู้คืน' : 'ยืนยันการลบถาวร',
            text: text, icon: isRestore ? 'question' : 'warning',
            showCancelButton: true, focusCancel: !isRestore,
            confirmButtonText: isRestore ? 'กู้คืน' : 'ลบถาวร',
            confirmButtonColor: isRestore ? '#198754' : '#dc3545',
            cancelButtonText: 'ไม่ทำรายการ'
        }).then(function (r) {
            if (!r.isConfirmed) { return; }
            Swal.fire({ title: 'กำลังดำเนินการ…', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            $.ajax({
                url: API, type: 'POST', dataType: 'json', data: { booking_ids: ids, action: action },
                success: function (res) {
                    if (res.success) {
                        Swal.fire({ icon: 'success', title: isRestore ? 'กู้คืนแล้ว' : 'ลบถาวรแล้ว', text: res.message || '', timer: 1300, showConfirmButton: false })
                            .then(() => location.reload());
                    } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
                },
                error: netError
            });
        });
    }

    $('#historyList').on('click', '.hs-act', function () {
        const $row = $(this).closest('.hs-row');
        const action = $(this).data('action');
        run(action, parseIds($row.data('ids')), 0);
    });

    /* ---------- เลือกหลายรายการ ---------- */
    function updateBulk() {
        const $all = $('.hs-checkbox'), $on = $all.filter(':checked'), n = $on.length;
        $('.hs-row').removeClass('is-selected');
        $on.closest('.hs-row').addClass('is-selected');
        $('#hsSelCount').text(n);
        $('#hsBulk').prop('hidden', n === 0);
        $('#selectAll').prop('checked', n > 0 && n === $all.length).prop('indeterminate', n > 0 && n < $all.length);
    }
    $('#selectAll').on('change', function () { $('.hs-checkbox').prop('checked', this.checked); updateBulk(); });
    $('#historyList').on('change', '.hs-checkbox', updateBulk);
    $('#hsClear').on('click', function () { $('.hs-checkbox, #selectAll').prop('checked', false); updateBulk(); });
    $('#hsBulk').on('click', '[data-bulk]', function () {
        const action = $(this).data('bulk');
        let ids = [], skipped = 0;
        $('.hs-checkbox:checked').closest('.hs-row').each(function () {
            const inReport = String($(this).data('in-report')) === '1';
            if (action === 'perm_delete' && inReport) { skipped++; return; }
            ids = ids.concat(parseIds($(this).data('ids')));
        });
        run(action, ids, skipped);
    });

    /* ---------- ตัวกรอง ---------- */
    const form = document.getElementById('hsFilters');
    $('#hsFilters select, #hsFilters input[type=date]').on('change', function () { form.submit(); });
    $('#hsFilters input[type=search]').on('search', function () { form.submit(); });
});
</script>
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';
require_admin();

$page_title = "จัดการผู้ใช้งาน";
include 'layouts/admin_header.php';

/* =====================================================================
   ตั้งค่า: โดเมนอีเมลภายในองค์กร (ใช้ติดป้าย "อีเมลภายนอก" ให้คำขอสมัคร)
   ===================================================================== */
$internal_domains = ['mahidol.ac.th', 'mahidol.edu'];

/* =====================================================================
   Helpers (prefix um_)
   ===================================================================== */
function um_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function um_get($key, $default = '') {
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? trim($_GET[$key]) : $default;
}

function um_url(array $set = [], array $unset = []) {
    $q = $_GET;
    foreach ($unset as $k) { unset($q[$k]); }
    foreach ($set as $k => $v) {
        if ($v === null || $v === '') { unset($q[$k]); } else { $q[$k] = $v; }
    }
    return '?' . http_build_query($q);
}

function um_date_short($ts) {
    static $m = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.', 7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    return date('j', $ts) . ' ' . $m[(int)date('n', $ts)] . ' ' . substr((string)(date('Y', $ts) + 543), -2);
}

// ตัวอักษรแรกของชื่อ (ข้ามสระนำหน้าแบบ เ แ โ ใ ไ)
function um_initial($name) {
    $name = preg_replace('/^[เแโใไ\s]+/u', '', (string)$name);
    return preg_match('/\p{L}/u', $name, $mm) ? $mm[0] : '?';
}

function um_is_internal($email, array $domains) {
    $at = strrpos((string)$email, '@');
    if ($at === false) { return false; }
    $d = strtolower(substr($email, $at + 1));
    foreach ($domains as $x) {
        if ($d === $x || substr($d, -(strlen($x) + 1)) === '.' . $x) { return true; }
    }
    return false;
}

/* =====================================================================
   1) รับค่าตัวกรอง
   ===================================================================== */
$role_names = ['admin' => 'ผู้ดูแลระบบ', 'officer' => 'เจ้าหน้าที่ส่วนงาน', 'user' => 'ผู้ใช้ทั่วไป'];
$role_desc = [
    'admin'   => 'จัดการผู้ใช้ ห้อง การจอง และรายงานได้ทั้งหมด',
    'officer' => 'อนุมัติและจัดการการจองของผู้ใช้ในส่วนงานเดียวกัน',
    'user'    => 'จองห้องและจัดการคำขอของตัวเอง',
];
$status_names = ['pending' => 'รออนุมัติ', 'approved' => 'อนุมัติแล้ว', 'inactive' => 'ไม่ใช้งาน', 'suspended' => 'ถูกระงับ'];

$roles_present = $pdo->query("SELECT DISTINCT role FROM users ORDER BY role")->fetchAll(PDO::FETCH_COLUMN);
$role_totals = $pdo->query("SELECT role, COUNT(*) FROM users GROUP BY role")->fetchAll(PDO::FETCH_KEY_PAIR);
$departments = $pdo->query("SELECT DISTINCT department FROM users WHERE department IS NOT NULL AND department <> '' ORDER BY department")->fetchAll(PDO::FETCH_COLUMN);

$filter_role = um_get('role', 'all');
if ($filter_role !== 'all' && !in_array($filter_role, $roles_present, true)) { $filter_role = 'all'; }
$filter_dept = um_get('dept', 'all');
if ($filter_dept === '') { $filter_dept = 'all'; }
$search = um_get('q');
if ($search !== '') { $search = function_exists('mb_substr') ? mb_substr($search, 0, 100) : substr($search, 0, 100); }
$per_page = (int)um_get('per_page', '25');
if (!in_array($per_page, [10, 25, 50], true)) { $per_page = 25; }
$sort_options = ['newest' => 'สมัครล่าสุดก่อน', 'name' => 'ชื่อ ก-ฮ', 'most_bookings' => 'จองมากที่สุดก่อน'];
$sort = um_get('sort', 'newest');
if (!isset($sort_options[$sort])) { $sort = 'newest'; }
$current_page = max(1, (int)um_get('page', '1'));
$has_filters = ($filter_role !== 'all' || $filter_dept !== 'all' || $search !== '');

/* =====================================================================
   2) จำนวนในแต่ละแท็บ แล้วกำหนดแท็บเริ่มต้น
   ===================================================================== */
$where = []; $params = [];
if ($filter_role !== 'all') { $where[] = "u.role = ?"; $params[] = $filter_role; }
if ($filter_dept !== 'all') { $where[] = "u.department = ?"; $params[] = $filter_dept; }
if ($search !== '') {
    $like = '%' . addcslashes($search, '\\%_') . '%';
    $where[] = "(u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR u.department LIKE ?)";
    for ($k = 0; $k < 4; $k++) { $params[] = $like; }
}
$base_sql = $where ? "WHERE " . implode(" AND ", $where) : "";

$cs = $pdo->prepare("SELECT u.status, COUNT(*) AS c FROM users u {$base_sql} GROUP BY u.status");
$cs->execute($params);
$counts = ['pending' => 0, 'approved' => 0, 'inactive' => 0, 'suspended' => 0];
foreach ($cs->fetchAll(PDO::FETCH_ASSOC) as $r) {
    if (isset($counts[$r['status']])) { $counts[$r['status']] = (int)$r['c']; }
}
$counts['all'] = array_sum($counts);

$filter_status = um_get('status', $counts['pending'] > 0 ? 'pending' : 'all');
if (!in_array($filter_status, ['pending', 'approved', 'inactive', 'suspended', 'all'], true)) { $filter_status = 'all'; }

$total_items = $counts[$filter_status];
$total_pages = max(1, (int)ceil($total_items / $per_page));
if ($current_page > $total_pages) { $current_page = $total_pages; }
$offset = ($current_page - 1) * $per_page;

/* =====================================================================
   3) รายการผู้ใช้ของหน้านี้ (ไม่ดึงรหัสผ่านมาเลย)
   ===================================================================== */
$list_where = $where; $list_params = $params;
if ($filter_status !== 'all') { $list_where[] = "u.status = ?"; $list_params[] = $filter_status; }
$list_sql = $list_where ? "WHERE " . implode(" AND ", $list_where) : "";
$order_map = [
    'newest'        => "u.created_at DESC, u.id DESC",
    'name'          => "u.full_name ASC",
    'most_bookings' => "booking_active DESC, u.full_name ASC",
];
$stmt = $pdo->prepare("
    SELECT u.id, u.full_name, u.username, u.email, u.department, u.role, u.status, u.created_at,
           COUNT(b.id) AS booking_total,
           COALESCE(SUM(b.is_deleted = 0), 0) AS booking_active,
           COALESCE(SUM(b.is_deleted = 0 AND b.status = 'pending'), 0) AS booking_pending,
           MAX(CASE WHEN b.is_deleted = 0 THEN b.start_time END) AS last_booking
    FROM users u
    LEFT JOIN bookings b ON b.user_id = u.id
    {$list_sql}
    GROUP BY u.id, u.full_name, u.username, u.email, u.department, u.role, u.status, u.created_at
    ORDER BY {$order_map[$sort]}
    LIMIT {$per_page} OFFSET {$offset}
");
$stmt->execute($list_params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$my_id = (int)$_SESSION['user_id'];
$now_ts = time();
$first_no = $total_items > 0 ? $offset + 1 : 0;
$last_no = min($offset + $per_page, $total_items);
$pending_on_page = 0;
foreach ($users as $u) { if ($u['status'] === 'pending' && (int)$u['id'] !== $my_id) { $pending_on_page++; } }
?>

<style>
.um-page { --um-ink:#1c2733; --um-muted:#667587; --um-line:#e3e8ee; --um-navy:#123456; --um-brand:#003399;
    --um-pending-bg:#fff3d1; --um-pending-fg:#7a5200; --um-pending-bar:#e0a100;
    --um-approved-bg:#dcf2e5; --um-approved-fg:#14613a; --um-approved-bar:#2e9d62;
    --um-inactive-bg:#e8ecf1; --um-inactive-fg:#475466; --um-inactive-bar:#9aa7b6;
    --um-suspended-bg:#fde3e7; --um-suspended-fg:#9a1b30; --um-suspended-bar:#d6455a;
    --um-info:#2c5fb3; color:var(--um-ink); }
.um-head { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-end; gap:12px; margin-bottom:16px; }
.um-head h1 { font-size:1.65rem; font-weight:500; margin:0; }
.um-head p { margin:2px 0 0; color:var(--um-muted); }
.um-panel { background:#fff; border:1px solid var(--um-line); border-radius:14px; box-shadow:0 1px 2px rgba(18,52,86,.04); }
.um-tabs { display:flex; gap:2px; padding:0 14px; border-bottom:1px solid var(--um-line); overflow-x:auto; }
.um-tab { display:inline-flex; align-items:center; gap:8px; padding:14px 12px 12px; border-bottom:3px solid transparent; color:var(--um-muted); text-decoration:none; font-weight:500; white-space:nowrap; }
.um-tab:hover { color:var(--um-ink); }
.um-tab.is-active { color:var(--um-ink); border-bottom-color:var(--um-brand); }
.um-count { min-width:24px; padding:0 8px; border-radius:999px; background:#eef1f5; color:var(--um-muted); font-size:.8rem; line-height:22px; text-align:center; }
.um-tab.is-active .um-count { background:var(--um-brand); color:#fff; }
.um-tab--pending .um-count.has-items { background:var(--um-pending-bg); color:var(--um-pending-fg); }
.um-tab--pending.is-active .um-count.has-items { background:var(--um-pending-bar); color:#fff; }
.um-filters { display:flex; flex-wrap:wrap; align-items:center; gap:10px; padding:14px 18px; background:#fafbfc; border-bottom:1px solid var(--um-line); }
.um-filters .um-search { flex:1 1 240px; min-width:200px; }
.um-filters .form-select { width:auto; max-width:240px; }
.um-toolbar { display:flex; justify-content:space-between; align-items:center; padding:10px 18px; font-size:.9rem; color:var(--um-muted); border-bottom:1px solid var(--um-line); }
.um-rows { list-style:none; margin:0; padding:0; }
.um-row { display:grid; grid-template-columns:32px minmax(0,1.5fr) minmax(0,1fr) 158px 112px 150px auto; grid-template-areas:"check main org role status activity actions"; gap:16px; align-items:center; padding:14px 18px; border-bottom:1px solid var(--um-line); box-shadow:inset 3px 0 0 var(--row-bar, transparent); }
.um-row:hover { background:#f7f9fc; }
.um-row.is-selected { background:#eef3ff; }
.um-row.is-pending { --row-bar:var(--um-pending-bar); }
.um-row.is-approved { --row-bar:var(--um-approved-bar); }
.um-row.is-inactive { --row-bar:var(--um-inactive-bar); }
.um-row.is-suspended { --row-bar:var(--um-suspended-bar); }
.um-check { grid-area:check; margin:0; display:flex; min-height:1px; }
.um-main { grid-area:main; min-width:0; display:flex; gap:12px; align-items:center; }
.um-avatar { flex:0 0 42px; width:42px; height:42px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:600; font-size:1.05rem; background:#e8ecf1; color:#475466; }
.um-avatar.role-admin { background:var(--um-navy); color:#fff; }
.um-avatar.role-officer { background:#dbe6fb; color:#1f4a9a; }
.um-name { font-weight:500; overflow-wrap:anywhere; }
.um-sub { font-size:.86rem; color:var(--um-muted); overflow-wrap:anywhere; }
.um-org { grid-area:org; min-width:0; font-size:.92rem; }
.um-org .dept { overflow-wrap:anywhere; }
.um-flags { display:flex; flex-wrap:wrap; gap:6px; margin-top:6px; }
.um-chip { display:inline-flex; align-items:center; gap:6px; padding:1px 8px; border-radius:6px; font-size:.78rem; border:1px solid var(--um-line); background:#f6f8fa; color:var(--um-muted); }
.um-chip--warn { background:var(--um-pending-bg); border-color:#f1d78a; color:var(--um-pending-fg); }
.um-chip--info { background:#e9f0fc; border-color:#c3d4f1; color:var(--um-info); }
.um-role { grid-area:role; }
.um-status { grid-area:status; }
.um-pill { display:inline-flex; align-items:center; gap:7px; padding:3px 11px; border-radius:999px; font-size:.82rem; font-weight:500; white-space:nowrap; }
.um-pill::before { content:""; width:7px; height:7px; border-radius:50%; background:currentColor; }
.um-pill--pending { background:var(--um-pending-bg); color:var(--um-pending-fg); }
.um-pill--approved { background:var(--um-approved-bg); color:var(--um-approved-fg); }
.um-pill--inactive { background:var(--um-inactive-bg); color:var(--um-inactive-fg); }
.um-pill--suspended { background:var(--um-suspended-bg); color:var(--um-suspended-fg); }
.um-activity { grid-area:activity; font-size:.88rem; }
.um-activity .muted { color:var(--um-muted); }
.um-actions { grid-area:actions; display:flex; justify-content:flex-end; align-items:center; gap:6px; flex-wrap:wrap; }
.um-empty { padding:56px 18px; text-align:center; color:var(--um-muted); }
.um-empty h2 { font-size:1.15rem; font-weight:500; color:var(--um-ink); margin-bottom:6px; }
.um-bulk { position:sticky; bottom:0; display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:12px 18px; background:var(--um-navy); color:#fff; border-radius:0 0 14px 14px; }
.um-bulk[hidden] { display:none; }
.um-bulk .grow { flex:1; }
.um-pager { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:10px; padding:14px 18px; }
.um-pager .pagination { margin:0; }
.um-role-help { font-size:.85rem; color:var(--um-muted); margin-top:4px; }
.um-row .btn:focus-visible, .um-row select:focus-visible { outline:2px solid var(--um-brand); outline-offset:2px; }
@media (max-width: 1199.98px) {
    .um-row { grid-template-columns:28px minmax(0,1fr) 150px; grid-template-areas:"check main main" ". org org" ". role status" ". activity activity" ". actions actions"; gap:10px 12px; }
    .um-actions { justify-content:flex-start; }
}
@media (prefers-reduced-motion: reduce) { .um-page * { transition:none !important; } }
</style>

<div class="container-fluid px-4 py-4 um-page">

    <header class="um-head">
        <div>
            <h1>จัดการผู้ใช้งาน</h1>
            <p>
                ทั้งหมด <?php echo array_sum($role_totals); ?> บัญชี:
                <?php
                $parts = [];
                foreach ($role_totals as $rk => $rc) { $parts[] = ($role_names[$rk] ?? ucfirst($rk)) . ' ' . (int)$rc . ' คน'; }
                echo um_h(implode(' / ', $parts));
                ?>
            </p>
        </div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="fas fa-user-plus me-2"></i>เพิ่มผู้ใช้งาน
        </button>
    </header>

    <section class="um-panel">
        <nav class="um-tabs" aria-label="กรองตามสถานะ">
            <?php foreach (['pending' => 'รออนุมัติ', 'approved' => 'อนุมัติแล้ว', 'inactive' => 'ไม่ใช้งาน', 'suspended' => 'ถูกระงับ', 'all' => 'ทั้งหมด'] as $key => $label): ?>
                <a class="um-tab um-tab--<?php echo $key; ?> <?php echo $filter_status === $key ? 'is-active' : ''; ?>"
                   href="<?php echo um_h(um_url(['status' => $key], ['page'])); ?>"
                   <?php echo $filter_status === $key ? 'aria-current="page"' : ''; ?>>
                    <?php echo $label; ?>
                    <span class="um-count <?php echo ($key === 'pending' && $counts[$key] > 0) ? 'has-items' : ''; ?>"><?php echo $counts[$key]; ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <form method="GET" id="umFilters" class="um-filters">
            <input type="hidden" name="status" value="<?php echo um_h($filter_status); ?>">
            <div class="um-search">
                <input type="search" name="q" class="form-control form-control-sm" value="<?php echo um_h($search); ?>" placeholder="ค้นหาชื่อ ชื่อผู้ใช้ อีเมล หรือส่วนงาน" aria-label="ค้นหา">
            </div>
            <select name="role" class="form-select form-select-sm" aria-label="สิทธิ์">
                <option value="all">ทุกสิทธิ์</option>
                <?php foreach ($roles_present as $rp): ?>
                    <option value="<?php echo um_h($rp); ?>" <?php echo $filter_role === $rp ? 'selected' : ''; ?>><?php echo um_h($role_names[$rp] ?? ucfirst($rp)); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="dept" class="form-select form-select-sm" aria-label="ส่วนงาน">
                <option value="all">ทุกส่วนงาน</option>
                <?php foreach ($departments as $d): ?>
                    <option value="<?php echo um_h($d); ?>" <?php echo $filter_dept === $d ? 'selected' : ''; ?>><?php echo um_h($d); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="sort" class="form-select form-select-sm" aria-label="เรียงลำดับ">
                <?php foreach ($sort_options as $sk => $sl): ?>
                    <option value="<?php echo $sk; ?>" <?php echo $sort === $sk ? 'selected' : ''; ?>><?php echo $sl; ?></option>
                <?php endforeach; ?>
            </select>
            <select name="per_page" class="form-select form-select-sm" aria-label="จำนวนต่อหน้า">
                <?php foreach ([10, 25, 50] as $pp): ?>
                    <option value="<?php echo $pp; ?>" <?php echo $per_page === $pp ? 'selected' : ''; ?>><?php echo $pp; ?> รายการ/หน้า</option>
                <?php endforeach; ?>
            </select>
            <?php if ($has_filters): ?>
                <a href="<?php echo um_h(um_url([], ['q', 'role', 'dept', 'page'])); ?>" class="btn btn-link btn-sm">ล้างตัวกรอง</a>
            <?php endif; ?>
        </form>

        <?php if (empty($users)): ?>
            <div class="um-empty">
                <?php if ($has_filters): ?>
                    <h2>ไม่พบผู้ใช้ตามตัวกรอง</h2>
                    <p>ลองเปลี่ยนคำค้น สิทธิ์ หรือส่วนงาน หรือล้างตัวกรองเพื่อดูทั้งหมด</p>
                    <a class="btn btn-outline-primary btn-sm" href="<?php echo um_h(um_url([], ['q', 'role', 'dept', 'page'])); ?>">ล้างตัวกรอง</a>
                <?php elseif ($filter_status === 'pending'): ?>
                    <h2>ไม่มีบัญชีที่รออนุมัติ</h2>
                    <p>ตรวจครบทุกคำขอสมัครแล้ว ดูบัญชีที่ใช้งานอยู่ได้ที่แท็บ "อนุมัติแล้ว"</p>
                    <a class="btn btn-outline-primary btn-sm" href="<?php echo um_h(um_url(['status' => 'approved'], ['page'])); ?>">ดูบัญชีที่อนุมัติแล้ว</a>
                <?php else: ?>
                    <h2>ยังไม่มีบัญชีในสถานะนี้</h2>
                    <p>เลือกแท็บอื่น หรือเพิ่มผู้ใช้งานใหม่</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="um-toolbar">
                <?php if ($pending_on_page > 0): ?>
                    <label class="d-flex align-items-center gap-2 mb-0">
                        <input class="form-check-input mt-0" type="checkbox" id="selectAll"> เลือกคำขอสมัครทั้งหน้า (<?php echo $pending_on_page; ?>)
                    </label>
                <?php else: ?>
                    <span></span>
                <?php endif; ?>
                <span>แสดง <?php echo $first_no; ?>-<?php echo $last_no; ?> จาก <?php echo $total_items; ?> บัญชี</span>
            </div>

            <ul class="um-rows" id="usersList">
            <?php foreach ($users as $u):
                $uid = (int)$u['id'];
                $is_self = ($uid === $my_id);
                $status = $u['status'];
                $role = $u['role'];
                $created_ts = strtotime($u['created_at']);
                $waiting = ($status === 'pending') ? max(0, (int)floor(($now_ts - $created_ts) / 86400)) : 0;
                $external = !um_is_internal($u['email'], $internal_domains);
                $b_total = (int)$u['booking_total'];
                $b_active = (int)$u['booking_active'];
                $b_pending = (int)$u['booking_pending'];
                $can_delete = ($b_total === 0 && !$is_self);
                $user_json = um_h(json_encode([
                    'id' => $uid, 'full_name' => $u['full_name'], 'username' => $u['username'], 'email' => $u['email'],
                    'department' => $u['department'], 'role' => $role, 'status' => $status, 'is_self' => $is_self,
                ], JSON_UNESCAPED_UNICODE));
            ?>
                <li class="um-row is-<?php echo um_h($status); ?>" id="user-row-<?php echo $uid; ?>"
                    data-id="<?php echo $uid; ?>" data-status="<?php echo um_h($status); ?>"
                    data-name="<?php echo um_h($u['full_name']); ?>" data-user="<?php echo $user_json; ?>">

                    <label class="um-check">
                        <?php if ($status === 'pending' && !$is_self): ?>
                            <input class="form-check-input user-checkbox" type="checkbox" aria-label="เลือก <?php echo um_h($u['full_name']); ?>">
                        <?php endif; ?>
                    </label>

                    <div class="um-main">
                        <div class="um-avatar role-<?php echo um_h($role); ?>" aria-hidden="true"><?php echo um_h(um_initial($u['full_name'])); ?></div>
                        <div style="min-width:0">
                            <div class="um-name"><?php echo um_h($u['full_name']); ?><?php if ($is_self): ?> <span class="um-chip um-chip--info ms-1">บัญชีของคุณ</span><?php endif; ?></div>
                            <div class="um-sub"><i class="fas fa-at me-1"></i><?php echo um_h($u['username']); ?></div>
                            <div class="um-sub"><i class="far fa-envelope me-1"></i><?php echo um_h($u['email']); ?></div>
                        </div>
                    </div>

                    <div class="um-org">
                        <div class="dept"><?php echo $u['department'] !== '' && $u['department'] !== null ? um_h($u['department']) : '<span class="um-sub">ไม่ระบุส่วนงาน</span>'; ?></div>
                        <div class="um-sub">สมัครเมื่อ <?php echo um_date_short($created_ts); ?></div>
                        <?php if ($status === 'pending' && ($external || $waiting >= 1)): ?>
                        <div class="um-flags">
                            <?php if ($external): ?><span class="um-chip um-chip--warn" title="อีเมลไม่ได้อยู่ในโดเมนองค์กร ควรตรวจสอบตัวตนก่อนอนุมัติ"><i class="fas fa-triangle-exclamation"></i> อีเมลภายนอก</span><?php endif; ?>
                            <?php if ($waiting >= 1): ?><span class="um-chip">รอมา <?php echo $waiting; ?> วัน</span><?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="um-role">
                        <select class="form-select form-select-sm user-role-select" data-id="<?php echo $uid; ?>" data-prev="<?php echo um_h($role); ?>"
                                aria-label="สิทธิ์ของ <?php echo um_h($u['full_name']); ?>" <?php echo $is_self ? 'disabled' : ''; ?>>
                            <?php
                            $opts = array_keys($role_names);
                            if (!in_array($role, $opts, true)) { $opts[] = $role; }
                            foreach ($opts as $ro): ?>
                                <option value="<?php echo um_h($ro); ?>" <?php echo $role === $ro ? 'selected' : ''; ?>><?php echo um_h($role_names[$ro] ?? ucfirst($ro)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="um-status"><span class="um-pill um-pill--<?php echo um_h($status); ?>"><?php echo um_h($status_names[$status] ?? $status); ?></span></div>

                    <div class="um-activity">
                        <?php if ($b_active > 0): ?>
                            <div>จอง <?php echo $b_active; ?> รายการ<?php echo $b_pending > 0 ? ' (รออนุมัติ ' . $b_pending . ')' : ''; ?></div>
                            <?php if (!empty($u['last_booking'])): ?><div class="muted">ล่าสุด <?php echo um_date_short(strtotime($u['last_booking'])); ?></div><?php endif; ?>
                        <?php else: ?>
                            <div class="muted"><?php echo $b_total > 0 ? 'ไม่มีรายการจองที่ใช้งาน' : 'ยังไม่เคยจอง'; ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="um-actions">
                        <?php if ($status === 'pending' && !$is_self): ?>
                            <button type="button" class="btn btn-success btn-sm um-act" data-action="approve"><i class="fas fa-user-check me-1"></i>อนุมัติ</button>
                        <?php elseif (in_array($status, ['inactive', 'suspended'], true) && !$is_self): ?>
                            <button type="button" class="btn btn-outline-success btn-sm um-act" data-action="reactivate">เปิดใช้งานอีกครั้ง</button>
                        <?php else: ?>
                            <button type="button" class="btn btn-outline-secondary btn-sm um-edit"><i class="fas fa-pen me-1"></i>แก้ไข</button>
                        <?php endif; ?>
                        <div class="dropdown">
                            <button type="button" class="btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false" aria-label="เมนูเพิ่มเติม"><i class="fas fa-ellipsis-vertical"></i></button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><button type="button" class="dropdown-item um-edit"><i class="fas fa-pen fa-fw me-2"></i>แก้ไขข้อมูล</button></li>
                                <?php if ($b_active > 0): ?>
                                    <li><a class="dropdown-item" href="manage_bookings.php?status=all&amp;q=<?php echo urlencode($u['full_name']); ?>"><i class="fas fa-calendar-check fa-fw me-2"></i>ดูรายการจอง</a></li>
                                <?php endif; ?>
                                <?php if (!$is_self): ?>
                                    <?php if ($status === 'approved'): ?>
                                        <li><button type="button" class="dropdown-item um-act" data-action="suspend"><i class="fas fa-user-lock fa-fw me-2"></i>ระงับ</button></li>
                                        <li><button type="button" class="dropdown-item um-act" data-action="deactivate"><i class="fas fa-user-slash fa-fw me-2"></i>ปิดใช้งาน</button></li>
                                    <?php endif; ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <?php if ($can_delete): ?>
                                        <li><button type="button" class="dropdown-item text-danger um-act" data-action="delete"><i class="fas fa-trash fa-fw me-2"></i><?php echo $status === 'pending' ? 'ปฏิเสธและลบคำขอ' : 'ลบบัญชี'; ?></button></li>
                                    <?php else: ?>
                                        <li><button type="button" class="dropdown-item" disabled title="ลบไม่ได้เพราะมีประวัติการจอง ให้ใช้ปิดใช้งานแทน"><i class="fas fa-trash fa-fw me-2"></i>ลบไม่ได้ (มีประวัติการจอง)</button></li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
            </ul>

            <div class="um-bulk" id="umBulk" hidden>
                <span><strong id="umSelCount">0</strong> บัญชีที่เลือก</span>
                <span class="grow"></span>
                <button type="button" class="btn btn-success btn-sm" id="umBulkApprove">อนุมัติที่เลือก</button>
                <button type="button" class="btn btn-link btn-sm text-white" id="umClear">ล้างที่เลือก</button>
            </div>

            <?php if ($total_pages > 1): ?>
            <div class="um-pager">
                <span class="text-muted small">หน้า <?php echo $current_page; ?> จาก <?php echo $total_pages; ?></span>
                <nav aria-label="เปลี่ยนหน้า">
                    <ul class="pagination pagination-sm">
                        <li class="page-item <?php echo $current_page <= 1 ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo um_h(um_url(['page' => $current_page - 1])); ?>">ก่อนหน้า</a></li>
                        <?php
                        $shown = [];
                        for ($p = 1; $p <= $total_pages; $p++) {
                            if ($p === 1 || $p === $total_pages || abs($p - $current_page) <= 2) { $shown[] = $p; }
                        }
                        $prev_p = 0;
                        foreach ($shown as $p) {
                            if ($p - $prev_p > 1) { echo '<li class="page-item disabled"><span class="page-link">…</span></li>'; }
                            echo '<li class="page-item ' . ($p === $current_page ? 'active' : '') . '"><a class="page-link" href="' . um_h(um_url(['page' => $p])) . '">' . $p . '</a></li>';
                            $prev_p = $p;
                        }
                        ?>
                        <li class="page-item <?php echo $current_page >= $total_pages ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo um_h(um_url(['page' => $current_page + 1])); ?>">ถัดไป</a></li>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>

<datalist id="deptList">
    <?php foreach ($departments as $d): ?><option value="<?php echo um_h($d); ?>"><?php endforeach; ?>
</datalist>

<!-- เพิ่มผู้ใช้งาน -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addUserTitle">เพิ่มผู้ใช้งาน</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
      </div>
      <form id="addUserForm" autocomplete="off">
        <div class="modal-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="add_full_name" class="form-label">ชื่อ-สกุล <span class="text-danger">*</span></label>
                    <input type="text" name="full_name" id="add_full_name" class="form-control" maxlength="255" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="add_username" class="form-label">ชื่อผู้ใช้ <span class="text-danger">*</span></label>
                    <input type="text" name="username" id="add_username" class="form-control" maxlength="100" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="add_email" class="form-label">อีเมล <span class="text-danger">*</span></label>
                    <input type="email" name="email" id="add_email" class="form-control" maxlength="255" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="add_password" class="form-label">รหัสผ่านเริ่มต้น <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="password" name="password" id="add_password" class="form-control" minlength="8" autocomplete="new-password" required>
                        <button type="button" class="btn btn-outline-secondary um-pw-toggle" data-target="#add_password" aria-label="แสดงหรือซ่อนรหัสผ่าน"><i class="far fa-eye"></i></button>
                        <button type="button" class="btn btn-outline-secondary um-pw-gen" data-target="#add_password">สุ่มรหัส</button>
                    </div>
                    <div class="form-text">อย่างน้อย 8 ตัวอักษร ต้องแจ้งรหัสนี้ให้ผู้ใช้เอง ระบบไม่ส่งอีเมลให้</div>
                </div>
            </div>
            <div class="mb-3">
                <label for="add_department" class="form-label">ส่วนงาน/ภาควิชา <span class="text-danger">*</span></label>
                <input type="text" name="department" id="add_department" class="form-control" list="deptList" maxlength="255" required>
                <div class="form-text">เลือกจากรายการที่มีอยู่เพื่อให้สะกดตรงกัน (สิทธิ์เจ้าหน้าที่ใช้ชื่อส่วนงานนี้จับคู่กับการจอง)</div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="add_role" class="form-label">สิทธิ์ <span class="text-danger">*</span></label>
                    <select name="role" id="add_role" class="form-select" required>
                        <?php foreach ($role_names as $rk => $rl): ?>
                            <option value="<?php echo um_h($rk); ?>" <?php echo $rk === 'user' ? 'selected' : ''; ?>><?php echo um_h($rl); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="um-role-help" id="add_role_help"></div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="add_status" class="form-label">สถานะ <span class="text-danger">*</span></label>
                    <select name="status" id="add_status" class="form-select" required>
                        <option value="approved" selected>อนุมัติแล้ว (ใช้งานได้ทันที)</option>
                        <option value="pending">รออนุมัติ</option>
                        <option value="inactive">ไม่ใช้งาน</option>
                        <option value="suspended">ถูกระงับ</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
            <button type="submit" class="btn btn-primary" id="addSubmit">เพิ่มผู้ใช้งาน</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- แก้ไขผู้ใช้งาน -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editUserTitle">แก้ไขข้อมูลผู้ใช้งาน</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
      </div>
      <form id="editUserForm" autocomplete="off">
        <div class="modal-body">
            <input type="hidden" name="id" id="edit_user_id">
            <div class="alert alert-info py-2 small d-none" id="edit_self_note">นี่คือบัญชีของคุณ จึงเปลี่ยนสิทธิ์และสถานะของตัวเองไม่ได้</div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="edit_full_name" class="form-label">ชื่อ-สกุล <span class="text-danger">*</span></label>
                    <input type="text" name="full_name" id="edit_full_name" class="form-control" maxlength="255" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="edit_username" class="form-label">ชื่อผู้ใช้ <span class="text-danger">*</span></label>
                    <input type="text" name="username" id="edit_username" class="form-control" maxlength="100" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="edit_email" class="form-label">อีเมล <span class="text-danger">*</span></label>
                    <input type="email" name="email" id="edit_email" class="form-control" maxlength="255" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="edit_password" class="form-label">ตั้งรหัสผ่านใหม่ (เว้นว่างถ้าไม่เปลี่ยน)</label>
                    <div class="input-group">
                        <input type="password" name="password" id="edit_password" class="form-control" minlength="8" autocomplete="new-password">
                        <button type="button" class="btn btn-outline-secondary um-pw-toggle" data-target="#edit_password" aria-label="แสดงหรือซ่อนรหัสผ่าน"><i class="far fa-eye"></i></button>
                        <button type="button" class="btn btn-outline-secondary um-pw-gen" data-target="#edit_password">สุ่มรหัส</button>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="edit_department" class="form-label">ส่วนงาน/ภาควิชา <span class="text-danger">*</span></label>
                <input type="text" name="department" id="edit_department" class="form-control" list="deptList" maxlength="255" required>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="edit_role" class="form-label">สิทธิ์ <span class="text-danger">*</span></label>
                    <select name="role" id="edit_role" class="form-select" required></select>
                    <div class="um-role-help" id="edit_role_help"></div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="edit_status" class="form-label">สถานะ <span class="text-danger">*</span></label>
                    <select name="status" id="edit_status" class="form-select" required>
                        <option value="approved">อนุมัติแล้ว</option>
                        <option value="pending">รออนุมัติ</option>
                        <option value="inactive">ไม่ใช้งาน</option>
                        <option value="suspended">ถูกระงับ</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
          <button type="submit" class="btn btn-primary" id="editSubmit">บันทึกการแก้ไข</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
$(function () {
    const ROLE_NAMES = <?php echo json_encode($role_names, JSON_UNESCAPED_UNICODE); ?>;
    const ROLE_DESC  = <?php echo json_encode($role_desc, JSON_UNESCAPED_UNICODE); ?>;
    const API_ACTION = '../api/update_user.php';
    const netError = () => Swal.fire('ทำรายการไม่สำเร็จ', 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ลองใหม่อีกครั้ง', 'error');

    const ACTIONS = {
        approve:    { title: 'อนุมัติบัญชี',        text: 'ผู้ใช้จะเข้าสู่ระบบและจองห้องได้ ระบบไม่ส่งอีเมลแจ้งผู้ใช้ กรุณาแจ้งเอง', icon: 'question', btn: 'อนุมัติ',          color: '#198754' },
        reactivate: { title: 'เปิดใช้งานอีกครั้ง',   text: 'ผู้ใช้จะกลับมาเข้าสู่ระบบได้',                                      icon: 'info',     btn: 'เปิดใช้งาน',       color: '#198754' },
        suspend:    { title: 'ระงับบัญชี',          text: 'ผู้ใช้จะเข้าสู่ระบบไม่ได้จนกว่าจะเปิดใช้งานอีกครั้ง',                 icon: 'warning',  btn: 'ระงับ',           color: '#dc3545' },
        deactivate: { title: 'ปิดใช้งานบัญชี',      text: 'ผู้ใช้จะเข้าสู่ระบบไม่ได้ ข้อมูลการจองยังอยู่ครบ',                  icon: 'warning',  btn: 'ปิดใช้งาน',        color: '#dc3545' },
        'delete':   { title: 'ลบบัญชี',             text: 'ลบถาวรและกู้คืนไม่ได้',                                            icon: 'error',    btn: 'ลบถาวร',          color: '#dc3545' }
    };

    /* ---------- ทำรายการกับบัญชี ---------- */
    function runAction(id, action, name, isPending) {
        const cfg = ACTIONS[action];
        if (!cfg) { return; }
        const title = (action === 'delete' && isPending) ? 'ปฏิเสธและลบคำขอสมัคร' : cfg.title;
        Swal.fire({
            title: title, text: name + ': ' + cfg.text, icon: cfg.icon,
            showCancelButton: true, confirmButtonText: cfg.btn, confirmButtonColor: cfg.color, cancelButtonText: 'ไม่ทำรายการ'
        }).then(function (r) {
            if (!r.isConfirmed) { return; }
            Swal.fire({ title: 'กำลังดำเนินการ…', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            $.ajax({
                url: API_ACTION, type: 'POST', dataType: 'json', data: { id: id, action: action },
                success: function (res) {
                    if (res.success) {
                        Swal.fire({ icon: 'success', title: 'ทำรายการแล้ว', text: res.message, timer: 1200, showConfirmButton: false }).then(() => location.reload());
                    } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
                },
                error: netError
            });
        });
    }
    $('#usersList').on('click', '.um-act', function () {
        const $row = $(this).closest('.um-row');
        runAction($row.data('id'), $(this).data('action'), String($row.data('name')), $row.data('status') === 'pending');
    });

    /* ---------- เปลี่ยนสิทธิ์ในแถว (ต้องยืนยัน และย้อนค่าเดิมถ้าไม่สำเร็จ) ---------- */
    $('#usersList').on('change', '.user-role-select', function () {
        const $sel = $(this);
        const id = $sel.data('id'), prev = String($sel.data('prev')), next = $sel.val();
        const name = String($sel.closest('.um-row').data('name'));
        $sel.val(prev);
        if (next === prev) { return; }

        let warn = 'สิทธิ์เดิมจะถูกแทนที่ทันที';
        if (next === 'admin') { warn = 'ผู้ดูแลระบบจัดการผู้ใช้ ห้อง และการจองได้ทั้งหมด'; }
        else if (prev === 'admin') { warn = 'บัญชีนี้จะไม่สามารถเข้าหน้าผู้ดูแลระบบได้อีก'; }

        Swal.fire({
            title: 'เปลี่ยนสิทธิ์เป็น "' + (ROLE_NAMES[next] || next) + '"',
            text: name + ': ' + warn, icon: next === 'admin' ? 'warning' : 'question',
            showCancelButton: true, focusCancel: next === 'admin',
            confirmButtonText: 'เปลี่ยนสิทธิ์', cancelButtonText: 'ไม่เปลี่ยน'
        }).then(function (r) {
            if (!r.isConfirmed) { return; }
            $.ajax({
                url: API_ACTION, type: 'POST', dataType: 'json', data: { id: id, action: 'update_role', role: next },
                success: function (res) {
                    if (res.success) {
                        $sel.val(next).data('prev', next);
                        $sel.closest('.um-row').find('.um-avatar').attr('class', 'um-avatar role-' + next);
                        Swal.fire({ icon: 'success', title: 'เปลี่ยนสิทธิ์แล้ว', timer: 1200, showConfirmButton: false });
                    } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
                },
                error: netError
            });
        });
    });

    /* ---------- อนุมัติหลายบัญชี ---------- */
    function updateBulk() {
        const $all = $('.user-checkbox'), $checked = $all.filter(':checked'), n = $checked.length;
        $('.um-row').removeClass('is-selected');
        $checked.closest('.um-row').addClass('is-selected');
        $('#umSelCount').text(n);
        $('#umBulk').prop('hidden', n === 0);
        $('#selectAll').prop('checked', n > 0 && n === $all.length).prop('indeterminate', n > 0 && n < $all.length);
    }
    $('#selectAll').on('change', function () { $('.user-checkbox').prop('checked', this.checked); updateBulk(); });
    $('#usersList').on('change', '.user-checkbox', updateBulk);
    $('#umClear').on('click', function () { $('.user-checkbox, #selectAll').prop('checked', false); updateBulk(); });
    $('#umBulkApprove').on('click', function () {
        const ids = $('.user-checkbox:checked').closest('.um-row').map(function () { return $(this).data('id'); }).get();
        if (!ids.length) { return; }
        Swal.fire({
            title: 'อนุมัติ ' + ids.length + ' บัญชี', text: 'ระบบไม่ส่งอีเมลแจ้งผู้ใช้ กรุณาแจ้งเอง', icon: 'question',
            showCancelButton: true, confirmButtonText: 'อนุมัติ', confirmButtonColor: '#198754', cancelButtonText: 'ไม่ทำรายการ'
        }).then(async function (r) {
            if (!r.isConfirmed) { return; }
            Swal.fire({ title: 'กำลังอนุมัติ…', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            let ok = 0; const fails = [];
            for (const id of ids) {
                try {
                    const res = await $.ajax({ url: API_ACTION, type: 'POST', dataType: 'json', data: { id: id, action: 'approve' } });
                    if (res.success) { ok++; } else { fails.push(res.message || 'ไม่สำเร็จ'); }
                } catch (e) { fails.push('เชื่อมต่อไม่ได้'); }
            }
            Swal.fire({
                icon: fails.length ? 'warning' : 'success',
                title: 'อนุมัติแล้ว ' + ok + ' จาก ' + ids.length + ' บัญชี',
                text: fails.length ? 'ไม่สำเร็จ ' + fails.length + ' บัญชี ลองทำซ้ำหรือดู error log' : ''
            }).then(() => location.reload());
        });
    });

    /* ---------- เพิ่มผู้ใช้งาน ---------- */
    const showRoleHelp = (sel, help) => $(help).text(ROLE_DESC[$(sel).val()] || '');
    $('#add_role').on('change', () => showRoleHelp('#add_role', '#add_role_help'));
    showRoleHelp('#add_role', '#add_role_help');

    $('.um-pw-toggle').on('click', function () {
        const $i = $($(this).data('target'));
        const show = $i.attr('type') === 'password';
        $i.attr('type', show ? 'text' : 'password');
        $(this).find('i').attr('class', show ? 'far fa-eye-slash' : 'far fa-eye');
    });
    $('.um-pw-gen').on('click', function () {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
        const buf = new Uint32Array(12);
        crypto.getRandomValues(buf);
        const pw = Array.from(buf, n => chars[n % chars.length]).join('');
        const $i = $($(this).data('target'));
        $i.val(pw).attr('type', 'text');
        $(this).siblings('.um-pw-toggle').find('i').attr('class', 'far fa-eye-slash');
    });

    $('#addUserForm').on('submit', function (e) {
        e.preventDefault();
        const $btn = $('#addSubmit').prop('disabled', true);
        $.ajax({
            url: '../api/add_user.php', type: 'POST', data: $(this).serialize(), dataType: 'json',
            success: function (res) {
                if (res.success) {
                    bootstrap.Modal.getOrCreateInstance(document.getElementById('addUserModal')).hide();
                    Swal.fire({ icon: 'success', title: 'เพิ่มผู้ใช้งานแล้ว', text: 'อย่าลืมแจ้งรหัสผ่านเริ่มต้นให้ผู้ใช้', timer: 1800, showConfirmButton: false }).then(() => location.reload());
                } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
            },
            error: netError,
            complete: function () { $btn.prop('disabled', false); }
        });
    });

    /* ---------- แก้ไขผู้ใช้งาน (ใช้ข้อมูลจากแถว ไม่ต้องเรียกเซิร์ฟเวอร์) ---------- */
    $('#usersList').on('click', '.um-edit', function () {
        const u = JSON.parse($(this).closest('.um-row').attr('data-user'));
        $('#edit_user_id').val(u.id);
        $('#edit_full_name').val(u.full_name);
        $('#edit_username').val(u.username);
        $('#edit_email').val(u.email);
        $('#edit_department').val(u.department || '');
        $('#edit_password').val('').attr('type', 'password');

        const $role = $('#edit_role').empty();
        Object.keys(ROLE_NAMES).forEach(k => $role.append($('<option>').val(k).text(ROLE_NAMES[k])));
        if (!ROLE_NAMES[u.role]) { $role.append($('<option>').val(u.role).text(u.role)); }
        $role.val(u.role);
        $('#edit_status').val(u.status);
        $('#edit_role, #edit_status').prop('disabled', !!u.is_self);
        $('#edit_self_note').toggleClass('d-none', !u.is_self);
        showRoleHelp('#edit_role', '#edit_role_help');
        bootstrap.Modal.getOrCreateInstance(document.getElementById('editUserModal')).show();
    });
    $('#edit_role').on('change', () => showRoleHelp('#edit_role', '#edit_role_help'));

    $('#editUserForm').on('submit', function (e) {
        e.preventDefault();
        $('#edit_role, #edit_status').prop('disabled', false); // ส่งค่าเดิมของบัญชีตัวเองไปด้วย
        const $btn = $('#editSubmit').prop('disabled', true);
        $.ajax({
            url: '../api/save_user_details.php', type: 'POST', data: $(this).serialize(), dataType: 'json',
            success: function (res) {
                if (res.success) {
                    bootstrap.Modal.getOrCreateInstance(document.getElementById('editUserModal')).hide();
                    Swal.fire({ icon: 'success', title: 'บันทึกแล้ว', text: res.message || '', timer: 1300, showConfirmButton: false }).then(() => location.reload());
                } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
            },
            error: netError,
            complete: function () { $btn.prop('disabled', false); }
        });
    });

    /* ---------- ตัวกรอง ---------- */
    const form = document.getElementById('umFilters');
    $('#umFilters select').on('change', function () { form.submit(); });
    $('#umFilters input[type=search]').on('search', function () { form.submit(); });
});
</script>
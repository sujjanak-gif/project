<?php
// Function to check if a menu item is active
function is_active($page) {
    // Get the current script name (e.g., 'index.php')
    $current_page = basename($_SERVER['PHP_SELF']);
    if ($current_page == $page) {
        return 'active';
    }
    return '';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' : ''; ?>Admin Panel</title>
    <link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=K2D:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="sb-nav-fixed">
<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark-blue">
    <a class="navbar-brand ps-3" href="index.php">
        <img src="../assets/images/logo_mu_th_2.png.png" alt="Logo" width="220" height="60" class="me-2">ระบบบริหารจัดการห้อง
    </a>
    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    <ul class="navbar-nav ms-auto me-3 me-lg-4">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i> <?php echo htmlspecialchars($_SESSION['user_fullname']); ?></a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="../index.php">หน้าเว็บไซต์หลัก</a></li>
                <li><hr class="dropdown-divider" /></li>
                <li><a class="dropdown-item" href="../logout.php">ออกจากระบบ</a></li>
            </ul>
        </li>
    </ul>
</nav>
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav pt-3">
                    <a class="nav-link <?php echo is_active('index.php'); ?>" href="index.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        แผงควบคุมหลัก
                    </a>
                    
                    <?php if (can_manage_bookings()): ?>
                    <a class="nav-link <?php echo is_active('manage_bookings.php'); ?>" href="manage_bookings.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>
                        จัดการการจอง
                    </a>
                    <?php endif; ?>

                    <?php if (is_admin()): ?>
                    <a class="nav-link <?php echo is_active('manage_users.php'); ?>" href="manage_users.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        จัดการผู้ใช้งาน
                    </a>
                     <a class="nav-link <?php echo is_active('manage_rooms.php'); ?>" href="manage_rooms.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-door-open"></i></div>
                        จัดการห้อง
                    </a>
                    <a class="nav-link <?php echo is_active('history.php'); ?>" href="history.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-history"></i></div>
                        ประวัติการจอง  (กู้คืน)
                    </a>
                    
                    <a class="nav-link <?php echo is_active('teaching_report.php'); ?>" href="teaching_report.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-file-invoice"></i></div>
                        รายงานการสอน
                    </a>
                    <a class="nav-link <?php echo is_active('statistics.phpphp'); ?>" href="statistics.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-file-invoice"></i></div>
                        สถิติการจอง
                    </a>
                    <?php endif; ?>
				</div>
            </div>
        </nav>
    </div>
    <div id="layoutSidenav_content">
        <main>
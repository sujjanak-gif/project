<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';

require_panel_access();

$page_title = "Admin Dashboard";
include 'layouts/admin_header.php';

/* =====================================================================
   Helpers (prefix dp_)
   ===================================================================== */
function dp_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dp_month_short($m) {
    static $a = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.', 7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    return $a[(int)$m] ?? '';
}
function dp_month_full($m) {
    static $a = [1 => 'มกราคม', 2 => 'กุมภาพันธ์', 3 => 'มีนาคม', 4 => 'เมษายน', 5 => 'พฤษภาคม', 6 => 'มิถุนายน', 7 => 'กรกฎาคม', 8 => 'สิงหาคม', 9 => 'กันยายน', 10 => 'ตุลาคม', 11 => 'พฤศจิกายน', 12 => 'ธันวาคม'];
    return $a[(int)$m] ?? '';
}
function dp_dow_short($w) {
    static $a = ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'];
    return $a[(int)$w] ?? '';
}
function dp_dow_full($w) {
    static $a = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
    return $a[(int)$w] ?? '';
}
function dp_date_long($ts) {
    return 'วัน' . dp_dow_full(date('w', $ts)) . 'ที่ ' . date('j', $ts) . ' ' . dp_month_full(date('n', $ts)) . ' ' . (date('Y', $ts) + 543);
}
function dp_date_short($ts) {
    return date('j', $ts) . ' ' . dp_month_short(date('n', $ts)) . ' ' . substr((string)(date('Y', $ts) + 543), -2);
}
function dp_color($c) {
    return preg_match('/^#[0-9a-fA-F]{3,8}$/', (string)$c) ? $c : '#9aa7b6';
}
function dp_hours($mins) {
    $h = round($mins / 60, 1);
    return (floor($h) == $h) ? (string)(int)$h : number_format($h, 1);
}

/* =====================================================================
   ข้อมูล (officer เห็นเฉพาะการจองของส่วนงานตัวเอง)
   ===================================================================== */
$is_officer = is_officer();
$is_admin = is_admin();
$now_ts = time();
$now_sql = date('Y-m-d H:i:s', $now_ts);
$today = date('Y-m-d', $now_ts);
$soon_to = date('Y-m-d H:i:s', strtotime('+7 days', $now_ts));
$sc_where = $is_officer ? " AND u.department = ?" : "";
$sc_params = $is_officer ? [$_SESSION['user_department']] : [];
$gb = "b.title, b.room_id, b.user_id, b.department, b.instructor_name, b.contact_phone, b.student_count, b.status, DATE(b.start_time)";

// 1) คำขอรออนุมัติ: ทั้งหมด / ใกล้ถึงวันใช้งาน / เลยวันใช้งานแล้ว
$st = $pdo->prepare("SELECT COUNT(*) AS total,
        COALESCE(SUM(g.s >= ? AND g.s < ?), 0) AS soon_cnt,
        COALESCE(SUM(g.e < ?), 0) AS stale_cnt
    FROM (SELECT MIN(b.start_time) AS s, MAX(b.end_time) AS e
          FROM bookings b JOIN users u ON u.id = b.user_id
          WHERE b.is_deleted = 0 AND b.status = 'pending'{$sc_where}
          GROUP BY {$gb}) g");
$st->execute(array_merge([$now_sql, $soon_to, $now_sql], $sc_params));
$p = $st->fetch(PDO::FETCH_ASSOC);
$p_total = (int)($p['total'] ?? 0);
$p_soon = (int)($p['soon_cnt'] ?? 0);
$p_stale = (int)($p['stale_cnt'] ?? 0);

// 2) คำขอที่เวลาชนกับรายการที่อนุมัติแล้ว (เฉพาะที่ยังไม่เลยเวลา)
$st = $pdo->prepare("SELECT COUNT(*) FROM (
        SELECT 1 FROM bookings b JOIN users u ON u.id = b.user_id
        WHERE b.is_deleted = 0 AND b.status = 'pending' AND b.end_time >= ?{$sc_where}
          AND EXISTS (SELECT 1 FROM bookings x
                      WHERE x.room_id = b.room_id AND x.id <> b.id AND x.is_deleted = 0 AND x.status = 'approved'
                        AND x.start_time < b.end_time AND x.end_time > b.start_time)
        GROUP BY {$gb}) c");
$st->execute(array_merge([$now_sql], $sc_params));
$p_conflicts = (int)$st->fetchColumn();

// 3) บัญชีผู้ใช้รออนุมัติ (เฉพาะ admin)
$pending_users = 0;
$latest_users = [];
if ($is_admin) {
    $pending_users = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'pending'")->fetchColumn();
    $latest_users = $pdo->query("SELECT full_name, status, created_at FROM users ORDER BY created_at DESC, id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
}

// 4) ตารางใช้ห้องวันนี้
$st = $pdo->prepare("SELECT b.id, b.title, b.start_time, b.end_time, r.name AS room_name, r.color AS room_color, u.full_name AS user_name
    FROM bookings b JOIN rooms r ON r.id = b.room_id JOIN users u ON u.id = b.user_id
    WHERE b.is_deleted = 0 AND b.status = 'approved' AND DATE(b.start_time) = ?{$sc_where}
    ORDER BY b.start_time, b.id");
$st->execute(array_merge([$today], $sc_params));
$agenda = $st->fetchAll(PDO::FETCH_ASSOC);
$agenda_max = 8;

// 5) การใช้ห้อง 7 วันข้างหน้า (ชั่วโมงที่อนุมัติแล้วต่อห้องต่อวัน)
$days = [];
for ($i = 0; $i < 7; $i++) { $days[] = date('Y-m-d', strtotime("+{$i} days", $now_ts)); }
$rooms = $pdo->query("SELECT id, name, color FROM rooms ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$st = $pdo->prepare("SELECT b.room_id, DATE(b.start_time) AS d,
        SUM(TIMESTAMPDIFF(MINUTE, b.start_time, b.end_time)) AS mins, COUNT(*) AS n
    FROM bookings b JOIN users u ON u.id = b.user_id
    WHERE b.is_deleted = 0 AND b.status = 'approved' AND DATE(b.start_time) BETWEEN ? AND ?{$sc_where}
    GROUP BY b.room_id, DATE(b.start_time)");
$st->execute(array_merge([$days[0], $days[6]], $sc_params));
$util = [];
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $util[(int)$r['room_id']][$r['d']] = ['mins' => (int)$r['mins'], 'n' => (int)$r['n']];
}

// 6) สรุปเดือนนี้ (ตามรายการที่อนุมัติไว้)
$st = $pdo->prepare("SELECT b.room_id, r.name AS room_name,
        SUM(TIMESTAMPDIFF(MINUTE, b.start_time, b.end_time)) AS mins,
        COUNT(DISTINCT CONCAT(b.title, '_', b.user_id, '_', DATE(b.start_time))) AS n
    FROM bookings b JOIN rooms r ON r.id = b.room_id JOIN users u ON u.id = b.user_id
    WHERE b.is_deleted = 0 AND b.status = 'approved' AND DATE(b.start_time) BETWEEN ? AND ?{$sc_where}
    GROUP BY b.room_id, r.name");
$st->execute(array_merge([date('Y-m-01', $now_ts), date('Y-m-t', $now_ts)], $sc_params));
$month_n = 0; $month_mins = 0; $busiest = null;
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $month_n += (int)$r['n'];
    $month_mins += (int)$r['mins'];
    if ($busiest === null || (int)$r['mins'] > $busiest['mins']) { $busiest = ['name' => $r['room_name'], 'mins' => (int)$r['mins']]; }
}

// 7) คำขอที่ควรตรวจก่อน (ใกล้ถึงวันใช้งานที่สุด)
$st = $pdo->prepare("SELECT MIN(b.id) AS id, b.title, r.name AS room_name, r.color AS room_color, u.full_name AS user_name,
        MIN(b.start_time) AS s, MAX(b.end_time) AS e
    FROM bookings b JOIN rooms r ON r.id = b.room_id JOIN users u ON u.id = b.user_id
    WHERE b.is_deleted = 0 AND b.status = 'pending'{$sc_where}
    GROUP BY b.title, b.room_id, r.name, r.color, b.user_id, u.full_name, b.department, b.instructor_name, b.contact_phone, b.student_count, b.status, DATE(b.start_time)
    ORDER BY (MIN(b.start_time) < '{$now_sql}') ASC, MIN(b.start_time) ASC, MIN(b.id) ASC
    LIMIT 6");
$st->execute($sc_params);
$urgent = $st->fetchAll(PDO::FETCH_ASSOC);

$user_status_names = ['pending' => 'รออนุมัติ', 'approved' => 'อนุมัติแล้ว', 'inactive' => 'ไม่ใช้งาน', 'suspended' => 'ถูกระงับ'];

$tiles = [
    [
        'href' => 'manage_bookings.php?status=pending',
        'key' => 'pending', 'icon' => 'fa-clipboard-list',
        'num' => $p_total, 'label' => 'คำขอรออนุมัติ', 'level' => $p_total > 0 ? 'warn' : 'ok',
        'hint' => $p_total === 0 ? 'ไม่มีคำขอค้าง' : ($p_stale > 0 ? 'เลยวันใช้งานแล้ว ' . $p_stale . ' รายการ' : 'ตรวจและตัดสินใจที่หน้าจัดการการจอง'),
    ],
    [
        'href' => 'manage_bookings.php?' . http_build_query(['status' => 'pending', 'start_date' => $today, 'end_date' => date('Y-m-d', strtotime('+7 days', $now_ts)), 'sort' => 'soon']),
        'key' => 'soon', 'icon' => 'fa-calendar-day',
        'num' => $p_soon, 'label' => 'จะถึงวันใช้งานภายใน 7 วัน', 'level' => $p_soon > 0 ? 'warn' : 'ok',
        'hint' => $p_soon > 0 ? 'ควรตัดสินใจก่อน' : 'ไม่มีรายการเร่งด่วน',
    ],
    [
        'href' => 'manage_bookings.php?status=pending&sort=soon',
        'key' => 'conflict', 'icon' => 'fa-triangle-exclamation',
        'num' => $p_conflicts, 'label' => 'เวลาชนกับรายการที่อนุมัติแล้ว', 'level' => $p_conflicts > 0 ? 'danger' : 'ok',
        'hint' => $p_conflicts > 0 ? 'ตรวจก่อนอนุมัติ ไม่เช่นนั้นจะจองซ้อน' : 'ไม่มีเวลาชน',
    ],
];
if ($is_admin) {
    $tiles[] = [
        'href' => 'manage_users.php?status=pending',
        'key' => 'users', 'icon' => 'fa-user-plus',
        'num' => $pending_users, 'label' => 'บัญชีรออนุมัติ', 'level' => $pending_users > 0 ? 'warn' : 'ok',
        'hint' => $pending_users > 0 ? 'ผู้สมัครใหม่รอการอนุมัติ' : 'ไม่มีผู้สมัครค้าง',
    ];
}
?>

<style>
.dp-page { --dp-ink:#1c2733; --dp-muted:#667587; --dp-line:#e3e8ee; --dp-navy:#123456; --dp-brand:#003399;
    --dp-warn:#e0a100; --dp-warn-bg:#fff3d1; --dp-warn-fg:#7a5200; --dp-danger:#c62839; --dp-ok:#2e9d62;
    --dp-approved-bg:#dcf2e5; --dp-approved-fg:#14613a; --dp-inactive-bg:#e8ecf1; --dp-inactive-fg:#475466; --dp-suspended-bg:#fde3e7; --dp-suspended-fg:#9a1b30;
    color:var(--dp-ink); }
.dp-head { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-end; gap:12px; margin-bottom:18px; }
.dp-head h1 { font-size:1.65rem; font-weight:500; margin:0; }
.dp-head p { margin:2px 0 0; color:var(--dp-muted); }
.dp-tiles { display:grid; grid-template-columns:repeat(auto-fit, minmax(230px, 1fr)); gap:16px; margin-bottom:22px; }
.dp-tile { position:relative; overflow:hidden; display:block; padding:18px 20px 16px; border-radius:16px; color:var(--t-ink); text-decoration:none;
    background:linear-gradient(135deg, var(--t-bg) 0%, var(--t-bg2) 100%); border:1px solid var(--t-line);
    box-shadow:0 1px 2px rgba(18,52,86,.05); transition:transform .15s ease, box-shadow .15s ease; }
.dp-tile:hover { color:var(--t-ink); transform:translateY(-2px); box-shadow:0 8px 20px rgba(18,52,86,.10); }
.dp-tile:focus-visible { outline:3px solid var(--t-accent); outline-offset:2px; }
.dp-tile--pending  { --t-bg:#fff6dc; --t-bg2:#ffe7a8; --t-accent:#d49a00; --t-ink:#5c3d00; --t-line:#f2d98d; }
.dp-tile--soon     { --t-bg:#e9f2ff; --t-bg2:#c9ddfb; --t-accent:#2f6fd6; --t-ink:#143a78; --t-line:#b9d0f3; }
.dp-tile--conflict { --t-bg:#ffeaee; --t-bg2:#fbc9d1; --t-accent:#d33a4e; --t-ink:#7d1222; --t-line:#f2b4be; }
.dp-tile--users    { --t-bg:#f2ebff; --t-bg2:#dccbf8; --t-accent:#7a4bd1; --t-ink:#3f2478; --t-line:#cfbcf0; }
.dp-ico { position:absolute; top:16px; right:16px; width:46px; height:46px; border-radius:14px; display:flex; align-items:center; justify-content:center;
    background:var(--t-accent); color:#fff; font-size:1.2rem; box-shadow:0 4px 10px rgba(0,0,0,.12); }
.dp-deco { position:absolute; right:-14px; bottom:-18px; font-size:5.6rem; color:var(--t-accent); opacity:.13; transform:rotate(-12deg); pointer-events:none; }
.dp-tile .num { font-size:2.4rem; font-weight:600; line-height:1.1; padding-right:60px; }
.dp-tile .label { font-weight:500; margin-top:6px; padding-right:48px; }
.dp-tile .hint { font-size:.86rem; margin-top:3px; opacity:.8; position:relative; }
.dp-tile.is-ok .dp-ico { opacity:.6; box-shadow:none; }
.dp-tile.is-ok .num { opacity:.55; }
.dp-card { background:#fff; border:1px solid var(--dp-line); border-radius:14px; box-shadow:0 1px 2px rgba(18,52,86,.04); margin-bottom:22px; }
.dp-card-head { display:flex; justify-content:space-between; align-items:center; gap:10px; padding:14px 18px; border-bottom:1px solid var(--dp-line); }
.dp-card-head h2 { font-size:1.05rem; font-weight:500; margin:0; }
.dp-card-head a { font-size:.88rem; text-decoration:none; }
.dp-list { list-style:none; margin:0; padding:0; }
.dp-item { display:flex; gap:14px; align-items:center; padding:12px 18px; border-bottom:1px solid var(--dp-line); }
.dp-item:last-child { border-bottom:0; }
.dp-item.is-done { opacity:.55; }
.dp-time { flex:0 0 58px; text-align:center; line-height:1.25; font-variant-numeric:tabular-nums; }
.dp-time .a { font-weight:600; }
.dp-time .b { font-size:.84rem; color:var(--dp-muted); }
.dp-body { flex:1; min-width:0; }
.dp-title { font-weight:500; overflow-wrap:anywhere; }
.dp-sub { font-size:.86rem; color:var(--dp-muted); overflow-wrap:anywhere; }
.dp-dot { display:inline-block; width:9px; height:9px; border-radius:50%; margin-right:6px; }
.dp-chip { display:inline-flex; align-items:center; gap:6px; padding:1px 9px; border-radius:999px; font-size:.78rem; border:1px solid var(--dp-line); background:#f6f8fa; color:var(--dp-muted); white-space:nowrap; }
.dp-chip.live { background:var(--dp-approved-bg); border-color:#b5dfc6; color:var(--dp-approved-fg); }
.dp-chip.warn { background:var(--dp-warn-bg); border-color:#f1d78a; color:var(--dp-warn-fg); }
.dp-date { flex:0 0 52px; text-align:center; border:1px solid var(--dp-line); border-radius:10px; padding:4px 0 5px; line-height:1.15; background:#fff; }
.dp-date .d { display:block; font-size:.72rem; color:var(--dp-muted); }
.dp-date .n { display:block; font-size:1.25rem; font-weight:600; }
.dp-date .m { display:block; font-size:.74rem; color:var(--dp-muted); }
.dp-empty { padding:34px 18px; text-align:center; color:var(--dp-muted); }
.dp-grid { width:100%; border-collapse:separate; border-spacing:4px; font-size:.9rem; }
.dp-grid th { font-weight:500; color:var(--dp-muted); text-align:center; padding:4px 2px; font-size:.82rem; line-height:1.2; }
.dp-grid th.today { color:var(--dp-brand); font-weight:600; }
.dp-grid th.room, .dp-grid td.room { text-align:left; min-width:170px; max-width:260px; padding-right:8px; }
.dp-grid td { text-align:center; height:40px; border-radius:8px; background:#f4f6f9; font-variant-numeric:tabular-nums; }
.dp-grid td.room { background:none; font-size:.88rem; overflow-wrap:anywhere; }
.dp-grid td.zero { color:#b3bdc9; }
.dp-legend { padding:0 18px 14px; font-size:.82rem; color:var(--dp-muted); }
.dp-stats { display:grid; grid-template-columns:repeat(auto-fit, minmax(150px, 1fr)); gap:12px; padding:16px 18px; }
.dp-stat .v { font-size:1.6rem; font-weight:600; line-height:1.15; }
.dp-stat .k { font-size:.86rem; color:var(--dp-muted); }
.dp-pill { display:inline-flex; align-items:center; gap:6px; padding:2px 10px; border-radius:999px; font-size:.78rem; font-weight:500; white-space:nowrap; }
.dp-pill::before { content:""; width:6px; height:6px; border-radius:50%; background:currentColor; }
.dp-pill.pending { background:var(--dp-warn-bg); color:var(--dp-warn-fg); }
.dp-pill.approved { background:var(--dp-approved-bg); color:var(--dp-approved-fg); }
.dp-pill.inactive { background:var(--dp-inactive-bg); color:var(--dp-inactive-fg); }
.dp-pill.suspended { background:var(--dp-suspended-bg); color:var(--dp-suspended-fg); }
.dp-item a.stretch { color:inherit; text-decoration:none; display:flex; gap:14px; align-items:center; width:100%; }
.dp-item a.stretch:hover .dp-title { color:var(--dp-brand); text-decoration:underline; }
@media (prefers-reduced-motion: reduce) { .dp-page * { transition:none !important; } .dp-tile:hover { transform:none; } }
</style>

<div class="container-fluid px-4 py-4 dp-page">

    <header class="dp-head">
        <div>
            <h1>แผงควบคุมหลัก</h1>
            <p><?php echo dp_h(dp_date_long($now_ts)); ?><?php if ($is_officer): ?><span class="ms-3">แสดงเฉพาะการจองของ <?php echo dp_h($_SESSION['user_department']); ?></span><?php endif; ?></p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-calendar-alt me-1"></i>ดูปฏิทินการจอง</a>
            <a href="manage_bookings.php" class="btn btn-primary btn-sm"><i class="fas fa-tasks me-1"></i>จัดการการจอง</a>
        </div>
    </header>

    <section class="dp-tiles" aria-label="เรื่องที่ต้องดำเนินการ">
        <?php foreach ($tiles as $t): ?>
            <a class="dp-tile dp-tile--<?php echo $t['key']; ?> is-<?php echo $t['level']; ?>" href="<?php echo dp_h($t['href']); ?>">
                <span class="dp-ico" aria-hidden="true"><i class="fas <?php echo $t['icon']; ?>"></i></span>
                <i class="fas <?php echo $t['icon']; ?> dp-deco" aria-hidden="true"></i>
                <div class="num"><?php echo (int)$t['num']; ?></div>
                <div class="label"><?php echo dp_h($t['label']); ?></div>
                <div class="hint"><?php echo dp_h($t['hint']); ?></div>
            </a>
        <?php endforeach; ?>
    </section>

    <div class="row">
        <div class="col-xl-7">

            <section class="dp-card">
                <div class="dp-card-head">
                    <h2>การใช้ห้องวันนี้</h2>
                    <a href="../index.php">ดูในปฏิทิน</a>
                </div>
                <?php if (empty($agenda)): ?>
                    <div class="dp-empty">วันนี้ไม่มีการจองที่อนุมัติแล้ว</div>
                <?php else: ?>
                    <ul class="dp-list">
                    <?php foreach (array_slice($agenda, 0, $agenda_max) as $a):
                        $s = strtotime($a['start_time']); $e = strtotime($a['end_time']);
                        $live = ($s <= $now_ts && $e > $now_ts);
                        $done = ($e <= $now_ts);
                    ?>
                        <li class="dp-item <?php echo $done ? 'is-done' : ''; ?>">
                            <div class="dp-time"><div class="a"><?php echo date('H:i', $s); ?></div><div class="b"><?php echo date('H:i', $e); ?></div></div>
                            <div class="dp-body">
                                <div class="dp-title"><?php echo dp_h($a['title']); ?></div>
                                <div class="dp-sub"><span class="dp-dot" style="background:<?php echo dp_h(dp_color($a['room_color'])); ?>"></span><?php echo dp_h($a['room_name']); ?></div>
                                <div class="dp-sub"><i class="far fa-user me-1"></i><?php echo dp_h($a['user_name']); ?></div>
                            </div>
                            <?php if ($live): ?><span class="dp-chip live">กำลังใช้งาน</span>
                            <?php elseif ($done): ?><span class="dp-chip">เสร็จแล้ว</span>
                            <?php else: ?><span class="dp-chip">ยังไม่เริ่ม</span><?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                    <?php if (count($agenda) > $agenda_max): ?>
                        <div class="dp-legend pt-2">และอีก <?php echo count($agenda) - $agenda_max; ?> รายการ ดูทั้งหมดในปฏิทิน</div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>

            <section class="dp-card">
                <div class="dp-card-head"><h2>ชั่วโมงใช้ห้อง 7 วันข้างหน้า</h2></div>
                <?php if (empty($rooms)): ?>
                    <div class="dp-empty">ยังไม่มีห้องในระบบ</div>
                <?php else: ?>
                <div class="table-responsive px-2 pt-2">
                    <table class="dp-grid">
                        <thead>
                            <tr>
                                <th class="room" scope="col">ห้อง</th>
                                <?php foreach ($days as $d): $dt = strtotime($d); ?>
                                    <th scope="col" class="<?php echo $d === $today ? 'today' : ''; ?>"><?php echo dp_dow_short(date('w', $dt)); ?><br><?php echo date('j', $dt); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($rooms as $r): $rid = (int)$r['id']; ?>
                            <tr>
                                <td class="room"><span class="dp-dot" style="background:<?php echo dp_h(dp_color($r['color'])); ?>"></span><?php echo dp_h($r['name']); ?></td>
                                <?php foreach ($days as $d):
                                    $cell = $util[$rid][$d] ?? null;
                                    if ($cell) {
                                        $alpha = 0.12 + 0.78 * min(($cell['mins'] / 60) / 8, 1);
                                        $style = 'background:rgba(0,51,153,' . round($alpha, 2) . ');' . ($alpha > 0.5 ? 'color:#fff;' : '');
                                        $tip = $r['name'] . ' ' . dp_date_short(strtotime($d)) . ': ' . $cell['n'] . ' รายการ ' . dp_hours($cell['mins']) . ' ชั่วโมง';
                                    }
                                ?>
                                    <?php if ($cell): ?>
                                        <td style="<?php echo $style; ?>" title="<?php echo dp_h($tip); ?>"><?php echo dp_hours($cell['mins']); ?></td>
                                    <?php else: ?>
                                        <td class="zero" title="<?php echo dp_h($r['name'] . ' ' . dp_date_short(strtotime($d)) . ': ว่างทั้งวัน'); ?>">-</td>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="dp-legend">ตัวเลขคือชั่วโมงที่อนุมัติแล้วในวันนั้น สีเข้มขึ้นเมื่อใช้ใกล้ 8 ชั่วโมงขึ้นไป</div>
                <?php endif; ?>
            </section>

            <section class="dp-card">
                <div class="dp-card-head"><h2>สรุปเดือน<?php echo dp_h(dp_month_full(date('n', $now_ts))); ?> (ตามรายการที่อนุมัติไว้)</h2></div>
                <div class="dp-stats">
                    <div class="dp-stat"><div class="v"><?php echo $month_n; ?></div><div class="k">รายการจองที่อนุมัติ</div></div>
                    <div class="dp-stat"><div class="v"><?php echo dp_hours($month_mins); ?></div><div class="k">ชั่วโมงใช้ห้องรวม</div></div>
                    <div class="dp-stat">
                        <div class="v" style="font-size:1.05rem;line-height:1.5"><?php echo $busiest ? dp_h($busiest['name']) : '-'; ?></div>
                        <div class="k"><?php echo $busiest ? 'ห้องที่ใช้มากที่สุด ' . dp_hours($busiest['mins']) . ' ชั่วโมง' : 'ยังไม่มีข้อมูลเดือนนี้'; ?></div>
                    </div>
                </div>
            </section>
        </div>

        <div class="col-xl-5">

            <section class="dp-card">
                <div class="dp-card-head">
                    <h2>คำขอที่ควรตรวจก่อน</h2>
                    <a href="manage_bookings.php?status=pending">ดูทั้งหมด (<?php echo $p_total; ?>)</a>
                </div>
                <?php if (empty($urgent)): ?>
                    <div class="dp-empty">ไม่มีคำขอที่รออนุมัติ</div>
                <?php else: ?>
                    <ul class="dp-list">
                    <?php foreach ($urgent as $u):
                        $s = strtotime($u['s']); $e = strtotime($u['e']);
                        $past = ($e < $now_ts);
                        $days_left = (int)round((strtotime(date('Y-m-d', $s)) - strtotime($today)) / 86400);
                        $when = $past ? 'เลยวันใช้งานแล้ว' : ($days_left <= 0 ? 'วันนี้' : ($days_left === 1 ? 'พรุ่งนี้' : 'อีก ' . $days_left . ' วัน'));
                    ?>
                        <li class="dp-item">
                            <a class="stretch" href="manage_bookings.php?<?php echo dp_h(http_build_query(['status' => 'pending', 'q' => $u['title']])); ?>">
                                <div class="dp-date"><span class="d"><?php echo dp_dow_short(date('w', $s)); ?></span><span class="n"><?php echo date('j', $s); ?></span><span class="m"><?php echo dp_month_short(date('n', $s)); ?></span></div>
                                <div class="dp-body">
                                    <div class="dp-title"><?php echo dp_h($u['title']); ?></div>
                                    <div class="dp-sub"><?php echo date('H:i', $s); ?> - <?php echo date('H:i', $e); ?></div>
                                    <div class="dp-sub"><span class="dp-dot" style="background:<?php echo dp_h(dp_color($u['room_color'])); ?>"></span><?php echo dp_h($u['room_name']); ?></div>
                                    <div class="dp-sub"><i class="far fa-user me-1"></i><?php echo dp_h($u['user_name']); ?></div>
                                </div>
                                <span class="dp-chip <?php echo (!$past && $days_left <= 2) ? 'warn' : ''; ?>"><?php echo dp_h($when); ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>

            <?php if ($is_admin): ?>
            <section class="dp-card">
                <div class="dp-card-head">
                    <h2>ผู้ใช้งานที่ลงทะเบียนล่าสุด</h2>
                    <a href="manage_users.php">จัดการผู้ใช้</a>
                </div>
                <?php if (empty($latest_users)): ?>
                    <div class="dp-empty">ยังไม่มีผู้ใช้งาน</div>
                <?php else: ?>
                    <ul class="dp-list">
                    <?php foreach ($latest_users as $lu): ?>
                        <li class="dp-item">
                            <div class="dp-body">
                                <div class="dp-title"><?php echo dp_h($lu['full_name']); ?></div>
                                <div class="dp-sub">สมัครเมื่อ <?php echo dp_h(dp_date_short(strtotime($lu['created_at']))); ?></div>
                            </div>
                            <span class="dp-pill <?php echo dp_h($lu['status']); ?>"><?php echo dp_h($user_status_names[$lu['status']] ?? $lu['status']); ?></span>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
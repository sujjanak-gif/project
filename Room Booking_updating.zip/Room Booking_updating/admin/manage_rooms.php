<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';
require_admin();

$page_title = "จัดการห้อง";
include 'layouts/admin_header.php';

/* =====================================================================
   Helpers (prefix rm_)
   ===================================================================== */
function rm_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function rm_color($c) { return preg_match('/^#[0-9a-fA-F]{6}$/', (string)$c) ? strtolower($c) : '#3788d8'; }
function rm_date($ts) {
    static $m = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.', 7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    return date('j', $ts) . ' ' . $m[(int)date('n', $ts)] . ' ' . substr((string)(date('Y', $ts) + 543), -2);
}

/* =====================================================================
   ข้อมูลห้อง พร้อมสถิติการใช้งานของแต่ละห้อง
   ===================================================================== */
$now_sql = date('Y-m-d H:i:s');
$stmt = $pdo->prepare("
    SELECT r.id, r.name, r.color,
           COUNT(b.id) AS total,
           COALESCE(SUM(b.is_deleted = 0 AND b.status = 'pending'), 0) AS pending,
           COALESCE(SUM(b.is_deleted = 0 AND b.status = 'approved'), 0) AS approved,
           COALESCE(SUM(b.is_deleted = 0 AND b.status = 'approved' AND b.end_time >= ?), 0) AS upcoming,
           MAX(CASE WHEN b.is_deleted = 0 AND b.status = 'approved' THEN b.start_time END) AS last_used
    FROM rooms r
    LEFT JOIN bookings b ON b.room_id = r.id
    GROUP BY r.id, r.name, r.color
    ORDER BY r.name
");
$stmt->execute([$now_sql]);
$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
$palette = ['#2f6fd6', '#198754', '#d9534f', '#e0a100', '#7a4bd1', '#0f9d8a', '#c2185b', '#e07b00', '#6c757d', '#0dcaf0'];
?>

<style>
.rm-page { --ink:#1c2733; --muted:#667587; --line:#e3e8ee; --brand:#003399; color:var(--ink); }
.rm-head { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-end; gap:12px; margin-bottom:18px; }
.rm-head h1 { font-size:1.65rem; font-weight:500; margin:0; }
.rm-head p { margin:2px 0 0; color:var(--muted); }
.rm-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(320px, 1fr)); gap:18px; }
.rm-card { position:relative; background:#fff; border:1px solid var(--line); border-radius:16px; overflow:hidden; box-shadow:0 1px 3px rgba(18,52,86,.06); display:flex; flex-direction:column; }
.rm-band { height:10px; background:var(--room); }
.rm-body { padding:16px 18px 14px; flex:1; }
.rm-name { font-size:1.1rem; font-weight:500; line-height:1.35; overflow-wrap:anywhere; margin:0 0 6px; }
.rm-hex { display:inline-flex; align-items:center; gap:7px; font-size:.82rem; color:var(--muted); font-variant-numeric:tabular-nums; }
.rm-sw { width:14px; height:14px; border-radius:50%; background:var(--room); box-shadow:0 0 0 2px #fff, 0 0 0 3px rgba(0,0,0,.14); }
.rm-stats { display:grid; grid-template-columns:repeat(3, 1fr); gap:8px; margin:16px 0 12px; }
.rm-stat { background:#f6f8fb; border-radius:12px; padding:10px 8px; text-align:center; }
.rm-stat .v { font-size:1.45rem; font-weight:600; line-height:1.1; }
.rm-stat .k { font-size:.76rem; color:var(--muted); margin-top:2px; }
.rm-stat.is-warn .v { color:#a86b00; }
.rm-last { font-size:.86rem; color:var(--muted); }
.rm-preview { margin-top:12px; }
.rm-ev { display:inline-flex; align-items:center; gap:6px; max-width:100%; padding:2px 8px; font-size:.78rem; line-height:1.4; background:color-mix(in srgb, var(--room) 14%, #fff); border-left:4px solid var(--room); color:#1c2733; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.rm-ev b { font-variant-numeric:tabular-nums; }
.rm-foot { display:flex; justify-content:flex-end; gap:8px; padding:12px 18px 16px; border-top:1px solid var(--line); background:#fafbfd; }
.rm-empty { background:#fff; border:1px dashed #c9d3df; border-radius:16px; padding:56px 18px; text-align:center; color:var(--muted); }
.rm-empty h2 { font-size:1.15rem; font-weight:500; color:var(--ink); }
.rm-swatches { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:10px; }
.rm-swatch { width:32px; height:32px; border-radius:50%; border:0; background:var(--c); box-shadow:0 0 0 2px #fff, 0 0 0 3px rgba(0,0,0,.18); cursor:pointer; }
.rm-swatch.is-on { box-shadow:0 0 0 2px #fff, 0 0 0 4px var(--ink); }
.rm-swatch:focus-visible { outline:2px solid var(--brand); outline-offset:3px; }
.rm-prev-box { background:#f6f8fb; border:1px solid var(--line); border-radius:12px; padding:14px; }
.rm-prev-box .t { font-size:.8rem; color:var(--muted); margin-bottom:8px; }
.rm-chip { display:inline-flex; align-items:center; gap:8px; max-width:100%; padding:6px 14px; border:1px solid color-mix(in srgb, var(--room) 60%, #fff); border-radius:999px; background:color-mix(in srgb, var(--room) 16%, #fff); font-size:.88rem; }
.rm-chip .dot { flex:none; width:10px; height:10px; border-radius:50%; background:var(--room); box-shadow:0 0 0 2px #fff, 0 0 0 3px rgba(0,0,0,.12); }
.rm-chip .txt { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
@media (prefers-reduced-motion: reduce) { .rm-page * { transition:none !important; } }
</style>

<div class="container-fluid px-4 py-4 rm-page">

    <header class="rm-head">
        <div>
            <h1>จัดการห้อง</h1>
            <p>ทั้งหมด <?php echo count($rooms); ?> ห้อง สีของแต่ละห้องใช้แสดงในปฏิทินหน้าแรกและรายงาน</p>
        </div>
        <button type="button" class="btn btn-primary" id="rmAddBtn"><i class="fas fa-plus me-2"></i>เพิ่มห้องใหม่</button>
    </header>

    <?php if (empty($rooms)): ?>
        <div class="rm-empty">
            <h2>ยังไม่มีห้องในระบบ</h2>
            <p>เพิ่มห้องแรกเพื่อให้ผู้ใช้เลือกจองและแสดงในปฏิทิน</p>
            <button type="button" class="btn btn-primary btn-sm" id="rmAddBtn2"><i class="fas fa-plus me-1"></i>เพิ่มห้องใหม่</button>
        </div>
    <?php else: ?>
    <div class="rm-grid" id="roomGrid">
        <?php foreach ($rooms as $r):
            $color = rm_color($r['color']);
            $total = (int)$r['total'];
            $can_delete = ($total === 0);
        ?>
        <article class="rm-card" id="room-<?php echo (int)$r['id']; ?>" style="--room:<?php echo rm_h($color); ?>"
                 data-id="<?php echo (int)$r['id']; ?>" data-name="<?php echo rm_h($r['name']); ?>" data-color="<?php echo rm_h($color); ?>">
            <div class="rm-band"></div>
            <div class="rm-body">
                <h2 class="rm-name"><?php echo rm_h($r['name']); ?></h2>
                <span class="rm-hex"><span class="rm-sw"></span><?php echo rm_h(strtoupper($color)); ?></span>

                <div class="rm-stats">
                    <div class="rm-stat"><div class="v"><?php echo (int)$r['upcoming']; ?></div><div class="k">จองล่วงหน้า (อนุมัติแล้ว)</div></div>
                    <div class="rm-stat <?php echo (int)$r['pending'] > 0 ? 'is-warn' : ''; ?>"><div class="v"><?php echo (int)$r['pending']; ?></div><div class="k">รออนุมัติ</div></div>
                    <div class="rm-stat"><div class="v"><?php echo $total; ?></div><div class="k">การจองทั้งหมด</div></div>
                </div>

                <div class="rm-last">
                    <?php echo !empty($r['last_used']) ? 'ใช้งานล่าสุด ' . rm_h(rm_date(strtotime($r['last_used']))) : 'ยังไม่เคยมีการจองที่อนุมัติ'; ?>
                </div>

                <div class="rm-preview"><span class="rm-ev"><b>09:00</b> ตัวอย่างรายการในปฏิทิน</span></div>
            </div>
            <div class="rm-foot">
                <button type="button" class="btn btn-outline-secondary btn-sm rm-edit"><i class="fas fa-pen me-1"></i>แก้ไข</button>
                <?php if ($can_delete): ?>
                    <button type="button" class="btn btn-outline-danger btn-sm rm-delete"><i class="fas fa-trash me-1"></i>ลบ</button>
                <?php else: ?>
                    <span class="d-inline-block" tabindex="0" data-bs-toggle="tooltip" data-bs-title="ลบไม่ได้ เพราะห้องนี้มีประวัติการจอง <?php echo $total; ?> รายการ">
                        <button type="button" class="btn btn-outline-secondary btn-sm" disabled><i class="fas fa-trash me-1"></i>ลบ</button>
                    </span>
                <?php endif; ?>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- เพิ่ม / แก้ไขห้อง -->
<div class="modal fade" id="roomModal" tabindex="-1" aria-labelledby="roomModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="roomModalTitle">เพิ่มห้องใหม่</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
      </div>
      <form id="roomForm" autocomplete="off">
        <div class="modal-body">
            <input type="hidden" name="action" id="rf_action" value="add">
            <input type="hidden" name="id" id="rf_id" value="">
            <div class="mb-3">
                <label for="rf_name" class="form-label">ชื่อห้อง <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="rf_name" name="name" maxlength="255" required>
            </div>
            <div class="mb-3">
                <label class="form-label">สีที่แสดงบนปฏิทิน</label>
                <div class="rm-swatches" id="rf_swatches" role="group" aria-label="เลือกสีสำเร็จรูป">
                    <?php foreach ($palette as $pc): ?>
                        <button type="button" class="rm-swatch" style="--c:<?php echo rm_h($pc); ?>" data-c="<?php echo rm_h($pc); ?>" aria-label="สี <?php echo rm_h($pc); ?>"></button>
                    <?php endforeach; ?>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <input type="color" class="form-control form-control-color" id="rf_color" name="color" value="#2f6fd6" title="เลือกสีเอง">
                    <input type="text" class="form-control" id="rf_hex" maxlength="7" style="max-width:130px" aria-label="รหัสสี" placeholder="#2f6fd6">
                </div>
            </div>
            <div class="rm-prev-box">
                <div class="t">ตัวอย่างที่จะแสดง</div>
                <div class="mb-2"><span class="rm-chip" id="rf_prev_chip"><span class="dot"></span><span class="txt" id="rf_prev_name">ชื่อห้อง</span></span></div>
                <span class="rm-ev" id="rf_prev_ev"><b>09:00</b> ตัวอย่างรายการในปฏิทิน</span>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
            <button type="submit" class="btn btn-primary" id="rf_submit">บันทึก</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
$(function () {
    const modalEl = document.getElementById('roomModal');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    const DEFAULT_COLOR = '#2f6fd6';
    const HEX = /^#[0-9a-fA-F]{6}$/;
    const netError = () => Swal.fire('ทำรายการไม่สำเร็จ', 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ลองใหม่อีกครั้ง', 'error');

    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => new bootstrap.Tooltip(el));

    function setColor(c) {
        if (!HEX.test(c)) { return; }
        c = c.toLowerCase();
        $('#rf_color').val(c);
        $('#rf_hex').val(c);
        modalEl.style.setProperty('--room', c);
        $('#rf_prev_chip, #rf_prev_ev').each(function () { this.style.setProperty('--room', c); });
        $('#rf_swatches .rm-swatch').each(function () { $(this).toggleClass('is-on', $(this).data('c') === c); });
    }
    function setName(n) { $('#rf_prev_name').text(n || 'ชื่อห้อง'); }

    function openForm(mode, data) {
        const isEdit = mode === 'edit';
        $('#roomModalTitle').text(isEdit ? 'แก้ไขห้อง' : 'เพิ่มห้องใหม่');
        $('#rf_submit').text(isEdit ? 'บันทึกการเปลี่ยนแปลง' : 'เพิ่มห้อง');
        $('#rf_action').val(isEdit ? 'edit' : 'add');
        $('#rf_id').val(isEdit ? data.id : '');
        $('#rf_name').val(isEdit ? data.name : '');
        setName(isEdit ? data.name : '');
        setColor(isEdit ? data.color : DEFAULT_COLOR);
        modal.show();
    }
    modalEl.addEventListener('shown.bs.modal', () => $('#rf_name').trigger('focus'));

    $('#rmAddBtn, #rmAddBtn2').on('click', () => openForm('add'));
    $('#roomGrid').on('click', '.rm-edit', function () {
        const $c = $(this).closest('.rm-card');
        openForm('edit', { id: $c.data('id'), name: String($c.data('name')), color: String($c.data('color')) });
    });

    $('#rf_name').on('input', function () { setName(this.value); });
    $('#rf_color').on('input', function () { setColor(this.value); });
    $('#rf_hex').on('input', function () {
        let v = this.value.trim();
        if (v && v[0] !== '#') { v = '#' + v; }
        if (HEX.test(v)) { setColor(v); }
    });
    $('#rf_swatches').on('click', '.rm-swatch', function () { setColor(String($(this).data('c'))); });

    $('#roomForm').on('submit', function (e) {
        e.preventDefault();
        if (!HEX.test($('#rf_color').val())) { Swal.fire('รหัสสีไม่ถูกต้อง', 'กรุณาเลือกสีใหม่', 'warning'); return; }
        const isEdit = $('#rf_action').val() === 'edit';
        const $btn = $('#rf_submit').prop('disabled', true);
        $.ajax({
            url: '../api/manage_room.php', type: 'POST', dataType: 'json', data: $(this).serialize(),
            success: function (res) {
                if (res.success) {
                    modal.hide();
                    Swal.fire({ icon: 'success', title: isEdit ? 'แก้ไขห้องแล้ว' : 'เพิ่มห้องแล้ว', timer: 1200, showConfirmButton: false }).then(() => location.reload());
                } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
            },
            error: netError,
            complete: function () { $btn.prop('disabled', false); }
        });
    });

    $('#roomGrid').on('click', '.rm-delete', function () {
        const $c = $(this).closest('.rm-card');
        const id = $c.data('id'), name = String($c.data('name'));
        Swal.fire({
            title: 'ลบห้องนี้?', text: name + ': ห้องนี้ยังไม่มีการจองเลย ลบแล้วกู้คืนไม่ได้',
            icon: 'warning', showCancelButton: true,
            confirmButtonText: 'ลบห้อง', confirmButtonColor: '#dc3545', cancelButtonText: 'ไม่ลบ'
        }).then(function (r) {
            if (!r.isConfirmed) { return; }
            $.ajax({
                url: '../api/manage_room.php', type: 'POST', dataType: 'json', data: { action: 'delete', id: id },
                success: function (res) {
                    if (res.success) {
                        Swal.fire({ icon: 'success', title: 'ลบห้องแล้ว', timer: 1100, showConfirmButton: false }).then(() => location.reload());
                    } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
                },
                error: netError
            });
        });
    });
});
</script>
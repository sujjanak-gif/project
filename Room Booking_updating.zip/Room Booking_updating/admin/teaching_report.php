<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';
require_admin();

$page_title = "รายงานการใช้ห้องเพื่อการสอน";
include 'layouts/admin_header.php';

/* =====================================================================
   Helpers (prefix rp_)
   ===================================================================== */
function rp_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function rp_get($key, $default = '') {
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? trim($_GET[$key]) : $default;
}

function rp_url(array $set = [], array $unset = []) {
    $q = $_GET;
    foreach ($unset as $k) { unset($q[$k]); }
    foreach ($set as $k => $v) {
        if ($v === null || $v === '') { unset($q[$k]); } else { $q[$k] = $v; }
    }
    return '?' . http_build_query($q);
}

function rp_date($ts) {
    static $m = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.', 7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    return date('j', $ts) . ' ' . $m[(int)date('n', $ts)] . ' ' . substr((string)(date('Y', $ts) + 543), -2);
}

function rp_dow_full($dow) { // DAYOFWEEK ของ MySQL: 1 = อาทิตย์
    static $a = [1 => 'อาทิตย์', 2 => 'จันทร์', 3 => 'อังคาร', 4 => 'พุธ', 5 => 'พฤหัสบดี', 6 => 'ศุกร์', 7 => 'เสาร์'];
    return $a[(int)$dow] ?? '';
}

function rp_period($s, $e) {
    $a = rp_date($s); $b = rp_date($e);
    return $a === $b ? $a : $a . ' ถึง ' . $b;
}

function rp_color($c) { return preg_match('/^#[0-9a-fA-F]{3,8}$/', (string)$c) ? $c : '#9aa7b6'; }

/* =====================================================================
   1) ตัวกรอง
   ===================================================================== */
$rooms = $pdo->query("SELECT id, name, color FROM rooms ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$view = rp_get('view', 'done');
if (!in_array($view, ['done', 'todo'], true)) { $view = 'done'; }
$filter_room = rp_get('room_id', 'all');
if ($filter_room !== 'all' && !ctype_digit($filter_room)) { $filter_room = 'all'; }
$filter_start = rp_get('start_date');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_start)) { $filter_start = ''; }
$filter_end = rp_get('end_date');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_end)) { $filter_end = ''; }
$search = rp_get('q');
if ($search !== '') { $search = function_exists('mb_substr') ? mb_substr($search, 0, 100) : substr($search, 0, 100); }
$per_page = 25;
$current_page = max(1, (int)rp_get('page', '1'));
$has_filters = ($filter_room !== 'all' || $filter_start !== '' || $filter_end !== '' || $search !== '');

// เงื่อนไขร่วม (ใช้กับตาราง bookings ชื่อ b)
$common = []; $common_params = [];
if ($filter_room !== 'all') { $common[] = "b.room_id = ?"; $common_params[] = (int)$filter_room; }
if ($filter_start !== '') { $common[] = "DATE(b.start_time) >= ?"; $common_params[] = $filter_start; }
if ($filter_end !== '') { $common[] = "DATE(b.start_time) <= ?"; $common_params[] = $filter_end; }

$like = $search !== '' ? '%' . addcslashes($search, '\\%_') . '%' : '';

/* ---------- รายงานที่บันทึกแล้ว ---------- */
$done_where = $common; $done_params = $common_params;
if ($search !== '') {
    $done_where[] = "(b.title LIKE ? OR b.instructor_name LIKE ? OR u.full_name LIKE ? OR r.name LIKE ? OR tr.doc_number LIKE ? OR tr.remarks LIKE ?)";
    for ($k = 0; $k < 6; $k++) { $done_params[] = $like; }
}
$done_where_sql = $done_where ? "WHERE " . implode(" AND ", $done_where) : "";
$done_from = "FROM teaching_reports tr
    JOIN bookings b ON b.id = tr.booking_id
    JOIN rooms r ON r.id = b.room_id
    JOIN users u ON u.id = b.user_id";
$done_group = "GROUP BY b.title, b.room_id, b.instructor_name, b.user_id, r.name, u.full_name";

/* ---------- การจองที่อนุมัติแล้วแต่ยังไม่อยู่ในรายงาน ---------- */
$todo_where = ["b.status = 'approved'", "b.is_deleted = 0", "NOT EXISTS (SELECT 1 FROM teaching_reports trx WHERE trx.booking_id = b.id)"];
$todo_where = array_merge($todo_where, $common);
$todo_params = $common_params;
if ($search !== '') {
    $todo_where[] = "(b.title LIKE ? OR b.instructor_name LIKE ? OR u.full_name LIKE ? OR r.name LIKE ?)";
    for ($k = 0; $k < 4; $k++) { $todo_params[] = $like; }
}
$todo_where_sql = "WHERE " . implode(" AND ", $todo_where);
$todo_from = "FROM bookings b
    JOIN rooms r ON r.id = b.room_id
    JOIN users u ON u.id = b.user_id";
$todo_group = "GROUP BY b.title, b.room_id, r.name, b.instructor_name, DAYOFWEEK(b.start_time)";

/* ---------- จำนวนในแต่ละแท็บ ---------- */
$st = $pdo->prepare("SELECT COUNT(*) FROM (SELECT 1 {$done_from} {$done_where_sql} {$done_group}) t");
$st->execute($done_params);
$count_done = (int)$st->fetchColumn();
$st = $pdo->prepare("SELECT COUNT(*) FROM (SELECT 1 {$todo_from} {$todo_where_sql} {$todo_group}) t");
$st->execute($todo_params);
$count_todo = (int)$st->fetchColumn();

$total_items = ($view === 'done') ? $count_done : $count_todo;
$total_pages = max(1, (int)ceil($total_items / $per_page));
if ($current_page > $total_pages) { $current_page = $total_pages; }
$offset = ($current_page - 1) * $per_page;

/* ---------- รายการของแท็บที่เปิดอยู่ ---------- */
if ($view === 'done') {
    $st = $pdo->prepare("
        SELECT MIN(tr.id) AS report_id,
               b.title, b.room_id, r.name AS room_name, b.instructor_name,
               (SELECT student_count FROM bookings WHERE id = MIN(b.id)) AS student_count,
               MIN(b.start_time) AS s, MAX(b.end_time) AS e,
               COUNT(DISTINCT b.id) AS sessions,
               GROUP_CONCAT(DISTINCT tr.id ORDER BY tr.id) AS report_ids,
               (SELECT doc_number FROM teaching_reports WHERE id = MIN(tr.id)) AS doc_first,
               (SELECT remarks FROM teaching_reports WHERE id = MIN(tr.id)) AS remarks_first,
               COUNT(DISTINCT NULLIF(tr.doc_number, '')) AS doc_variants,
               GROUP_CONCAT(DISTINCT NULLIF(tr.doc_number, '') SEPARATOR ', ') AS doc_all
        {$done_from} {$done_where_sql} {$done_group}
        ORDER BY MIN(tr.id) DESC
        LIMIT {$per_page} OFFSET {$offset}");
    $st->execute($done_params);
} else {
    $st = $pdo->prepare("
        SELECT MIN(b.id) AS first_id,
               b.title, b.room_id, r.name AS room_name, b.instructor_name,
               (SELECT student_count FROM bookings WHERE id = MIN(b.id)) AS student_count,
               MIN(b.start_time) AS s, MAX(b.end_time) AS e,
               COUNT(*) AS sessions,
               GROUP_CONCAT(b.id ORDER BY b.id) AS booking_ids,
               DAYOFWEEK(b.start_time) AS dow
        {$todo_from} {$todo_where_sql} {$todo_group}
        ORDER BY MAX(b.end_time) DESC, b.title ASC
        LIMIT {$per_page} OFFSET {$offset}");
    $st->execute($todo_params);
}
$items = $st->fetchAll(PDO::FETCH_ASSOC);

$now_ts = time();
$first_no = $total_items > 0 ? $offset + 1 : 0;
$last_no = min($offset + $per_page, $total_items);
$room_color_map = [];
foreach ($rooms as $rm) { $room_color_map[(int)$rm['id']] = rp_color($rm['color']); }
$export_url = '../api/export_csv.php?room_id=' . urlencode($filter_room);
?>

<style>
.rp-page { --rp-ink:#1c2733; --rp-muted:#667587; --rp-line:#e3e8ee; --rp-navy:#123456; --rp-brand:#003399;
    --rp-warn-bg:#fff3d1; --rp-warn-fg:#7a5200; --rp-warn-bar:#e0a100; --rp-ok-bg:#dcf2e5; --rp-ok-fg:#14613a; --rp-ok-bar:#2e9d62; --rp-info:#2c5fb3;
    color:var(--rp-ink); }
.rp-head { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-end; gap:12px; margin-bottom:16px; }
.rp-head h1 { font-size:1.65rem; font-weight:500; margin:0; }
.rp-head p { margin:2px 0 0; color:var(--rp-muted); }
.rp-panel { background:#fff; border:1px solid var(--rp-line); border-radius:14px; box-shadow:0 1px 2px rgba(18,52,86,.04); }
.rp-tabs { display:flex; gap:2px; padding:0 14px; border-bottom:1px solid var(--rp-line); overflow-x:auto; }
.rp-tab { display:inline-flex; align-items:center; gap:8px; padding:14px 12px 12px; border-bottom:3px solid transparent; color:var(--rp-muted); text-decoration:none; font-weight:500; white-space:nowrap; }
.rp-tab:hover { color:var(--rp-ink); }
.rp-tab.is-active { color:var(--rp-ink); border-bottom-color:var(--rp-brand); }
.rp-count { min-width:24px; padding:0 8px; border-radius:999px; background:#eef1f5; color:var(--rp-muted); font-size:.8rem; line-height:22px; text-align:center; }
.rp-tab.is-active .rp-count { background:var(--rp-brand); color:#fff; }
.rp-tab--todo .rp-count.has-items { background:var(--rp-warn-bg); color:var(--rp-warn-fg); }
.rp-tab--todo.is-active .rp-count.has-items { background:var(--rp-warn-bar); color:#fff; }
.rp-filters { display:flex; flex-wrap:wrap; align-items:center; gap:10px; padding:14px 18px; background:#fafbfc; border-bottom:1px solid var(--rp-line); }
.rp-filters .rp-search { flex:1 1 240px; min-width:200px; }
.rp-filters .form-select { width:auto; max-width:300px; }
.rp-range { display:inline-flex; align-items:center; gap:6px; }
.rp-toolbar { padding:10px 18px; font-size:.9rem; color:var(--rp-muted); border-bottom:1px solid var(--rp-line); text-align:right; }
.rp-rows { list-style:none; margin:0; padding:0; }
.rp-row { display:grid; grid-template-columns:minmax(0,1.6fr) minmax(0,1fr) 150px minmax(0,1.2fr) auto; grid-template-areas:"main who period doc actions"; gap:16px; align-items:center; padding:14px 18px; border-bottom:1px solid var(--rp-line); box-shadow:inset 3px 0 0 var(--bar, var(--rp-ok-bar)); }
.rp-row.is-todo { --bar:var(--rp-warn-bar); }
.rp-row:hover { background:#f7f9fc; }
.rp-main { grid-area:main; min-width:0; }
.rp-title { font-weight:500; font-size:1.02rem; overflow-wrap:anywhere; }
.rp-sub { font-size:.88rem; color:var(--rp-muted); overflow-wrap:anywhere; }
.rp-dot { display:inline-block; width:9px; height:9px; border-radius:50%; margin-right:6px; }
.rp-who { grid-area:who; min-width:0; font-size:.92rem; overflow-wrap:anywhere; }
.rp-period { grid-area:period; font-size:.9rem; }
.rp-doc { grid-area:doc; min-width:0; font-size:.92rem; overflow-wrap:anywhere; }
.rp-actions { grid-area:actions; display:flex; justify-content:flex-end; align-items:center; gap:6px; }
.rp-chip { display:inline-flex; align-items:center; gap:6px; padding:1px 8px; border-radius:6px; font-size:.78rem; border:1px solid var(--rp-line); background:#f6f8fa; color:var(--rp-muted); margin-top:6px; margin-right:6px; }
.rp-chip--warn { background:var(--rp-warn-bg); border-color:#f1d78a; color:var(--rp-warn-fg); }
.rp-chip--info { background:#e9f0fc; border-color:#c3d4f1; color:var(--rp-info); }
.rp-chip--ok { background:var(--rp-ok-bg); border-color:#b5dfc6; color:var(--rp-ok-fg); }
.rp-empty { padding:56px 18px; text-align:center; color:var(--rp-muted); }
.rp-empty h2 { font-size:1.15rem; font-weight:500; color:var(--rp-ink); margin-bottom:6px; }
.rp-pager { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:10px; padding:14px 18px; }
.rp-pager .pagination { margin:0; }
.rp-sum { background:#f6f8fa; border:1px solid var(--rp-line); border-radius:10px; padding:12px 14px; margin-bottom:16px; font-size:.92rem; }
.rp-sum .t { font-weight:500; margin-bottom:4px; overflow-wrap:anywhere; }
.rp-sum .r { color:var(--rp-muted); overflow-wrap:anywhere; }
.rp-row .btn:focus-visible { outline:2px solid var(--rp-brand); outline-offset:2px; }
@media (max-width: 1199.98px) {
    .rp-row { grid-template-columns:1fr; grid-template-areas:"main" "who" "period" "doc" "actions"; gap:6px; }
    .rp-actions { justify-content:flex-start; margin-top:6px; }
}
@media (prefers-reduced-motion: reduce) { .rp-page * { transition:none !important; } }
</style>

<div class="container-fluid px-4 py-4 rp-page">

    <header class="rp-head">
        <div>
            <h1>รายงานการใช้ห้องเพื่อการสอน</h1>
            <p>บันทึกเลขที่หนังสือและหมายเหตุให้การจองที่อนุมัติแล้ว เพื่อใช้ส่งออกเป็นรายงาน</p>
        </div>
        <a href="<?php echo rp_h($export_url); ?>" class="btn btn-outline-success btn-sm"
           title="ส่งออกรายงานที่บันทึกแล้วตามห้องที่เลือก">
            <i class="fas fa-file-csv me-1"></i> ส่งออก CSV
        </a>
    </header>

    <section class="rp-panel">
        <nav class="rp-tabs" aria-label="มุมมองรายงาน">
            <a class="rp-tab rp-tab--done <?php echo $view === 'done' ? 'is-active' : ''; ?>" href="<?php echo rp_h(rp_url(['view' => 'done'], ['page'])); ?>" <?php echo $view === 'done' ? 'aria-current="page"' : ''; ?>>
                บันทึกในรายงานแล้ว <span class="rp-count"><?php echo $count_done; ?></span>
            </a>
            <a class="rp-tab rp-tab--todo <?php echo $view === 'todo' ? 'is-active' : ''; ?>" href="<?php echo rp_h(rp_url(['view' => 'todo'], ['page'])); ?>" <?php echo $view === 'todo' ? 'aria-current="page"' : ''; ?>>
                ยังไม่ได้บันทึก <span class="rp-count <?php echo $count_todo > 0 ? 'has-items' : ''; ?>"><?php echo $count_todo; ?></span>
            </a>
        </nav>

        <form method="GET" id="rpFilters" class="rp-filters">
            <input type="hidden" name="view" value="<?php echo rp_h($view); ?>">
            <div class="rp-search">
                <input type="search" name="q" class="form-control form-control-sm" value="<?php echo rp_h($search); ?>"
                       placeholder="ค้นหารายวิชา อาจารย์ ผู้จอง ห้อง หรือเลขที่หนังสือ" aria-label="ค้นหา">
            </div>
            <select name="room_id" class="form-select form-select-sm" aria-label="ห้อง">
                <option value="all">ทุกห้อง</option>
                <?php foreach ($rooms as $rm): ?>
                    <option value="<?php echo (int)$rm['id']; ?>" <?php echo ($filter_room == $rm['id']) ? 'selected' : ''; ?>><?php echo rp_h($rm['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <div class="rp-range">
                <input type="date" name="start_date" class="form-control form-control-sm" value="<?php echo rp_h($filter_start); ?>" aria-label="ตั้งแต่วันที่">
                <span class="text-muted">ถึง</span>
                <input type="date" name="end_date" class="form-control form-control-sm" value="<?php echo rp_h($filter_end); ?>" aria-label="ถึงวันที่">
            </div>
            <?php if ($has_filters): ?>
                <a href="<?php echo rp_h(rp_url([], ['q', 'room_id', 'start_date', 'end_date', 'page'])); ?>" class="btn btn-link btn-sm">ล้างตัวกรอง</a>
            <?php endif; ?>
        </form>

        <?php if (empty($items)): ?>
            <div class="rp-empty">
                <?php if ($has_filters): ?>
                    <h2>ไม่พบรายการตามตัวกรอง</h2>
                    <p>ลองเปลี่ยนคำค้น ห้อง หรือช่วงวันที่ หรือล้างตัวกรอง</p>
                    <a class="btn btn-outline-primary btn-sm" href="<?php echo rp_h(rp_url([], ['q', 'room_id', 'start_date', 'end_date', 'page'])); ?>">ล้างตัวกรอง</a>
                <?php elseif ($view === 'done'): ?>
                    <h2>ยังไม่มีรายการในรายงาน</h2>
                    <p>เลือกจากแท็บ "ยังไม่ได้บันทึก" เพื่อเพิ่มการจองเข้ารายงาน</p>
                    <a class="btn btn-outline-primary btn-sm" href="<?php echo rp_h(rp_url(['view' => 'todo'], ['page'])); ?>">ดูรายการที่ยังไม่ได้บันทึก</a>
                <?php else: ?>
                    <h2>ไม่มีรายการที่รอบันทึก</h2>
                    <p>ทุกการจองที่อนุมัติแล้วอยู่ในรายงานครบแล้ว</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="rp-toolbar">แสดง <?php echo $first_no; ?>-<?php echo $last_no; ?> จาก <?php echo $total_items; ?> รายการ</div>

            <ul class="rp-rows" id="rpList">
            <?php foreach ($items as $it):
                $s = strtotime($it['s']); $e = strtotime($it['e']);
                $color = $room_color_map[(int)$it['room_id']] ?? '#9aa7b6';
                $students = ($it['student_count'] === null || $it['student_count'] === '') ? '' : (string)(int)$it['student_count'];
                if ($view === 'done') {
                    $payload = [
                        'mode' => 'edit', 'title' => $it['title'], 'room' => $it['room_name'], 'instructor' => $it['instructor_name'],
                        'students' => $students, 'period' => rp_period($s, $e), 'sessions' => (int)$it['sessions'],
                        'ids' => $it['report_ids'], 'first_id' => (int)$it['report_id'],
                        'doc' => $it['doc_first'], 'remarks' => $it['remarks_first'], 'doc_variants' => (int)$it['doc_variants'],
                    ];
                } else {
                    $payload = [
                        'mode' => 'create', 'title' => $it['title'], 'room' => $it['room_name'], 'instructor' => $it['instructor_name'],
                        'students' => $students, 'period' => rp_period($s, $e), 'sessions' => (int)$it['sessions'],
                        'ids' => $it['booking_ids'], 'doc' => '', 'remarks' => '', 'doc_variants' => 0,
                    ];
                }
            ?>
                <li class="rp-row <?php echo $view === 'todo' ? 'is-todo' : ''; ?>" data-item="<?php echo rp_h(json_encode($payload, JSON_UNESCAPED_UNICODE)); ?>">
                    <div class="rp-main">
                        <div class="rp-title"><?php echo rp_h($it['title']); ?></div>
                        <div class="rp-sub"><span class="rp-dot" style="background:<?php echo rp_h($color); ?>"></span><?php echo rp_h($it['room_name']); ?></div>
                        <div>
                            <span class="rp-chip"><i class="far fa-calendar-check"></i> <?php echo (int)$it['sessions']; ?> ครั้ง</span>
                            <?php if ($view === 'todo'): ?>
                                <?php if ((int)$it['sessions'] > 1): ?><span class="rp-chip rp-chip--info">ทุกวัน<?php echo rp_h(rp_dow_full($it['dow'])); ?></span><?php endif; ?>
                                <?php if ($e > $now_ts): ?><span class="rp-chip">ยังไม่ถึงวันใช้งานครบ</span><?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="rp-who">
                        <div><?php echo $it['instructor_name'] !== '' && $it['instructor_name'] !== null ? '<i class="fas fa-user-tie me-1 text-muted"></i>' . rp_h($it['instructor_name']) : '<span class="rp-sub">ไม่ระบุอาจารย์</span>'; ?></div>
                        <?php if ($students !== ''): ?><div class="rp-sub"><i class="fas fa-users me-1"></i><?php echo rp_h($students); ?> คน</div><?php endif; ?>
                    </div>

                    <div class="rp-period"><?php echo rp_h(rp_period($s, $e)); ?></div>

                    <div class="rp-doc">
                        <?php if ($view === 'done'): ?>
                            <?php if (!empty($it['doc_all'])): ?>
                                <div><?php echo rp_h($it['doc_all']); ?></div>
                                <?php if ((int)$it['doc_variants'] > 1): ?><span class="rp-chip rp-chip--warn" style="margin-top:2px">มีเลขที่หนังสือหลายค่า</span><?php endif; ?>
                            <?php else: ?>
                                <span class="rp-chip rp-chip--warn" style="margin-top:0">ยังไม่มีเลขที่หนังสือ</span>
                            <?php endif; ?>
                            <?php if (!empty($it['remarks_first'])): ?><div class="rp-sub"><?php echo rp_h($it['remarks_first']); ?></div><?php endif; ?>
                        <?php else: ?>
                            <span class="rp-sub">ยังไม่ได้บันทึกในรายงาน</span>
                        <?php endif; ?>
                    </div>

                    <div class="rp-actions">
                        <?php if ($view === 'done'): ?>
                            <button type="button" class="btn btn-outline-secondary btn-sm rp-open"><i class="fas fa-pen me-1"></i>แก้ไข</button>
                            <div class="dropdown">
                                <button type="button" class="btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false" aria-label="เมนูเพิ่มเติม"><i class="fas fa-ellipsis-vertical"></i></button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><button type="button" class="dropdown-item text-danger rp-delete"><i class="fas fa-trash fa-fw me-2"></i>ลบออกจากรายงาน</button></li>
                                </ul>
                            </div>
                        <?php else: ?>
                            <button type="button" class="btn btn-primary btn-sm rp-open"><i class="fas fa-plus me-1"></i>บันทึกในรายงาน</button>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; ?>
            </ul>

            <?php if ($total_pages > 1): ?>
            <div class="rp-pager">
                <span class="text-muted small">หน้า <?php echo $current_page; ?> จาก <?php echo $total_pages; ?></span>
                <nav aria-label="เปลี่ยนหน้า">
                    <ul class="pagination pagination-sm">
                        <li class="page-item <?php echo $current_page <= 1 ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo rp_h(rp_url(['page' => $current_page - 1])); ?>">ก่อนหน้า</a></li>
                        <?php
                        $shown = [];
                        for ($p = 1; $p <= $total_pages; $p++) {
                            if ($p === 1 || $p === $total_pages || abs($p - $current_page) <= 2) { $shown[] = $p; }
                        }
                        $prev_p = 0;
                        foreach ($shown as $p) {
                            if ($p - $prev_p > 1) { echo '<li class="page-item disabled"><span class="page-link">…</span></li>'; }
                            echo '<li class="page-item ' . ($p === $current_page ? 'active' : '') . '"><a class="page-link" href="' . rp_h(rp_url(['page' => $p])) . '">' . $p . '</a></li>';
                            $prev_p = $p;
                        }
                        ?>
                        <li class="page-item <?php echo $current_page >= $total_pages ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo rp_h(rp_url(['page' => $current_page + 1])); ?>">ถัดไป</a></li>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>

<!-- บันทึก / แก้ไขรายการในรายงาน -->
<div class="modal fade" id="rpModal" tabindex="-1" aria-labelledby="rpModalTitle" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="rpModalTitle">บันทึกในรายงาน</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
      </div>
      <form id="rpForm" autocomplete="off">
        <div class="modal-body">
            <div class="rp-sum">
                <div class="t" id="rpSumTitle"></div>
                <div class="r" id="rpSumRoom"></div>
                <div class="r" id="rpSumWho"></div>
                <div class="r" id="rpSumPeriod"></div>
            </div>
            <div class="alert alert-warning py-2 small d-none" id="rpVariantNote">กลุ่มนี้มีเลขที่หนังสือหลายค่า การบันทึกจะแทนที่ทุกรายการในกลุ่มด้วยค่าที่กรอกนี้</div>
            <div class="mb-3">
                <label for="rp_doc" class="form-label">เลขที่หนังสือ</label>
                <input type="text" id="rp_doc" name="doc_number" class="form-control" maxlength="100">
            </div>
            <div class="mb-1">
                <label for="rp_remarks" class="form-label">หมายเหตุ</label>
                <textarea id="rp_remarks" name="remarks" rows="3" class="form-control"></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
            <button type="submit" class="btn btn-primary" id="rpSubmit">บันทึก</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
$(function () {
    const modalEl = document.getElementById('rpModal');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    let current = null;
    const netError = () => Swal.fire('ทำรายการไม่สำเร็จ', 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ลองใหม่อีกครั้ง', 'error');
    const parseIds = s => String(s).split(',').map(n => parseInt(n, 10)).filter(n => n > 0);
    const readItem = el => JSON.parse($(el).closest('.rp-row').attr('data-item'));

    /* ---------- เปิดหน้าต่างบันทึก/แก้ไข ---------- */
    $('#rpList').on('click', '.rp-open', function () {
        current = readItem(this);
        const isEdit = current.mode === 'edit';
        $('#rpModalTitle').text(isEdit ? 'แก้ไขข้อมูลในรายงาน' : 'บันทึกในรายงาน');
        $('#rpSubmit').text(isEdit ? 'บันทึกการแก้ไข' : 'บันทึกในรายงาน');
        $('#rpSumTitle').text(current.title);
        $('#rpSumRoom').text(current.room);
        $('#rpSumWho').text([current.instructor ? 'อาจารย์ ' + current.instructor : '', current.students ? current.students + ' คน' : ''].filter(Boolean).join('  '));
        $('#rpSumPeriod').text(current.period + '  (' + current.sessions + ' ครั้ง)');
        $('#rp_doc').val(current.doc || '');
        $('#rp_remarks').val(current.remarks || '');
        $('#rpVariantNote').toggleClass('d-none', !(isEdit && current.doc_variants > 1));
        modal.show();
    });
    modalEl.addEventListener('shown.bs.modal', () => $('#rp_doc').trigger('focus'));

    /* ---------- บันทึก ---------- */
    $('#rpForm').on('submit', function (e) {
        e.preventDefault();
        if (!current) { return; }
        const isEdit = current.mode === 'edit';
        const $btn = $('#rpSubmit').prop('disabled', true);
        const data = isEdit
            ? { action: 'update', report_id: current.first_id, report_ids: parseIds(current.ids), doc_number: $('#rp_doc').val(), remarks: $('#rp_remarks').val() }
            : { booking_ids_selected: current.ids, doc_number: $('#rp_doc').val(), remarks: $('#rp_remarks').val() };
        $.ajax({
            url: isEdit ? '../api/manage_teaching_report.php' : '../api/create_teaching_report.php',
            type: 'POST', dataType: 'json', data: data,
            success: function (res) {
                if (res.success) {
                    modal.hide();
                    Swal.fire({ icon: 'success', title: isEdit ? 'บันทึกการแก้ไขแล้ว' : 'บันทึกในรายงานแล้ว', text: res.message || '', timer: 1400, showConfirmButton: false })
                        .then(() => location.reload());
                } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
            },
            error: netError,
            complete: function () { $btn.prop('disabled', false); }
        });
    });

    /* ---------- ลบออกจากรายงาน (ไม่ลบการจอง) ---------- */
    $('#rpList').on('click', '.rp-delete', function () {
        const item = readItem(this);
        const ids = parseIds(item.ids);
        Swal.fire({
            title: 'ลบออกจากรายงาน',
            text: item.title + ': ลบ ' + ids.length + ' รายการออกจากรายงาน การจองยังอยู่ครบ และจะกลับไปอยู่ในแท็บ "ยังไม่ได้บันทึก"',
            icon: 'warning', showCancelButton: true,
            confirmButtonText: 'ลบออกจากรายงาน', confirmButtonColor: '#dc3545', cancelButtonText: 'ไม่ลบ'
        }).then(function (r) {
            if (!r.isConfirmed) { return; }
            $.ajax({
                url: '../api/manage_teaching_report.php', type: 'POST', dataType: 'json',
                data: { action: 'delete_multiple', report_ids: ids },
                success: function (res) {
                    if (res.success) {
                        Swal.fire({ icon: 'success', title: 'ลบออกจากรายงานแล้ว', text: res.message || '', timer: 1300, showConfirmButton: false })
                            .then(() => location.reload());
                    } else { Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
                },
                error: netError
            });
        });
    });

    /* ---------- ตัวกรอง ---------- */
    const form = document.getElementById('rpFilters');
    $('#rpFilters select, #rpFilters input[type=date]').on('change', function () { form.submit(); });
    $('#rpFilters input[type=search]').on('search', function () { form.submit(); });
});
</script>
<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db.php';
include_once '../includes/functions.php';
require_admin();

$page_title = "รายงานการใช้ห้องเพื่อการสอน";
include 'layouts/admin_header.php';

// --- Fetch Data for the Report Table (Grouped) ---
// เราจะ Group by รายวิชา, ผู้สอน, ห้อง เพื่อให้สรุปรายการซ้ำได้
$reports_sql = "
    SELECT
        MIN(tr.id) as report_id,
        tr.doc_number,
        tr.remarks,
        b.title as course_code,
        b.room_id,
        r.name as room_name,
        b.user_id,
        u.full_name as user_name,
        (SELECT student_count FROM bookings WHERE id = MIN(b.id)) as student_count, /* <--- เปลี่ยนเป็นแบบนี้ */
        b.instructor_name,
        MIN(b.start_time) as overall_start_time,
        MAX(b.end_time) as overall_end_time,
        GROUP_CONCAT(DISTINCT b.id) as all_booking_ids_in_report,
        GROUP_CONCAT(DISTINCT tr.id) as all_report_ids
    FROM teaching_reports tr
    JOIN bookings b ON tr.booking_id = b.id
    JOIN rooms r ON b.room_id = r.id
    JOIN users u ON b.user_id = u.id
    GROUP BY b.title, b.room_id, b.instructor_name, b.instructor_name, b.user_id, r.name, u.full_name
    ORDER BY MIN(tr.id) DESC
";
$reports_stmt = $pdo->query($reports_sql);
$reports = $reports_stmt->fetchAll();

// --- Fetch Approved Bookings for the dropdown (Grouped) ---
$bookings_stmt = $pdo->query("
    SELECT
        MIN(id) as id,
        title,
        instructor_name,
        SUM(student_count) as total_student_count,
        room_id,
        (SELECT name FROM rooms WHERE id = room_id) as room_name,
        MIN(start_time) as start_time_grouped,
        MAX(end_time) as end_time_grouped,
        GROUP_CONCAT(id) as all_booking_ids_for_dropdown
    FROM bookings
    WHERE status = 'approved'
    AND is_deleted = 0  /* <--- เพิ่มเงื่อนไขนี้ */
    AND id NOT IN (SELECT booking_id FROM teaching_reports)
    GROUP BY title, room_id, instructor_name, DAYOFWEEK(start_time)
    ORDER BY title ASC, start_time_grouped DESC
");
$available_bookings = $bookings_stmt->fetchAll();

?>

<div class="container-fluid px-4 py-4">
    <h1 class="mt-2 mb-4">รายงานการใช้ห้อง</h1>

    <div class="card mb-4">
        <div class="card-header"><i class="fas fa-plus-circle me-1"></i>เพิ่มข้อมูลในรายงาน</div>
        <div class="card-body">
            <form id="addReportForm" action="../api/create_teaching_report.php" method="POST">
                <div class="mb-3">
                    <label for="booking_ids_selected" class="form-label">เลือกจากการจองที่อนุมัติแล้ว</label>
                    <select name="booking_ids_selected" id="booking_ids_selected" class="form-select" required>
                        <option value="">-- กรุณาเลือกรายการ --</option>
                        <?php foreach($available_bookings as $booking): ?>
                            <option
                                value="<?php echo htmlspecialchars($booking['all_booking_ids_for_dropdown']); ?>"
                                data-title="<?php echo htmlspecialchars($booking['title']); ?>"
                                data-instructor="<?php echo htmlspecialchars($booking['instructor_name']); ?>"
                                data-students="<?php echo htmlspecialchars($booking['total_student_count']); ?>"
                                data-start-time="<?php echo date('d/m/Y H:i', strtotime($booking['start_time_grouped'])); ?>"
                                data-end-time="<?php echo date('d/m/Y H:i', strtotime($booking['end_time_grouped'])); ?>"
                            >
                                <?php echo htmlspecialchars($booking['title']); ?> (<?php echo htmlspecialchars($booking['room_name']); ?> | <?php echo date('d/m/Y', strtotime($booking['start_time_grouped'])); ?> - <?php echo date('d/m/Y', strtotime($booking['end_time_grouped'])); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="form-text text-muted"></small>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="course_code_display" class="form-label">รายวิชา (จากการจอง)</label>
                        <input type="text" id="course_code_display" class="form-control bg-light" readonly>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="student_count_display" class="form-label">จำนวนนักศึกษา (จากการจอง)</label>
                        <input type="text" id="student_count_display" class="form-control bg-light" readonly>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="instructor_name_display" class="form-label">อาจารย์ผู้สอน (จากการจอง)</label>
                        <input type="text" id="instructor_name_display" class="form-control bg-light" readonly>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="start_time_display" class="form-label">วัน-เวลาเริ่มต้น (รวม)</label>
                        <input type="text" id="start_time_display" class="form-control bg-light" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="end_time_display" class="form-label">วัน-เวลาสิ้นสุด (รวม)</label>
                        <input type="text" id="end_time_display" class="form-control bg-light" readonly>
                    </div>
                </div>
                <hr>
                <p class="fw-bold">ข้อมูลเพิ่มเติมสำหรับรายงาน (Admin กรอก)</p>
                   <div class="mb-3">
                    <label for="doc_number" class="form-label">เลขที่หนังสือ</label>
                    <input type="text" name="doc_number" id="doc_number" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="remarks" class="form-label">หมายเหตุ</label>
                    <textarea name="remarks" id="remarks" rows="2" class="form-control"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">บันทึกรายงาน</button>
            </form>
        </div>
    </div>

    <div class="card mb-4">
           <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-table me-1"></i>ตารางสรุปรายงาน</span>
            <a href="../api/export_csv.php" class="btn btn-success btn-sm"><i class="fas fa-file-csv me-1"></i> Export to CSV</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>ลำดับ</th>
                            <th>เลขที่หนังสือ</th>
                            <th>รายวิชา</th>
                            <th>ห้อง</th>
                            <th>อาจารย์ผู้สอน</th>
                            <th>จำนวน นศ.</th> <th>ช่วงเวลา (รวม)</th>
                            <th>หมายเหตุ</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($reports)): ?>
                            <tr><td colspan="9" class="text-center">ยังไม่มีข้อมูลรายงาน</td></tr>
                        <?php endif; ?>
                        <?php foreach($reports as $index => $report): ?>
                        <tr id="report-row-<?php echo $report['report_id']; ?>">
                            <td><?php echo $index + 1; ?></td>
                            <td data-field="doc_number"><?php echo htmlspecialchars($report['doc_number']); ?></td>
                            <td><?php echo htmlspecialchars($report['course_code']); ?></td>
                            <td><?php echo htmlspecialchars($report['room_name']); ?></td>
                            <td><?php echo htmlspecialchars($report['instructor_name']); ?></td>
                            <td><?php echo htmlspecialchars($report['student_count']); ?></td> <td><?php echo date('d/m/Y', strtotime($report['overall_start_time'])) . ' - ' . date('d/m/Y', strtotime($report['overall_end_time'])); ?></td>
                            <td data-field="remarks"><?php echo htmlspecialchars($report['remarks']); ?></td>
                            <td>
                                <button class="btn btn-sm btn-info btn-edit" data-id="<?php echo $report['report_id']; ?>"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-sm btn-danger btn-delete" data-ids="<?php echo htmlspecialchars($report['all_report_ids']); ?>"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editReportModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">แก้ไขข้อมูลรายงาน</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="editReportForm">
            <div class="modal-body">
                <input type="hidden" name="action" value="update">
                <input type="hidden" id="edit_report_id" name="report_id">
                <div class="mb-3">
                    <label for="edit_doc_number" class="form-label">เลขที่หนังสือ</label>
                    <input type="text" name="doc_number" id="edit_doc_number" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="edit_remarks" class="form-label">หมายเหตุ</label>
                    <textarea name="remarks" id="edit_remarks" rows="3" class="form-control"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                <button type="submit" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
            </div>
      </form>
    </div>
  </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
$(document).ready(function() {
    // --- Auto-populate form on booking selection ---
    $('#booking_ids_selected').on('change', function() {
        const selectedOption = $(this).find('option:selected');
        
        if (selectedOption.length > 0 && selectedOption.val() !== '') {
            const title = selectedOption.data('title') || '';
            const instructor = selectedOption.data('instructor') || '';
            const students = selectedOption.data('students') || 0;
            const startTime = selectedOption.data('start-time') || '';
            const endTime = selectedOption.data('end-time') || '';

            $('#course_code_display').val(title);
            $('#instructor_name_display').val(instructor);
            $('#student_count_display').val(students);
            $('#start_time_display').val(startTime);
            $('#end_time_display').val(endTime);
        } else {
            // Clear fields if nothing is selected
            $('#course_code_display').val('');
            $('#instructor_name_display').val('');
            $('#student_count_display').val('');
            $('#start_time_display').val('');
            $('#end_time_display').val('');
        }
        $('#doc_number').val(''); // Clear doc number as it's specific to each report
    });

    // Add Report Form Submission (ใช้ AJAX)
    $('#addReportForm').on('submit', function(e) {
        e.preventDefault(); // ป้องกันการ submit form แบบปกติ

        const formData = $(this).serialize(); // เก็บข้อมูล form

        $.ajax({
            url: '../api/create_teaching_report.php', // URL ของ API
            type: 'POST', // Method
            data: formData, // ข้อมูลที่ส่ง
            dataType: 'json', // คาดหวัง response เป็น JSON
            success: function(response) {
                if (response.success) {
                    Swal.fire('สำเร็จ!', response.message, 'success').then(() => {
                        location.reload(); // โหลดหน้าใหม่เมื่อสำเร็จ
                    });
                } else {
                    Swal.fire('เกิดข้อผิดพลาด!', response.message, 'error');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error("AJAX Error:", textStatus, errorThrown, jqXHR.responseText);
                Swal.fire('เกิดข้อผิดพลาด!', 'ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ หรือมีข้อผิดพลาดในการตอบกลับ', 'error');
            }
        });
    });

    // Edit Button Click
    $('.btn-edit').on('click', function() {
        const reportId = $(this).data('id');
        const row = $('#report-row-' + reportId);

        $('#edit_report_id').val(reportId);
        $('#edit_doc_number').val(row.find('[data-field="doc_number"]').text());
        $('#edit_remarks').val(row.find('[data-field="remarks"]').text());

        $('#editReportModal').modal('show');
    });

    // Edit Form Submission
    $('#editReportForm').on('submit', function(e) {
            e.preventDefault();
        $.ajax({
            url: '../api/manage_teaching_report.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#editReportModal').modal('hide');
                    Swal.fire('สำเร็จ!', 'แก้ไขข้อมูลเรียบร้อยแล้ว', 'success').then(() => {
                        location.reload(); // Reload page to see changes
                    });
                } else {
                    Swal.fire('เกิดข้อผิดพลาด!', response.message, 'error');
                }
            }
        });
    });

    // Delete Button Click
    $('.btn-delete').on('click', function() {
        let reportIdsString = $(this).data('ids');
        let reportIds = [];

        // Ensure reportIdsString is treated as a string before splitting.
        // This handles cases where data() might return a number or undefined for single IDs.
        if (typeof reportIdsString !== 'string' && reportIdsString !== undefined && reportIdsString !== null) {
            reportIdsString = String(reportIdsString);
        }

        if (typeof reportIdsString === 'string' && reportIdsString.length > 0) {
            reportIds = reportIdsString.split(',').map(id => parseInt(id.trim()));
        } else {
            console.error("Error: data-ids is not a valid string or is empty.", reportIdsString);
            Swal.fire('เกิดข้อผิดพลาด!', 'ไม่พบข้อมูลรายงานที่ต้องการลบ', 'error');
            return;
        }

        reportIds = reportIds.filter(id => !isNaN(id) && id > 0);

        if (reportIds.length === 0) {
            Swal.fire('ข้อมูลไม่ครบถ้วน!', 'ไม่พบ ID รายงานที่ต้องการลบ', 'warning');
            return;
        }

        Swal.fire({
            title: 'ยืนยันการลบ',
            text: "คุณแน่ใจหรือไม่ว่าต้องการลบรายงานนี้? การกระทำนี้ไม่สามารถย้อนกลับได้! (จะลบทุกรายการที่เกี่ยวข้องในกลุ่มนี้ด้วย)",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'ใช่, ลบเลย!',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../api/manage_teaching_report.php',
                    type: 'POST',
                    data: { action: 'delete_multiple', report_ids: reportIds },
                    dataType: 'json',
                    success: function(response) {
                           if (response.success) {
                                Swal.fire('สำเร็จ!', 'ลบรายงานเรียบร้อยแล้ว', 'success');
                                $('#report-row-' + reportIds[0]).fadeOut(500, function() { $(this).remove(); });
                            } else {
                                Swal.fire('เกิดข้อผิดพลาด!', response.message, 'error');
                            }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error("AJAX Error:", textStatus, errorThrown, jqXHR.responseText);
                        Swal.fire('เกิดข้อผิดพลาด!', 'ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้', 'error');
                    }
                });
            }
        });
    });
});
</script>
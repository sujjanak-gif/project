<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';
require_admin();

$page_title = "สถิติและรายงาน";
include 'layouts/admin_header.php';

/* =====================================================================
   Helpers (prefix st_)
   ===================================================================== */
function st_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function st_get($key, $default = '') {
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? trim($_GET[$key]) : $default;
}
function st_valid_date($d) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) { return false; }
    $p = explode('-', $d);
    return checkdate((int)$p[1], (int)$p[2], (int)$p[0]);
}
function st_month_short($m) {
    static $a = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.', 7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    return $a[(int)$m] ?? '';
}
function st_date($ts) {
    return date('j', $ts) . ' ' . st_month_short(date('n', $ts)) . ' ' . substr((string)(date('Y', $ts) + 543), -2);
}
function st_color($c) { return preg_match('/^#[0-9a-fA-F]{6}$/', (string)$c) ? $c : '#9aa7b6'; }
function st_hours($mins) {
    $h = round($mins / 60, 1);
    return (floor($h) == $h) ? number_format((int)$h) : number_format($h, 1);
}
function st_summary($pdo, $s, $e) {
    $q = $pdo->prepare("SELECT COUNT(*) AS n,
            COALESCE(SUM(TIMESTAMPDIFF(MINUTE, start_time, end_time)), 0) AS mins,
            COUNT(DISTINCT user_id) AS users
        FROM bookings WHERE status = 'approved' AND is_deleted = 0 AND start_time BETWEEN ? AND ?");
    $q->execute([$s . ' 00:00:00', $e . ' 23:59:59']);
    return $q->fetch(PDO::FETCH_ASSOC);
}
function st_delta($cur, $prev) {
    if ($prev <= 0) { return $cur > 0 ? ['flat', 'ช่วงก่อนหน้าไม่มีข้อมูลให้เทียบ'] : ['flat', 'ไม่มีข้อมูลในช่วงนี้']; }
    $p = (int)round(($cur - $prev) / $prev * 100);
    if ($p > 0) { return ['up', 'เพิ่มขึ้น ' . $p . '% จากช่วงก่อนหน้า']; }
    if ($p < 0) { return ['down', 'ลดลง ' . abs($p) . '% จากช่วงก่อนหน้า']; }
    return ['flat', 'เท่ากับช่วงก่อนหน้า'];
}

/* =====================================================================
   1) ช่วงเวลา (ค่าเริ่มต้น: ปีปัจจุบัน) และช่วงก่อนหน้าที่ยาวเท่ากัน
   ===================================================================== */
$start_date = st_get('start_date');
$end_date = st_get('end_date');
if (!st_valid_date($start_date)) { $start_date = date('Y-01-01'); }
if (!st_valid_date($end_date)) { $end_date = date('Y-12-31'); }
if ($start_date > $end_date) { $tmp = $start_date; $start_date = $end_date; $end_date = $tmp; }

$days = (int)floor((strtotime($end_date) - strtotime($start_date)) / 86400) + 1;
$prev_end = date('Y-m-d', strtotime($start_date . ' -1 day'));
$prev_start = date('Y-m-d', strtotime($start_date . ' -' . $days . ' days'));
$range = [$start_date . ' 00:00:00', $end_date . ' 23:59:59'];

$cur = st_summary($pdo, $start_date, $end_date);
$prev = st_summary($pdo, $prev_start, $prev_end);

$bounds = $pdo->query("SELECT MIN(DATE(start_time)) AS mn, MAX(DATE(start_time)) AS mx FROM bookings WHERE is_deleted = 0")->fetch(PDO::FETCH_ASSOC);
$all_min = $bounds['mn'] ?: date('Y-m-d');
$all_max = $bounds['mx'] ?: date('Y-m-d');

// สถานะของคำขอทั้งหมดในช่วงนี้
$st = $pdo->prepare("SELECT status, COUNT(*) FROM bookings WHERE is_deleted = 0 AND start_time BETWEEN ? AND ? GROUP BY status");
$st->execute($range);
$status_counts = $st->fetchAll(PDO::FETCH_KEY_PAIR);
$pending_n = (int)($status_counts['pending'] ?? 0);
$rejected_n = (int)($status_counts['rejected'] ?? 0);
$cancelled_n = (int)($status_counts['cancelled'] ?? 0);

/* ---------- การใช้ห้อง (รวมห้องที่ไม่มีการจองในช่วงนี้) ---------- */
$st = $pdo->prepare("SELECT r.id, r.name, r.color, COUNT(b.id) AS n,
        COALESCE(SUM(TIMESTAMPDIFF(MINUTE, b.start_time, b.end_time)), 0) AS mins
    FROM rooms r
    LEFT JOIN bookings b ON b.room_id = r.id AND b.status = 'approved' AND b.is_deleted = 0 AND b.start_time BETWEEN ? AND ?
    GROUP BY r.id, r.name, r.color
    ORDER BY mins DESC, r.name");
$st->execute($range);
$room_rows = $st->fetchAll(PDO::FETCH_ASSOC);
$total_mins_rooms = 0;
foreach ($room_rows as $rr) { $total_mins_rooms += (int)$rr['mins']; }

/* ---------- จำนวนต่อเดือน แยกตามห้อง ---------- */
$st = $pdo->prepare("SELECT DATE_FORMAT(start_time, '%Y-%m') AS ym, room_id, COUNT(*) AS n
    FROM bookings WHERE status = 'approved' AND is_deleted = 0 AND start_time BETWEEN ? AND ?
    GROUP BY ym, room_id");
$st->execute($range);
$by_month = [];
foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) { $by_month[$r['ym']][(int)$r['room_id']] = (int)$r['n']; }

$months = [];
$cursor = strtotime(date('Y-m-01', strtotime($start_date)));
$last = strtotime(date('Y-m-01', strtotime($end_date)));
while ($cursor <= $last && count($months) < 60) {
    $months[] = date('Y-m', $cursor);
    $cursor = strtotime('+1 month', $cursor);
}
$month_labels = [];
foreach ($months as $ym) {
    $p = explode('-', $ym);
    $month_labels[] = st_month_short($p[1]) . ' ' . substr((string)((int)$p[0] + 543), -2);
}
$datasets = [];
foreach ($room_rows as $rr) {
    if ((int)$rr['n'] === 0) { continue; }
    $series = [];
    foreach ($months as $ym) { $series[] = $by_month[$ym][(int)$rr['id']] ?? 0; }
    $datasets[] = ['label' => $rr['name'], 'data' => $series, 'backgroundColor' => st_color($rr['color']), 'borderWidth' => 0];
}

/* ---------- ช่วงเวลาที่ใช้บ่อย (วันในสัปดาห์ x ชั่วโมง) ---------- */
$hour_from = 7; $hour_to = 20;
$heat = [];
for ($d = 0; $d < 7; $d++) { for ($h = $hour_from; $h <= $hour_to; $h++) { $heat[$d][$h] = 0; } }
$st = $pdo->prepare("SELECT start_time, end_time FROM bookings WHERE status = 'approved' AND is_deleted = 0 AND start_time BETWEEN ? AND ? LIMIT 20000");
$st->execute($range);
foreach ($st->fetchAll(PDO::FETCH_NUM) as $row) {
    $s = strtotime($row[0]); $e = strtotime($row[1]);
    if ($e <= $s) { continue; }
    $dow = (int)date('w', $s);
    $h1 = (int)date('G', $s);
    $h2 = (date('Y-m-d', $e) === date('Y-m-d', $s)) ? ((int)date('G', $e) - ((int)date('i', $e) === 0 ? 1 : 0)) : 23;
    for ($h = max($h1, $hour_from); $h <= min($h2, $hour_to); $h++) { $heat[$dow][$h]++; }
}
$heat_max = 0;
foreach ($heat as $row) { foreach ($row as $v) { if ($v > $heat_max) { $heat_max = $v; } } }
$dow_names = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
$dow_order = [1, 2, 3, 4, 5, 6, 0];

/* ---------- ส่วนงานที่ใช้ห้องมากที่สุด ---------- */
$st = $pdo->prepare("SELECT COALESCE(NULLIF(TRIM(department), ''), 'ไม่ระบุส่วนงาน') AS dept, COUNT(*) AS n,
        COALESCE(SUM(TIMESTAMPDIFF(MINUTE, start_time, end_time)), 0) AS mins
    FROM bookings WHERE status = 'approved' AND is_deleted = 0 AND start_time BETWEEN ? AND ?
    GROUP BY dept ORDER BY mins DESC, n DESC LIMIT 6");
$st->execute($range);
$top_depts = $st->fetchAll(PDO::FETCH_ASSOC);
$top_max = 0;
foreach ($top_depts as $td) { if ((int)$td['mins'] > $top_max) { $top_max = (int)$td['mins']; } }

$d_n = st_delta((int)$cur['n'], (int)$prev['n']);
$d_h = st_delta((int)$cur['mins'], (int)$prev['mins']);
$d_u = st_delta((int)$cur['users'], (int)$prev['users']);

$this_year = date('Y');
$tiles = [
    ['key' => 'n', 'icon' => 'fa-calendar-check', 'num' => number_format((int)$cur['n']), 'label' => 'รายการจองที่อนุมัติ', 'delta' => $d_n],
    ['key' => 'h', 'icon' => 'fa-clock', 'num' => st_hours((int)$cur['mins']), 'label' => 'ชั่วโมงใช้ห้องรวม', 'delta' => $d_h],
    ['key' => 'u', 'icon' => 'fa-users', 'num' => number_format((int)$cur['users']), 'label' => 'ผู้ใช้ที่จองห้อง', 'delta' => $d_u],
    ['key' => 'p', 'icon' => 'fa-hourglass-half', 'num' => number_format($pending_n), 'label' => 'คำขอที่ยังรออนุมัติ',
        'delta' => ['flat', 'ปฏิเสธ ' . $rejected_n . ' รายการ ยกเลิก ' . $cancelled_n . ' รายการ']],
];
?>

<style>
.st-page { --ink:#1c2733; --muted:#667587; --line:#e3e8ee; --brand:#003399; color:var(--ink); }
.st-head { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-end; gap:12px; margin-bottom:6px; }
.st-head h1 { font-size:1.65rem; font-weight:500; margin:0; }
.st-period { color:var(--muted); margin:2px 0 16px; }
.st-filters { display:flex; flex-wrap:wrap; align-items:center; gap:10px; padding:12px 16px; background:#fff; border:1px solid var(--line); border-radius:14px; margin-bottom:18px; }
.st-range { display:inline-flex; align-items:center; gap:6px; }
.st-tiles { display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; margin-bottom:22px; }
.st-tile { position:relative; overflow:hidden; padding:18px 20px 16px; border-radius:16px; background:linear-gradient(135deg, var(--t-bg), var(--t-bg2)); border:1px solid var(--t-line); color:var(--t-ink); box-shadow:0 1px 2px rgba(18,52,86,.05); }
.st-tile--n { --t-bg:#e9f2ff; --t-bg2:#c9ddfb; --t-accent:#2f6fd6; --t-ink:#143a78; --t-line:#b9d0f3; }
.st-tile--h { --t-bg:#e6f6ec; --t-bg2:#c4e8d1; --t-accent:#1f8a52; --t-ink:#0f4f2e; --t-line:#a9d9bb; }
.st-tile--u { --t-bg:#f2ebff; --t-bg2:#dccbf8; --t-accent:#7a4bd1; --t-ink:#3f2478; --t-line:#cfbcf0; }
.st-tile--p { --t-bg:#fff6dc; --t-bg2:#ffe7a8; --t-accent:#d49a00; --t-ink:#5c3d00; --t-line:#f2d98d; }
.st-ico { position:absolute; top:16px; right:16px; width:44px; height:44px; border-radius:14px; display:flex; align-items:center; justify-content:center; background:var(--t-accent); color:#fff; font-size:1.15rem; }
.st-deco { position:absolute; right:-12px; bottom:-18px; font-size:5.4rem; color:var(--t-accent); opacity:.12; transform:rotate(-12deg); pointer-events:none; }
.st-tile .num { font-size:2.3rem; font-weight:600; line-height:1.1; padding-right:56px; font-variant-numeric:tabular-nums; }
.st-tile .label { font-weight:500; margin-top:4px; }
.st-tile .hint { font-size:.84rem; margin-top:4px; opacity:.85; position:relative; }
.st-tile .hint.up::before { content:"▲ "; color:#1f8a52; }
.st-tile .hint.down::before { content:"▼ "; color:#c0392b; }
.st-card { background:#fff; border:1px solid var(--line); border-radius:14px; box-shadow:0 1px 2px rgba(18,52,86,.04); margin-bottom:22px; }
.st-card-head { padding:14px 18px; border-bottom:1px solid var(--line); }
.st-card-head h2 { font-size:1.05rem; font-weight:500; margin:0; }
.st-card-head p { margin:2px 0 0; font-size:.84rem; color:var(--muted); }
.st-card-body { padding:16px 18px; }
.st-chart { position:relative; height:340px; }
.st-empty { padding:40px 18px; text-align:center; color:var(--muted); }
.st-rank { list-style:none; margin:0; padding:0; }
.st-rank li { padding:10px 0; border-bottom:1px solid #eef1f5; }
.st-rank li:last-child { border-bottom:0; }
.st-rank .top { display:flex; justify-content:space-between; gap:10px; align-items:baseline; }
.st-rank .nm { min-width:0; overflow-wrap:anywhere; font-weight:500; }
.st-rank .val { flex:none; font-size:.86rem; color:var(--muted); font-variant-numeric:tabular-nums; text-align:right; }
.st-dot { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:7px; }
.st-bar { height:8px; border-radius:4px; background:#eef1f5; margin-top:6px; overflow:hidden; }
.st-bar > span { display:block; height:100%; background:var(--c, var(--brand)); border-radius:4px; }
.st-heat { width:100%; border-collapse:separate; border-spacing:3px; font-size:.82rem; }
.st-heat th { font-weight:500; color:var(--muted); text-align:center; padding:2px; }
.st-heat th.day { text-align:left; padding-right:8px; white-space:nowrap; color:var(--ink); }
.st-heat td { height:34px; text-align:center; border-radius:6px; background:#f3f5f8; color:#9aa7b6; font-variant-numeric:tabular-nums; }
.st-legend { display:flex; align-items:center; gap:8px; margin-top:10px; font-size:.82rem; color:var(--muted); }
.st-legend .ramp { width:120px; height:10px; border-radius:5px; background:linear-gradient(90deg, rgba(0,51,153,.1), rgba(0,51,153,.9)); }
@media (prefers-reduced-motion: reduce) { .st-page * { transition:none !important; } }
</style>

<div class="container-fluid px-4 py-4 st-page">

    <header class="st-head">
        <h1>สถิติการจอง</h1>
    </header>
    <p class="st-period">
        ช่วงที่แสดง <?php echo st_h(st_date(strtotime($start_date))); ?> ถึง <?php echo st_h(st_date(strtotime($end_date))); ?> (<?php echo $days; ?> วัน)
        เทียบกับ <?php echo st_h(st_date(strtotime($prev_start))); ?> ถึง <?php echo st_h(st_date(strtotime($prev_end))); ?> นับเฉพาะการจองที่อนุมัติแล้ว
    </p>

    <form method="GET" id="stFilters" class="st-filters">
        <div class="st-range">
            <label class="text-muted small" for="start_date">ตั้งแต่</label>
            <input type="date" id="start_date" name="start_date" class="form-control form-control-sm" value="<?php echo st_h($start_date); ?>">
            <label class="text-muted small" for="end_date">ถึง</label>
            <input type="date" id="end_date" name="end_date" class="form-control form-control-sm" value="<?php echo st_h($end_date); ?>">
        </div>
        <div class="btn-group btn-group-sm" role="group" aria-label="ช่วงเวลาลัด">
            <button type="button" class="btn btn-outline-secondary" data-range="month">เดือนนี้</button>
            <button type="button" class="btn btn-outline-secondary" data-range="last30">30 วันล่าสุด</button>
            <button type="button" class="btn btn-outline-secondary" data-range="year">ปีนี้</button>
            <button type="button" class="btn btn-outline-secondary" data-range="all">ทั้งหมด</button>
        </div>
    </form>

    <section class="st-tiles" aria-label="สรุปภาพรวม">
        <?php foreach ($tiles as $t): ?>
            <div class="st-tile st-tile--<?php echo $t['key']; ?>">
                <span class="st-ico" aria-hidden="true"><i class="fas <?php echo $t['icon']; ?>"></i></span>
                <i class="fas <?php echo $t['icon']; ?> st-deco" aria-hidden="true"></i>
                <div class="num"><?php echo st_h($t['num']); ?></div>
                <div class="label"><?php echo st_h($t['label']); ?></div>
                <div class="hint <?php echo $t['delta'][0]; ?>"><?php echo st_h($t['delta'][1]); ?></div>
            </div>
        <?php endforeach; ?>
    </section>

    <div class="row">
        <div class="col-xl-8">
            <section class="st-card">
                <div class="st-card-head">
                    <h2>จำนวนการจองรายเดือน แยกตามห้อง</h2>
                    <p>นับเฉพาะรายการที่อนุมัติแล้ว สีตรงกับสีห้องในปฏิทิน</p>
                </div>
                <div class="st-card-body">
                    <?php if (empty($datasets)): ?>
                        <div class="st-empty">ไม่มีการจองที่อนุมัติในช่วงนี้ ลองเลือกช่วงเวลาอื่น</div>
                    <?php else: ?>
                        <div class="st-chart"><canvas id="monthlyChart"></canvas></div>
                    <?php endif; ?>
                </div>
            </section>

            <section class="st-card">
                <div class="st-card-head">
                    <h2>ช่วงเวลาที่ใช้ห้องบ่อย</h2>
                    <p>จำนวนการจองที่คาบเกี่ยวกับแต่ละชั่วโมง แยกตามวันในสัปดาห์</p>
                </div>
                <div class="st-card-body">
                    <?php if ($heat_max === 0): ?>
                        <div class="st-empty">ไม่มีข้อมูลในช่วงนี้</div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="st-heat">
                            <thead>
                                <tr>
                                    <th></th>
                                    <?php for ($h = $hour_from; $h <= $hour_to; $h++): ?><th scope="col"><?php echo sprintf('%02d', $h); ?></th><?php endfor; ?>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($dow_order as $d): ?>
                                <tr>
                                    <th class="day" scope="row"><?php echo st_h($dow_names[$d]); ?></th>
                                    <?php for ($h = $hour_from; $h <= $hour_to; $h++):
                                        $v = $heat[$d][$h];
                                        if ($v > 0) {
                                            $alpha = round(0.12 + 0.78 * ($v / $heat_max), 2);
                                            $style = 'background:rgba(0,51,153,' . $alpha . ');' . ($alpha > 0.5 ? 'color:#fff;' : 'color:#143a78;');
                                        }
                                    ?>
                                        <?php if ($v > 0): ?>
                                            <td style="<?php echo $style; ?>" title="<?php echo st_h($dow_names[$d] . ' ' . sprintf('%02d:00', $h) . ': ' . $v . ' รายการ'); ?>"><?php echo $v; ?></td>
                                        <?php else: ?>
                                            <td>·</td>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="st-legend"><span>น้อย</span><span class="ramp"></span><span>มาก (สูงสุด <?php echo $heat_max; ?> รายการ)</span></div>
                    <?php endif; ?>
                </div>
            </section>
        </div>

        <div class="col-xl-4">
            <section class="st-card">
                <div class="st-card-head">
                    <h2>การใช้งานแต่ละห้อง</h2>
                    <p>เรียงตามชั่วโมงที่ใช้ แถบแสดงสัดส่วนของชั่วโมงทั้งหมด</p>
                </div>
                <div class="st-card-body">
                    <?php if (empty($room_rows)): ?>
                        <div class="st-empty">ยังไม่มีห้องในระบบ</div>
                    <?php else: ?>
                    <ul class="st-rank">
                        <?php foreach ($room_rows as $rr):
                            $share = $total_mins_rooms > 0 ? round($rr['mins'] / $total_mins_rooms * 100) : 0;
                            $c = st_color($rr['color']);
                        ?>
                        <li>
                            <div class="top">
                                <span class="nm"><span class="st-dot" style="background:<?php echo st_h($c); ?>"></span><?php echo st_h($rr['name']); ?></span>
                                <span class="val"><?php echo (int)$rr['n']; ?> ครั้ง<br><?php echo st_h(st_hours((int)$rr['mins'])); ?> ชม. (<?php echo $share; ?>%)</span>
                            </div>
                            <div class="st-bar"><span style="width:<?php echo $share; ?>%;--c:<?php echo st_h($c); ?>"></span></div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </section>

            <section class="st-card">
                <div class="st-card-head">
                    <h2>ส่วนงานที่ใช้ห้องมากที่สุด</h2>
                    <p>6 อันดับแรก เรียงตามชั่วโมงที่ใช้</p>
                </div>
                <div class="st-card-body">
                    <?php if (empty($top_depts)): ?>
                        <div class="st-empty">ไม่มีข้อมูลในช่วงนี้</div>
                    <?php else: ?>
                    <ul class="st-rank">
                        <?php foreach ($top_depts as $td):
                            $w = $top_max > 0 ? round($td['mins'] / $top_max * 100) : 0;
                        ?>
                        <li>
                            <div class="top">
                                <span class="nm"><?php echo st_h($td['dept']); ?></span>
                                <span class="val"><?php echo (int)$td['n']; ?> ครั้ง<br><?php echo st_h(st_hours((int)$td['mins'])); ?> ชม.</span>
                            </div>
                            <div class="st-bar"><span style="width:<?php echo $w; ?>%"></span></div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('stFilters');
    var ALL_MIN = <?php echo json_encode($all_min); ?>, ALL_MAX = <?php echo json_encode($all_max); ?>;

    ['start_date', 'end_date'].forEach(function (id) {
        document.getElementById(id).addEventListener('change', function () { form.submit(); });
    });
    document.querySelectorAll('[data-range]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var pad = function (n) { return String(n).padStart(2, '0'); };
            var fmt = function (d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
            var t = new Date(), a = new Date(t), b = new Date(t);
            switch (this.dataset.range) {
                case 'month': a = new Date(t.getFullYear(), t.getMonth(), 1); b = new Date(t.getFullYear(), t.getMonth() + 1, 0); break;
                case 'last30': a.setDate(a.getDate() - 29); break;
                case 'year': a = new Date(t.getFullYear(), 0, 1); b = new Date(t.getFullYear(), 11, 31); break;
                case 'all': document.getElementById('start_date').value = ALL_MIN; document.getElementById('end_date').value = ALL_MAX; form.submit(); return;
            }
            document.getElementById('start_date').value = fmt(a);
            document.getElementById('end_date').value = fmt(b);
            form.submit();
        });
    });

    var canvas = document.getElementById('monthlyChart');
    if (canvas && window.Chart) {
        Chart.defaults.font.family = "'K2D', sans-serif";
        Chart.defaults.color = '#445468';
        new Chart(canvas, {
            type: 'bar',
            data: { labels: <?php echo json_encode($month_labels, JSON_UNESCAPED_UNICODE); ?>, datasets: <?php echo json_encode($datasets, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?> },
            options: {
                responsive: true, maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                scales: {
                    x: { stacked: true, grid: { display: false } },
                    y: { stacked: true, beginAtZero: true, ticks: { precision: 0 }, title: { display: true, text: 'จำนวนการจอง (ครั้ง)' } }
                },
                plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } }
            }
        });
    }
});
</script>
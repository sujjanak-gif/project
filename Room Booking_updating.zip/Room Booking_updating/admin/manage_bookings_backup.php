<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../includes/db.php';
include_once '../includes/functions.php';

if (!can_manage_bookings()) {
    header('Location: ../error.php?code=403');
    exit();
}

$page_title = "จัดการการจอง";
include 'layouts/admin_header.php';

// --- 1. INITIALIZE VARIABLES ---
$items_per_page = 10;
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $items_per_page;

$filter_room = $_GET['room_id'] ?? 'all';
$filter_status = $_GET['status'] ?? 'all';
$filter_start_date = $_GET['start_date'] ?? '';
$filter_end_date = $_GET['end_date'] ?? '';

// --- 2. BUILD DYNAMIC SQL QUERY ---
$where_clauses = ["b.is_deleted = 0"];
$params = [];

if (is_editor()) {
    $where_clauses[] = "u.department = ?";
    $params[] = $_SESSION['user_department'];
}

if ($filter_status !== 'all') {
    $where_clauses[] = "b.status = ?";
    $params[] = $filter_status;
} else {
    $where_clauses[] = "b.status IN ('pending', 'approved')";
}

if ($filter_room !== 'all') {
    $where_clauses[] = "b.room_id = ?";
    $params[] = $filter_room;
}
if (!empty($filter_start_date)) {
    $where_clauses[] = "DATE(b.start_time) >= ?";
    $params[] = $filter_start_date;
}
if (!empty($filter_end_date)) {
    $where_clauses[] = "DATE(b.start_time) <= ?";
    $params[] = $filter_end_date;
}

$where_sql = "WHERE " . implode(" AND ", $where_clauses);

// --- 3. FETCH TOTAL COUNT FOR PAGINATION ---
$count_sql = "
    SELECT COUNT(DISTINCT CONCAT(b.title, '_', b.room_id, '_', b.user_id, '_', DAYOFWEEK(b.start_time)))
    FROM bookings b 
    JOIN users u ON b.user_id = u.id
    {$where_sql}
";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_items = $count_stmt->fetchColumn();
$total_pages = ceil($total_items / $items_per_page);

// --- 4. FETCH BOOKINGS FOR THE CURRENT PAGE (GROUPED) ---
$bookings_sql = "
    SELECT 
        MIN(b.id) as id,
        b.title,
        b.department,
        b.instructor_name,
        b.contact_phone,
        b.student_count,
        b.room_id, 
        r.name as room_name, 
        b.user_id, 
        u.full_name as user_name, 
        MIN(b.start_time) as start_time_grouped,
        MAX(b.end_time) as end_time_grouped,
        (SELECT status FROM bookings WHERE id = MIN(b.id)) as status,
        GROUP_CONCAT(b.id) as all_booking_ids
    FROM bookings b 
    JOIN rooms r ON b.room_id = r.id 
    JOIN users u ON b.user_id = u.id 
    {$where_sql}
    GROUP BY b.title, b.room_id, b.user_id, b.department, b.instructor_name, b.contact_phone, b.student_count, DAYOFWEEK(b.start_time) 
    ORDER BY start_time_grouped DESC 
    LIMIT {$items_per_page} OFFSET {$offset}
";
$bookings_stmt = $pdo->prepare($bookings_sql);
$bookings_stmt->execute($params);
$bookings = $bookings_stmt->fetchAll();

// --- 5. FETCH DATA FOR FILTER DROPDOWNS ---
$rooms = $pdo->query("SELECT id, name FROM rooms ORDER BY name")->fetchAll();
$statuses = ['pending', 'approved', 'rejected', 'cancelled'];
?>

<div class="container-fluid px-4 py-4">
    <h1 class="mt-2 mb-4">จัดการการจอง</h1>

    <div class="card mb-4">
        <div class="card-header"><i class="fas fa-filter me-1"></i>ตัวกรองข้อมูล</div>
        <div class="card-body">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label for="room_id" class="form-label">ห้อง</label>
                    <select name="room_id" id="room_id" class="form-select">
                        <option value="all">ทุกห้อง</option>
                        <?php foreach($rooms as $room): ?>
                            <option value="<?php echo $room['id']; ?>" <?php echo ($filter_room == $room['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($room['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="status" class="form-label">สถานะ</label>
                    <select name="status" id="status" class="form-select">
                        <option value="all">ทุกสถานะ</option>
                           <?php foreach($statuses as $status): ?>
                               <option value="<?php echo $status; ?>" <?php echo ($filter_status == $status) ? 'selected' : ''; ?>><?php echo ucfirst($status); ?></option>
                           <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="start_date" class="form-label">ตั้งแต่วันที่</label>
                    <input type="date" name="start_date" id="start_date" value="<?php echo htmlspecialchars($filter_start_date); ?>" class="form-control">
                </div>
                   <div class="col-md-3">
                    <label for="end_date" class="form-label">ถึงวันที่</label>
                    <input type="date" name="end_date" id="end_date" value="<?php echo htmlspecialchars($filter_end_date); ?>" class="form-control">
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-primary w-100">กรอง</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            รายการจองทั้งหมด (หน้า <?php echo $current_page; ?> / <?php echo $total_pages; ?>)
        </div>
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <select id="bulkAction" class="form-select form-select-sm" style="width: auto;">
                    <option value="">-- เลือก Actions --</option>
                    <option value="approve">อนุมัติรายการที่เลือก</option>
                    <option value="reject">ปฏิเสธรายการที่เลือก</option>
                    <option value="delete">ลบรายการที่เลือก</option>
                </select>
                <button id="applyBulkAction" class="btn btn-primary btn-sm ms-2">Apply</button>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="bookingsTable">
                    <thead class="table-light">
                        <tr>
                            <th><input class="form-check-input" type="checkbox" id="selectAll"></th>
                            <th>ลำดับ</th>
                            <th>หัวข้อ</th>
                            <th>ห้อง</th>
                            <th>ผู้จอง</th>
                            <th>ส่วนงาน/ภาควิชา</th>
                            <th>อาจารย์ผู้สอน</th>
                            <th>จำนวน นศ.</th>
                            <th>เบอร์โทรศัพท์</th>
                            <th>วัน-เวลา</th>
                            <th>สถานะ</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($bookings)): ?>
                            <tr><td colspan="12" class="text-center">ไม่พบข้อมูลตามเงื่อนไขที่กำหนด</td></tr>
                        <?php endif; ?>
                        <?php foreach ($bookings as $index => $booking): ?>
                        <tr id="booking-row-<?php echo $booking['id']; ?>">
                            <td class="text-center"><input class="form-check-input booking-checkbox" type="checkbox" value="<?php echo htmlspecialchars($booking['all_booking_ids']); ?>"></td>
                            <td class="text-center"><?php echo $offset + $index + 1; ?></td>
                            <td><?php echo htmlspecialchars($booking['title']); ?></td>
                            <td><?php echo htmlspecialchars($booking['room_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['user_name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['department']); ?></td>
                            <td><?php echo htmlspecialchars($booking['instructor_name']); ?></td>
                            <td class="text-center"><?php echo htmlspecialchars($booking['student_count']); ?></td>
                            <td class="text-center"><?php echo htmlspecialchars($booking['contact_phone']); ?></td>
                            <td class="text-center small"><?php echo date('d/m/y H:i', strtotime($booking['start_time_grouped'])); ?> - <?php echo date('H:i', strtotime($booking['end_time_grouped'])); ?></td>
                            <td class="status-cell text-center"><?php echo format_status_badge($booking['status']); ?></td>
                            <td class="action-cell text-center">
                                   <div class="btn-group btn-group-sm">
                                       <?php if ($booking['status'] == 'pending'): ?>
                                           <button class="btn btn-sm btn-success btn-approve" data-ids="<?php echo htmlspecialchars($booking['all_booking_ids']); ?>" title="อนุมัติ"><i class="fas fa-check"></i></button>
                                           <button class="btn btn-sm btn-warning btn-reject" data-ids="<?php echo htmlspecialchars($booking['all_booking_ids']); ?>" title="ปฏิเสธ"><i class="fas fa-times"></i></button>
                                       <?php elseif ($booking['status'] == 'approved'): ?>
                                           <button class="btn btn-sm btn-info btn-unapprove" data-ids="<?php echo htmlspecialchars($booking['all_booking_ids']); ?>" title="ยกเลิกการอนุมัติ"><i class="fas fa-undo"></i></button>
                                       <?php endif; ?>
                                        <button class="btn btn-sm btn-danger btn-delete" data-ids="<?php echo htmlspecialchars($booking['all_booking_ids']); ?>" title="ลบ"><i class="fas fa-trash"></i></button>
                                   </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center">
                    <?php
                        $query_params = $_GET;

                        $query_params['page'] = $current_page - 1;
                        $prev_link = http_build_query($query_params);
                        echo '<li class="page-item ' . ($current_page <= 1 ? 'disabled' : '') . '">';
                        echo '<a class="page-link" href="?' . $prev_link . '">ย้อนกลับ</a>';
                        echo '</li>';

                        for ($i = 1; $i <= $total_pages; $i++) {
                            $query_params['page'] = $i;
                            $page_link = http_build_query($query_params);
                            echo '<li class="page-item ' . ($current_page == $i ? 'active' : '') . '">';
                            echo '<a class="page-link" href="?' . $page_link . '">' . $i . '</a>';
                            echo '</li>';
                        }

                        $query_params['page'] = $current_page + 1;
                        $next_link = http_build_query($query_params);
                        echo '<li class="page-item ' . ($current_page >= $total_pages ? 'disabled' : '') . '">';
                        echo '<a class="page-link" href="?' . $next_link . '">ถัดไป</a>';
                        echo '</li>';
                    ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
// JavaScript ทั้งหมดใช้ของเดิมได้เลย ไม่ต้องแก้ไข
$(document).ready(function(){
    $('#selectAll').on('click', function() {
        $('.booking-checkbox').prop('checked', $(this).prop('checked'));
    });

    $('#applyBulkAction').on('click', function() {
        const action = $('#bulkAction').val();
        const selectedIdsRaw = $('.booking-checkbox:checked').map(function() {
            return $(this).val();
        }).get();

        let selectedIds = [];
        selectedIdsRaw.forEach(function(idString) {
            selectedIds = selectedIds.concat(idString.split(',').map(id => parseInt(id.trim())));
        });
        
        selectedIds = [...new Set(selectedIds)];

        if (action === '' || selectedIds.length === 0) {
            Swal.fire('ข้อมูลไม่ครบถ้วน', 'กรุณาเลือกการกระทำ และเลือกอย่างน้อย 1 รายการ', 'warning');
            return;
        }

        let confirmText = `คุณต้องการจะ "${action}" รายการที่เลือกทั้งหมด ${selectedIds.length} รายการใช่หรือไม่?`;

        Swal.fire({
            title: 'ยืนยันการทำรายการ',
            text: confirmText,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'ยืนยัน',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../api/bulk_update_bookings.php',
                    type: 'POST',
                    data: { 
                        action: action,
                        booking_ids: selectedIds
                    },
                    dataType: 'json',
                    success: function(response) {
                        if(response.success) {
                            Swal.fire('สำเร็จ!', response.message, 'success').then(() => location.reload());
                        } else {
                            Swal.fire('เกิดข้อผิดพลาด!', response.message, 'error');
                        }
                    },
                    error: function() {
                           Swal.fire('เกิดข้อผิดพลาด!', 'ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้', 'error');
                    }
                });
            }
        });
    });

    $('#bookingsTable').on('click', '.btn-approve, .btn-reject, .btn-delete, .btn-unapprove', function() {
        let bookingIdsString = $(this).data('ids'); 
        let bookingIds = [];

        if (typeof bookingIdsString !== 'string' && bookingIdsString !== undefined && bookingIdsString !== null) {
            bookingIdsString = String(bookingIdsString);
        }
        
        if (typeof bookingIdsString === 'string' && bookingIdsString.length > 0) {
            bookingIds = bookingIdsString.split(',').map(id => parseInt(id.trim()));
        } else {
            Swal.fire('เกิดข้อผิดพลาด!', 'ไม่พบข้อมูลการจองที่ต้องการดำเนินการ', 'error');
            return;
        }

        bookingIds = bookingIds.filter(id => !isNaN(id) && id > 0);

        if (bookingIds.length === 0) {
            Swal.fire('ข้อมูลไม่ครบถ้วน!', 'ไม่พบ ID การจองที่ต้องการดำเนินการ', 'warning');
            return;
        }

        let action = '';
        let confirmConfig = {};

        if ($(this).hasClass('btn-approve')) {
            action = 'approve';
            confirmConfig = { title: 'ยืนยันการอนุมัติ', text: 'คุณต้องการอนุมัติรายการจองนี้ใช่หรือไม่?', icon: 'question', confirmButtonText: 'ใช่, อนุมัติ' };
        } else if ($(this).hasClass('btn-reject')) {
            action = 'reject';
            confirmConfig = { title: 'ยืนยันการปฏิเสธ', text: 'คุณต้องการปฏิเสธรายการจองนี้ใช่หรือไม่?', icon: 'warning', confirmButtonText: 'ใช่, ปฏิเสธ' };
        } else if ($(this).hasClass('btn-delete')) {
            action = 'delete';
            confirmConfig = { title: 'ยืนยันการลบ', text: 'คุณต้องการย้ายรายการนี้ไปถังขยะใช่หรือไม่?', icon: 'warning', confirmButtonText: 'ใช่, ลบ', confirmButtonColor: '#d33' };
        } else if ($(this).hasClass('btn-unapprove')) {
            action = 'unapprove';
            confirmConfig = { title: 'ยืนยันการยกเลิกอนุมัติ', text: 'คุณต้องการเปลี่ยนสถานะรายการนี้กลับเป็น "รออนุมัติ" ใช่หรือไม่?', icon: 'info', confirmButtonText: 'ใช่, ยกเลิกอนุมัติ' };
        }

        Swal.fire({
            ...confirmConfig,
            showCancelButton: true,
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../api/update_booking_status.php',
                    type: 'POST',
                    data: { booking_ids: bookingIds, action: action },
                    dataType: 'json',
                    success: function(response) {
                        if(response.success) {
                            Swal.fire('สำเร็จ!', response.message, 'success').then(() => {
                                location.reload(); 
                            });
                        } else {
                            Swal.fire('เกิดข้อผิดพลาด!', response.message, 'error');
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                           console.error("AJAX Error:", textStatus, errorThrown, jqXHR.responseText);
                           Swal.fire('เกิดข้อผิดพลาด!', 'ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้', 'error');
                    }
                });
            }
        });
    });
});
</script>
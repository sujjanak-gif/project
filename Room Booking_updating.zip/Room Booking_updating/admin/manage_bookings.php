<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';

if (!can_manage_bookings()) {
    header('Location: ../error.php?code=403');
    exit();
}

$page_title = "จัดการการจอง";
include 'layouts/admin_header.php';

/* =====================================================================
   Helpers (prefix bk_ เพื่อไม่ชนกับฟังก์ชันอื่นของระบบ)
   ===================================================================== */
function bk_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function bk_get($key, $default = '') {
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? trim($_GET[$key]) : $default;
}

// สร้าง URL จาก query ปัจจุบัน แล้วเพิ่ม/แก้ ($set) หรือเอาออก ($unset)
function bk_url(array $set = [], array $unset = []) {
    $q = $_GET;
    foreach ($unset as $k) { unset($q[$k]); }
    foreach ($set as $k => $v) {
        if ($v === null || $v === '') { unset($q[$k]); } else { $q[$k] = $v; }
    }
    return '?' . http_build_query($q);
}

function bk_month_short($m) {
    static $a = [1 => 'ม.ค.', 2 => 'ก.พ.', 3 => 'มี.ค.', 4 => 'เม.ย.', 5 => 'พ.ค.', 6 => 'มิ.ย.', 7 => 'ก.ค.', 8 => 'ส.ค.', 9 => 'ก.ย.', 10 => 'ต.ค.', 11 => 'พ.ย.', 12 => 'ธ.ค.'];
    return $a[(int)$m] ?? '';
}
function bk_month_full($m) {
    static $a = [1 => 'มกราคม', 2 => 'กุมภาพันธ์', 3 => 'มีนาคม', 4 => 'เมษายน', 5 => 'พฤษภาคม', 6 => 'มิถุนายน', 7 => 'กรกฎาคม', 8 => 'สิงหาคม', 9 => 'กันยายน', 10 => 'ตุลาคม', 11 => 'พฤศจิกายน', 12 => 'ธันวาคม'];
    return $a[(int)$m] ?? '';
}
function bk_dow_short($w) {
    static $a = ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'];
    return $a[(int)$w] ?? '';
}
function bk_dow_full($w) {
    static $a = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
    return $a[(int)$w] ?? '';
}
function bk_date_full($ts) {   // วันจันทร์ที่ 22 พฤศจิกายน 2569
    return 'วัน' . bk_dow_full(date('w', $ts)) . 'ที่ ' . date('j', $ts) . ' ' . bk_month_full(date('n', $ts)) . ' ' . (date('Y', $ts) + 543);
}
function bk_date_short($ts) {  // 22 พ.ย. 69
    return date('j', $ts) . ' ' . bk_month_short(date('n', $ts)) . ' ' . substr((string)(date('Y', $ts) + 543), -2);
}

/* =====================================================================
   1) รับค่าตัวกรอง (ตรวจสอบทุกค่า)
   ===================================================================== */
$status_labels = ['pending' => 'รออนุมัติ', 'approved' => 'อนุมัติ', 'rejected' => 'ปฏิเสธ', 'cancelled' => 'ยกเลิก'];

$filter_status = bk_get('status', 'pending');
if (!in_array($filter_status, ['pending', 'approved', 'rejected', 'cancelled', 'all'], true)) { $filter_status = 'pending'; }

$filter_room = bk_get('room_id', 'all');
if ($filter_room !== 'all' && !ctype_digit($filter_room)) { $filter_room = 'all'; }

$filter_start_date = bk_get('start_date');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_start_date)) { $filter_start_date = ''; }
$filter_end_date = bk_get('end_date');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_end_date)) { $filter_end_date = ''; }

$search = bk_get('q');
if ($search !== '') { $search = function_exists('mb_substr') ? mb_substr($search, 0, 100) : substr($search, 0, 100); }

$per_page = (int)bk_get('per_page', '25');
if (!in_array($per_page, [10, 25, 50], true)) { $per_page = 25; }

$sort_options = [
    'soon'       => 'ใกล้ถึงวันใช้งานก่อน',
    'latest_use' => 'วันใช้งานล่าสุดก่อน',
    'newest'     => 'ส่งคำขอล่าสุดก่อน',
    'oldest'     => 'ส่งคำขอเก่าสุดก่อน',
];
$sort = bk_get('sort', $filter_status === 'pending' ? 'soon' : 'newest');
if (!isset($sort_options[$sort])) { $sort = ($filter_status === 'pending') ? 'soon' : 'newest'; }

$current_page = max(1, (int)bk_get('page', '1'));

$has_filters = ($filter_room !== 'all' || $filter_start_date !== '' || $filter_end_date !== '' || $search !== '');

/* =====================================================================
   2) สร้างเงื่อนไข SQL
   ===================================================================== */
$group_by = "b.title, b.room_id, r.name, r.color, b.user_id, u.full_name, b.department, b.instructor_name, b.contact_phone, b.student_count, b.status, DATE(b.start_time)";
$joins = "FROM bookings b JOIN rooms r ON r.id = b.room_id JOIN users u ON u.id = b.user_id";

$base_where = ["b.is_deleted = 0"];
$base_params = [];
if (is_officer()) {
    $base_where[] = "u.department = ?";
    $base_params[] = $_SESSION['user_department'];
}
if ($filter_room !== 'all') { $base_where[] = "b.room_id = ?"; $base_params[] = (int)$filter_room; }
if ($filter_start_date !== '') { $base_where[] = "DATE(b.start_time) >= ?"; $base_params[] = $filter_start_date; }
if ($filter_end_date !== '') { $base_where[] = "DATE(b.start_time) <= ?"; $base_params[] = $filter_end_date; }
if ($search !== '') {
    $like = '%' . addcslashes($search, '\\%_') . '%';
    $base_where[] = "(b.title LIKE ? OR u.full_name LIKE ? OR b.instructor_name LIKE ? OR b.department LIKE ? OR b.doc_number LIKE ?)";
    for ($k = 0; $k < 5; $k++) { $base_params[] = $like; }
}
$base_sql = "WHERE " . implode(" AND ", $base_where);

$where = $base_where;
$params = $base_params;
if ($filter_status !== 'all') { $where[] = "b.status = ?"; $params[] = $filter_status; }
$where_sql = "WHERE " . implode(" AND ", $where);

/* =====================================================================
   3) จำนวนในแต่ละแท็บ (ตามตัวกรองที่เลือกอยู่)
   ===================================================================== */
$count_stmt = $pdo->prepare("SELECT t.status, COUNT(*) AS c FROM (SELECT b.status {$joins} {$base_sql} GROUP BY {$group_by}) t GROUP BY t.status");
$count_stmt->execute($base_params);
$counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0, 'cancelled' => 0];
foreach ($count_stmt->fetchAll(PDO::FETCH_ASSOC) as $cr) {
    if (isset($counts[$cr['status']])) { $counts[$cr['status']] = (int)$cr['c']; }
}
$counts['all'] = array_sum($counts);

$total_items = $counts[$filter_status];
$total_pages = max(1, (int)ceil($total_items / $per_page));
if ($current_page > $total_pages) { $current_page = $total_pages; }
$offset = ($current_page - 1) * $per_page;

/* =====================================================================
   4) ข้อมูลรายการของหน้านี้
   ===================================================================== */
$now_ts = time();
$now_sql = date('Y-m-d H:i:s', $now_ts);
$order_map = [
    'soon'       => "(MIN(b.start_time) < '{$now_sql}') ASC, MIN(b.start_time) ASC, MIN(b.id) ASC",
    'latest_use' => "MIN(b.start_time) DESC, MIN(b.id) DESC",
    'newest'     => "MIN(b.id) DESC",
    'oldest'     => "MIN(b.id) ASC",
];

$bookings_sql = "
    SELECT
        MIN(b.id) AS id,
        b.title, MAX(b.description) AS description, MAX(b.doc_number) AS doc_number,
        b.department, b.instructor_name, b.contact_phone, b.student_count, b.status,
        b.room_id, r.name AS room_name, r.color AS room_color,
        b.user_id, u.full_name AS user_name,
        MIN(b.start_time) AS start_time_grouped,
        MAX(b.end_time) AS end_time_grouped,
        MAX(b.event_group_id) AS event_group_id,
        MIN(b.created_at) AS created_at_min,
        GROUP_CONCAT(b.id ORDER BY b.id) AS all_booking_ids,
        COUNT(*) AS slot_count
    {$joins}
    {$where_sql}
    GROUP BY {$group_by}
    ORDER BY {$order_map[$sort]}
    LIMIT {$per_page} OFFSET {$offset}
";
$bookings_stmt = $pdo->prepare($bookings_sql);
$bookings_stmt->execute($params);
$bookings = $bookings_stmt->fetchAll(PDO::FETCH_ASSOC);

$rooms = $pdo->query("SELECT id, name FROM rooms ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

/* ---- ข้อมูลเตือนด้านบน: คำขอที่ใกล้ถึงวันใช้งาน / เลยวันใช้งานแล้ว ---- */
$soon_to = date('Y-m-d H:i:s', strtotime('+7 days', $now_ts));
$stat_params = [$now_sql, $soon_to, $now_sql];
$stat_officer = '';
if (is_officer()) { $stat_officer = " AND u.department = ?"; $stat_params[] = $_SESSION['user_department']; }
$stat_stmt = $pdo->prepare("SELECT COALESCE(SUM(g.s >= ? AND g.s < ?), 0) AS soon_cnt, COALESCE(SUM(g.e < ?), 0) AS stale_cnt
    FROM (SELECT MIN(b.start_time) AS s, MAX(b.end_time) AS e {$joins}
          WHERE b.is_deleted = 0 AND b.status = 'pending'{$stat_officer} GROUP BY {$group_by}) g");
$stat_stmt->execute($stat_params);
$stat = $stat_stmt->fetch(PDO::FETCH_ASSOC);
$pending_soon = (int)($stat['soon_cnt'] ?? 0);
$pending_stale = (int)($stat['stale_cnt'] ?? 0);

/* ---- การจองซ้ำ (series) ของรายการในหน้านี้ ---- */
$row_ids = [];
foreach ($bookings as $i => $b) {
    $row_ids[$i] = array_map('intval', explode(',', $b['all_booking_ids']));
}
$series = [];
$gid_set = [];
foreach ($bookings as $b) {
    if (!empty($b['event_group_id'])) { $gid_set[$b['event_group_id']] = true; }
}
if ($gid_set) {
    $gl = array_map('strval', array_keys($gid_set));
    $ph = implode(',', array_fill(0, count($gl), '?'));
    $st = $pdo->prepare("SELECT id, event_group_id, status FROM bookings WHERE is_deleted = 0 AND event_group_id IN ({$ph}) ORDER BY start_time, id");
    $st->execute($gl);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) {
        $g = (string)$s['event_group_id'];
        if (!isset($series[$g])) { $series[$g] = ['order' => [], 'pending' => []]; }
        $series[$g]['order'][] = (int)$s['id'];
        if ($s['status'] === 'pending') { $series[$g]['pending'][] = (int)$s['id']; }
    }
}

/* ---- ตรวจเวลาชนกับรายการอื่นในห้องเดียวกัน (เฉพาะรายการที่รออนุมัติ) ---- */
$check = [];
foreach ($bookings as $i => $b) {
    if ($b['status'] === 'pending') { foreach ($row_ids[$i] as $id) { $check[$id] = true; } }
}
foreach ($series as $s) { foreach ($s['pending'] as $id) { $check[$id] = true; } }
$conf = [];
foreach (array_chunk(array_keys($check), 400) as $chunk) {
    $ph = implode(',', array_fill(0, count($chunk), '?'));
    $cs = $pdo->prepare("
        SELECT b.id AS bid, b.event_group_id AS bgid,
               x.id AS xid, x.event_group_id AS xgid, x.status AS xstatus, x.title AS xtitle,
               x.start_time AS xs, x.end_time AS xe, xu.full_name AS xuser
        FROM bookings b
        JOIN bookings x ON x.room_id = b.room_id AND x.id <> b.id AND x.is_deleted = 0
             AND x.status IN ('approved', 'pending')
             AND x.start_time < b.end_time AND x.end_time > b.start_time
        LEFT JOIN users xu ON xu.id = x.user_id
        WHERE b.id IN ({$ph})");
    $cs->execute($chunk);
    foreach ($cs->fetchAll(PDO::FETCH_ASSOC) as $c) { $conf[(int)$c['bid']][] = $c; }
}

function bk_conflict_text($c, $hide_detail) {
    $ts = strtotime($c['xs']);
    $te = strtotime($c['xe']);
    $when = bk_date_short($ts) . ' ' . date('H:i', $ts) . '-' . date('H:i', $te);
    if ($hide_detail) { return $when; }
    $who = trim((string)$c['xuser']);
    return trim($c['xtitle'] . ($who !== '' ? ' (' . $who . ')' : '')) . ' ' . $when;
}

$export_url = '../api/export_bookings_csv.php?' . http_build_query([
    'status' => $filter_status, 'room_id' => $filter_room,
    'start_date' => $filter_start_date, 'end_date' => $filter_end_date,
]);
$first_no = $total_items > 0 ? $offset + 1 : 0;
$last_no = min($offset + $per_page, $total_items);
?>

<style>
.bk-page { --bk-ink:#1c2733; --bk-muted:#667587; --bk-line:#e3e8ee; --bk-navy:#123456; --bk-brand:#003399;
    --bk-pending-bg:#fff3d1; --bk-pending-fg:#7a5200; --bk-pending-bar:#e0a100;
    --bk-approved-bg:#dcf2e5; --bk-approved-fg:#14613a; --bk-approved-bar:#2e9d62;
    --bk-rejected-bg:#fde3e7; --bk-rejected-fg:#9a1b30; --bk-rejected-bar:#d6455a;
    --bk-cancelled-bg:#e8ecf1; --bk-cancelled-fg:#475466; --bk-cancelled-bar:#9aa7b6;
    --bk-danger:#c62839; --bk-info:#2c5fb3; color: var(--bk-ink); }
.bk-head { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-end; gap:12px; margin-bottom:16px; }
.bk-head h1 { font-size:1.65rem; font-weight:500; margin:0; }
.bk-head p { margin:2px 0 0; color:var(--bk-muted); }
.bk-notes { display:flex; flex-wrap:wrap; gap:10px; margin-bottom:16px; }
.bk-note { display:inline-flex; align-items:center; gap:8px; padding:8px 14px; border-radius:10px; font-size:.92rem; text-decoration:none; border:1px solid var(--bk-line); background:#fff; color:var(--bk-ink); }
.bk-note:hover { border-color:#c5cfdb; color:var(--bk-ink); }
.bk-note--warn { background:var(--bk-pending-bg); border-color:#f1d78a; color:var(--bk-pending-fg); }
.bk-panel { background:#fff; border:1px solid var(--bk-line); border-radius:14px; box-shadow:0 1px 2px rgba(18,52,86,.04); }
.bk-tabs { display:flex; gap:2px; padding:0 14px; border-bottom:1px solid var(--bk-line); overflow-x:auto; }
.bk-tab { display:inline-flex; align-items:center; gap:8px; padding:14px 12px 12px; border-bottom:3px solid transparent; color:var(--bk-muted); text-decoration:none; font-weight:500; white-space:nowrap; }
.bk-tab:hover { color:var(--bk-ink); }
.bk-tab.is-active { color:var(--bk-ink); border-bottom-color:var(--bk-brand); }
.bk-count { min-width:24px; padding:0 8px; border-radius:999px; background:#eef1f5; color:var(--bk-muted); font-size:.8rem; line-height:22px; text-align:center; }
.bk-tab.is-active .bk-count { background:var(--bk-brand); color:#fff; }
.bk-tab--pending .bk-count.has-items { background:var(--bk-pending-bg); color:var(--bk-pending-fg); }
.bk-tab--pending.is-active .bk-count.has-items { background:var(--bk-pending-bar); color:#fff; }
.bk-filters { display:flex; flex-wrap:wrap; align-items:center; gap:10px; padding:14px 18px; background:#fafbfc; border-bottom:1px solid var(--bk-line); }
.bk-filters .bk-search { flex:1 1 240px; min-width:200px; }
.bk-filters .form-select, .bk-filters .form-control { width:auto; }
.bk-filters .bk-search .form-control { width:100%; }
.bk-range { display:inline-flex; align-items:center; gap:6px; }
.bk-toolbar { display:flex; justify-content:space-between; align-items:center; padding:10px 18px; font-size:.9rem; color:var(--bk-muted); border-bottom:1px solid var(--bk-line); }
.bk-rows { list-style:none; margin:0; padding:0; }
.bk-row { display:grid; grid-template-columns:32px 72px minmax(0,1.7fr) minmax(0,1.1fr) 112px auto; grid-template-areas:"check date main person status actions"; gap:16px; align-items:center; padding:14px 18px; border-bottom:1px solid var(--bk-line); box-shadow:inset 3px 0 0 var(--row-bar, transparent); cursor:pointer; }
.bk-row:hover { background:#f7f9fc; }
.bk-row.is-selected { background:#eef3ff; }
.bk-row.is-pending { --row-bar:var(--bk-pending-bar); }
.bk-row.is-approved { --row-bar:var(--bk-approved-bar); }
.bk-row.is-rejected { --row-bar:var(--bk-rejected-bar); }
.bk-row.is-cancelled { --row-bar:var(--bk-cancelled-bar); }
.bk-row.has-conflict { --row-bar:var(--bk-danger); }
.bk-check { grid-area:check; margin:0; display:flex; }
.bk-date { grid-area:date; text-align:center; border:1px solid var(--bk-line); border-radius:10px; padding:5px 0 6px; line-height:1.15; background:#fff; }
.bk-date .dow { display:block; font-size:.75rem; color:var(--bk-muted); }
.bk-date .day { display:block; font-size:1.5rem; font-weight:600; }
.bk-date .mon { display:block; font-size:.78rem; color:var(--bk-muted); }
.bk-date.is-today { background:var(--bk-navy); border-color:var(--bk-navy); }
.bk-date.is-today span { color:#fff; }
.bk-date.is-past { opacity:.6; }
.bk-main { grid-area:main; min-width:0; }
.bk-title { display:block; max-width:100%; padding:0; border:0; background:none; text-align:left; font-weight:500; font-size:1.02rem; color:var(--bk-ink); overflow-wrap:anywhere; }
.bk-title:hover { color:var(--bk-brand); text-decoration:underline; }
.bk-title:focus-visible, .bk-row .btn:focus-visible { outline:2px solid var(--bk-brand); outline-offset:2px; }
.bk-sub { display:flex; flex-wrap:wrap; gap:4px 16px; margin-top:3px; font-size:.88rem; color:var(--bk-muted); }
.bk-dot { display:inline-block; width:9px; height:9px; border-radius:50%; margin-right:6px; background:#9aa7b6; }
.bk-flags { display:flex; flex-wrap:wrap; gap:6px; margin-top:7px; }
.bk-chip { display:inline-flex; align-items:center; gap:6px; padding:1px 8px; border-radius:6px; font-size:.78rem; border:1px solid var(--bk-line); background:#f6f8fa; color:var(--bk-muted); }
.bk-chip--danger { background:#fdeaec; border-color:#f3b9c0; color:var(--bk-danger); }
.bk-chip--info { background:#e9f0fc; border-color:#c3d4f1; color:var(--bk-info); }
.bk-person { grid-area:person; min-width:0; font-size:.9rem; }
.bk-person .name { font-weight:500; overflow-wrap:anywhere; }
.bk-person .meta { color:var(--bk-muted); font-size:.85rem; overflow-wrap:anywhere; }
.bk-status { grid-area:status; }
.bk-pill { display:inline-flex; align-items:center; gap:7px; padding:3px 11px; border-radius:999px; font-size:.82rem; font-weight:500; white-space:nowrap; }
.bk-pill::before { content:""; width:7px; height:7px; border-radius:50%; background:currentColor; }
.bk-pill--pending { background:var(--bk-pending-bg); color:var(--bk-pending-fg); }
.bk-pill--approved { background:var(--bk-approved-bg); color:var(--bk-approved-fg); }
.bk-pill--rejected { background:var(--bk-rejected-bg); color:var(--bk-rejected-fg); }
.bk-pill--cancelled { background:var(--bk-cancelled-bg); color:var(--bk-cancelled-fg); }
.bk-actions { grid-area:actions; display:flex; justify-content:flex-end; align-items:center; gap:6px; flex-wrap:wrap; }
.bk-empty { padding:56px 18px; text-align:center; color:var(--bk-muted); }
.bk-empty h2 { font-size:1.15rem; font-weight:500; color:var(--bk-ink); margin-bottom:6px; }
.bk-bulk { position:sticky; bottom:0; display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:12px 18px; background:var(--bk-navy); color:#fff; border-radius:0 0 14px 14px; }
.bk-bulk[hidden] { display:none; }
.bk-bulk .grow { flex:1; }
.bk-pager { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:10px; padding:14px 18px; }
.bk-pager .pagination { margin:0; }
.bk-dl { display:grid; grid-template-columns:130px 1fr; row-gap:10px; column-gap:12px; margin:0; }
.bk-dl dt { color:var(--bk-muted); font-weight:400; }
.bk-dl dd { margin:0; overflow-wrap:anywhere; white-space:pre-line; }
.bk-block { margin-top:18px; padding-top:16px; border-top:1px solid var(--bk-line); }
.bk-block h3 { font-size:.98rem; font-weight:500; margin-bottom:8px; }
.bk-conf-list { margin:0; padding-left:1.1rem; font-size:.9rem; }
@media (max-width: 991.98px) {
    .bk-row { grid-template-columns:28px 64px 1fr; grid-template-areas:"check date main" ". person person" ". status actions"; gap:10px 12px; }
    .bk-actions { justify-content:flex-end; }
    .bk-dl { grid-template-columns:110px 1fr; }
}
@media (prefers-reduced-motion: reduce) { .bk-page * { transition:none !important; } }
</style>

<div class="container-fluid px-4 py-4 bk-page">

    <header class="bk-head">
        <div>
            <h1>จัดการการจอง</h1>
            <p><?php echo is_officer() ? 'แสดงเฉพาะการจองของ ' . bk_h($_SESSION['user_department']) : 'ตรวจและตัดสินใจคำขอจองห้องของทุกส่วนงาน'; ?></p>
        </div>
        <a href="<?php echo bk_h($export_url); ?>" class="btn btn-outline-success btn-sm"
           title="ส่งออกตามสถานะ ห้อง และช่วงวันที่ที่เลือก (ไม่รวมคำค้นหา)">
            <i class="fas fa-file-csv me-1"></i> ส่งออก CSV
        </a>
    </header>

    <?php if ($pending_soon > 0 || $pending_stale > 0): ?>
    <div class="bk-notes">
        <?php if ($pending_soon > 0): ?>
            <a class="bk-note bk-note--warn" href="<?php echo bk_h(bk_url(['status' => 'pending', 'start_date' => date('Y-m-d', $now_ts), 'end_date' => date('Y-m-d', strtotime('+7 days', $now_ts)), 'sort' => 'soon', 'room_id' => null, 'q' => null], ['page'])); ?>">
                <i class="fas fa-hourglass-half"></i> มี <?php echo $pending_soon; ?> คำขอที่จะถึงวันใช้งานภายใน 7 วัน
            </a>
        <?php endif; ?>
        <?php if ($pending_stale > 0): ?>
            <a class="bk-note" href="<?php echo bk_h(bk_url(['status' => 'pending', 'end_date' => date('Y-m-d', strtotime('-1 day', $now_ts)), 'start_date' => null, 'sort' => 'latest_use', 'room_id' => null, 'q' => null], ['page'])); ?>">
                <i class="fas fa-clock-rotate-left"></i> มี <?php echo $pending_stale; ?> คำขอที่เลยวันใช้งานแล้วแต่ยังไม่ได้ตัดสินใจ
            </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <section class="bk-panel">
        <nav class="bk-tabs" aria-label="กรองตามสถานะ">
            <?php foreach (['pending' => 'รออนุมัติ', 'approved' => 'อนุมัติ', 'rejected' => 'ปฏิเสธ', 'cancelled' => 'ยกเลิก', 'all' => 'ทั้งหมด'] as $key => $label): ?>
                <a class="bk-tab bk-tab--<?php echo $key; ?> <?php echo $filter_status === $key ? 'is-active' : ''; ?>"
                   href="<?php echo bk_h(bk_url(['status' => $key], ['page'])); ?>"
                   <?php echo $filter_status === $key ? 'aria-current="page"' : ''; ?>>
                    <?php echo $label; ?>
                    <span class="bk-count <?php echo ($key === 'pending' && $counts[$key] > 0) ? 'has-items' : ''; ?>"><?php echo $counts[$key]; ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <form method="GET" id="bkFilters" class="bk-filters">
            <input type="hidden" name="status" value="<?php echo bk_h($filter_status); ?>">
            <div class="bk-search">
                <input type="search" name="q" class="form-control form-control-sm" value="<?php echo bk_h($search); ?>"
                       placeholder="ค้นหาหัวข้อ ผู้จอง อาจารย์ ส่วนงาน หรือเลขที่หนังสือ" aria-label="ค้นหา">
            </div>
            <select name="room_id" class="form-select form-select-sm" aria-label="ห้อง">
                <option value="all">ทุกห้อง</option>
                <?php foreach ($rooms as $room): ?>
                    <option value="<?php echo (int)$room['id']; ?>" <?php echo ($filter_room == $room['id']) ? 'selected' : ''; ?>><?php echo bk_h($room['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <div class="bk-range">
                <input type="date" name="start_date" id="start_date" class="form-control form-control-sm" value="<?php echo bk_h($filter_start_date); ?>" aria-label="ตั้งแต่วันที่">
                <span class="text-muted">ถึง</span>
                <input type="date" name="end_date" id="end_date" class="form-control form-control-sm" value="<?php echo bk_h($filter_end_date); ?>" aria-label="ถึงวันที่">
            </div>
            <div class="btn-group btn-group-sm" role="group" aria-label="ช่วงเวลาลัด">
                <button type="button" class="btn btn-outline-secondary" data-range="today">วันนี้</button>
                <button type="button" class="btn btn-outline-secondary" data-range="next7">7 วันข้างหน้า</button>
                <button type="button" class="btn btn-outline-secondary" data-range="month">เดือนนี้</button>
            </div>
            <select name="sort" class="form-select form-select-sm" aria-label="เรียงลำดับ">
                <?php foreach ($sort_options as $sk => $sl): ?>
                    <option value="<?php echo $sk; ?>" <?php echo $sort === $sk ? 'selected' : ''; ?>><?php echo $sl; ?></option>
                <?php endforeach; ?>
            </select>
            <select name="per_page" class="form-select form-select-sm" aria-label="จำนวนต่อหน้า">
                <?php foreach ([10, 25, 50] as $pp): ?>
                    <option value="<?php echo $pp; ?>" <?php echo $per_page === $pp ? 'selected' : ''; ?>><?php echo $pp; ?> รายการ/หน้า</option>
                <?php endforeach; ?>
            </select>
            <?php if ($has_filters): ?>
                <a href="<?php echo bk_h(bk_url([], ['q', 'room_id', 'start_date', 'end_date', 'page'])); ?>" class="btn btn-link btn-sm">ล้างตัวกรอง</a>
            <?php endif; ?>
        </form>

        <?php if (empty($bookings)): ?>
            <div class="bk-empty">
                <?php if ($has_filters): ?>
                    <h2>ไม่พบรายการตามตัวกรอง</h2>
                    <p>ลองเปลี่ยนคำค้น ห้อง หรือช่วงวันที่ หรือล้างตัวกรองเพื่อดูทั้งหมด</p>
                    <a class="btn btn-outline-primary btn-sm" href="<?php echo bk_h(bk_url([], ['q', 'room_id', 'start_date', 'end_date', 'page'])); ?>">ล้างตัวกรอง</a>
                <?php elseif ($filter_status === 'pending'): ?>
                    <h2>ไม่มีคำขอที่รออนุมัติ</h2>
                    <p>ตัดสินใจครบทุกคำขอแล้ว ดูรายการที่อนุมัติแล้วได้ที่แท็บ "อนุมัติ"</p>
                    <a class="btn btn-outline-primary btn-sm" href="<?php echo bk_h(bk_url(['status' => 'approved'], ['page'])); ?>">ดูรายการที่อนุมัติ</a>
                <?php else: ?>
                    <h2>ยังไม่มีรายการในสถานะนี้</h2>
                    <p>เลือกแท็บอื่นเพื่อดูรายการจอง</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="bk-toolbar">
                <label class="d-flex align-items-center gap-2 mb-0">
                    <input class="form-check-input mt-0" type="checkbox" id="selectAll"> เลือกทั้งหน้า
                </label>
                <span>แสดง <?php echo $first_no; ?>-<?php echo $last_no; ?> จาก <?php echo $total_items; ?> รายการ</span>
            </div>

            <ul class="bk-rows" id="bookingsList">
            <?php foreach ($bookings as $i => $b):
                $ids = $row_ids[$i];
                $start_ts = strtotime($b['start_time_grouped']);
                $end_ts = strtotime($b['end_time_grouped']);
                $status = $b['status'];
                $is_pending = ($status === 'pending');
                $is_past = ($end_ts < $now_ts);
                $is_today = (date('Y-m-d', $start_ts) === date('Y-m-d', $now_ts));
                $color = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string)$b['room_color']) ? $b['room_color'] : '#9aa7b6';

                // เวลาชน
                $hard = []; $soft = [];
                if ($is_pending) {
                    foreach ($ids as $bid) {
                        foreach ($conf[$bid] ?? [] as $c) {
                            if (in_array((int)$c['xid'], $ids, true)) { continue; }
                            if ($c['xstatus'] === 'approved') { $hard[$c['xid']] = $c; } else { $soft[$c['xid']] = $c; }
                        }
                    }
                }

                // การจองซ้ำ
                $gid = !empty($b['event_group_id']) ? (string)$b['event_group_id'] : '';
                $sinfo = ($gid !== '' && isset($series[$gid])) ? $series[$gid] : null;
                $series_detail = null;
                if ($sinfo && count($sinfo['order']) > 1) {
                    $nth = array_search($ids[0], $sinfo['order'], true);
                    $other_pending = array_values(array_diff($sinfo['pending'], $ids));
                    $series_hard = 0;
                    foreach ($sinfo['pending'] as $pid) {
                        foreach ($conf[$pid] ?? [] as $c) {
                            if ($c['xstatus'] === 'approved' && (string)$c['xgid'] !== (string)$c['bgid']) { $series_hard++; break; }
                        }
                    }
                    $series_detail = [
                        'nth' => ($nth === false ? 1 : $nth + 1),
                        'total' => count($sinfo['order']),
                        'pending_ids' => $sinfo['pending'],
                        'other_pending' => count($other_pending),
                        'conflicts' => $series_hard,
                    ];
                }

                $waiting = $is_pending ? max(0, (int)floor(($now_ts - strtotime($b['created_at_min'])) / 86400)) : 0;

                $conf_list = [];
                foreach (array_slice($hard, 0, 5) as $c) { $conf_list[] = ['kind' => 'approved', 'text' => bk_conflict_text($c, is_officer())]; }
                foreach (array_slice($soft, 0, 5) as $c) { $conf_list[] = ['kind' => 'pending', 'text' => bk_conflict_text($c, is_officer())]; }

                $detail = [
                    'title' => $b['title'],
                    'status' => $status,
                    'status_label' => $status_labels[$status] ?? $status,
                    'room' => $b['room_name'],
                    'date_text' => bk_date_full($start_ts),
                    'time_text' => date('H:i', $start_ts) . ' - ' . date('H:i', $end_ts),
                    'slots' => (int)$b['slot_count'],
                    'user' => $b['user_name'],
                    'department' => $b['department'],
                    'instructor' => $b['instructor_name'],
                    'students' => ($b['student_count'] === null || $b['student_count'] === '') ? '' : (string)$b['student_count'],
                    'phone' => $b['contact_phone'],
                    'doc' => $b['doc_number'],
                    'description' => $b['description'],
                    'waiting_text' => ($is_pending && $waiting >= 1) ? 'รอมาแล้ว ' . $waiting . ' วัน' : '',
                    'ids' => $ids,
                    'conflicts' => $conf_list,
                    'series' => $series_detail,
                ];
                $detail_attr = bk_h(json_encode($detail, JSON_UNESCAPED_UNICODE));
            ?>
                <li class="bk-row is-<?php echo bk_h($status); ?> <?php echo $hard ? 'has-conflict' : ''; ?>"
                    id="booking-row-<?php echo (int)$b['id']; ?>"
                    data-ids="<?php echo bk_h(implode(',', $ids)); ?>"
                    data-status="<?php echo bk_h($status); ?>"
                    data-conflicts="<?php echo count($hard); ?>"
                    data-detail="<?php echo $detail_attr; ?>">

                    <label class="bk-check">
                        <input class="form-check-input booking-checkbox" type="checkbox" aria-label="เลือก <?php echo bk_h($b['title']); ?>">
                    </label>

                    <div class="bk-date <?php echo $is_today ? 'is-today' : ''; ?> <?php echo ($is_past && !$is_today) ? 'is-past' : ''; ?>" title="<?php echo bk_h(bk_date_full($start_ts)); ?>">
                        <span class="dow"><?php echo bk_dow_short(date('w', $start_ts)); ?></span>
                        <span class="day"><?php echo date('j', $start_ts); ?></span>
                        <span class="mon"><?php echo bk_month_short(date('n', $start_ts)); ?><?php echo date('Y', $start_ts) !== date('Y', $now_ts) ? ' ' . substr((string)(date('Y', $start_ts) + 543), -2) : ''; ?></span>
                    </div>

                    <div class="bk-main">
                        <button type="button" class="bk-title"><?php echo bk_h($b['title']); ?></button>
                        <div class="bk-sub">
                            <span><i class="fa-regular fa-clock me-1"></i><?php echo date('H:i', $start_ts); ?> - <?php echo date('H:i', $end_ts); ?></span>
                            <span><span class="bk-dot" style="background:<?php echo bk_h($color); ?>"></span><?php echo bk_h($b['room_name']); ?></span>
                        </div>
                        <?php if ($hard || $soft || $series_detail || ($is_pending && $is_past) || $waiting >= 3): ?>
                        <div class="bk-flags">
                            <?php if ($hard): ?><span class="bk-chip bk-chip--danger"><i class="fas fa-triangle-exclamation"></i> เวลาชนกับรายการที่อนุมัติแล้ว <?php echo count($hard); ?></span><?php endif; ?>
                            <?php if ($soft): ?><span class="bk-chip bk-chip--info"><i class="fas fa-layer-group"></i> มีคำขออื่นขอเวลาซ้อนกัน <?php echo count($soft); ?></span><?php endif; ?>
                            <?php if ($series_detail): ?><span class="bk-chip"><i class="fas fa-repeat"></i> จองซ้ำ ครั้งที่ <?php echo $series_detail['nth']; ?>/<?php echo $series_detail['total']; ?></span><?php endif; ?>
                            <?php if ($is_pending && $is_past): ?><span class="bk-chip">เลยวันใช้งานแล้ว</span><?php endif; ?>
                            <?php if ($waiting >= 3): ?><span class="bk-chip">รอมา <?php echo $waiting; ?> วัน</span><?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="bk-person">
                        <div class="name"><?php echo bk_h($b['user_name']); ?></div>
                        <?php if (!empty($b['department'])): ?><div class="meta"><?php echo bk_h($b['department']); ?></div><?php endif; ?>
                        <?php if (!empty($b['instructor_name']) || !empty($b['student_count'])): ?>
                        <div class="meta">
                            <?php if (!empty($b['instructor_name'])): ?><span class="me-2"><i class="fas fa-user-tie me-1"></i><?php echo bk_h($b['instructor_name']); ?></span><?php endif; ?>
                            <?php if (!empty($b['student_count'])): ?><span><i class="fas fa-users me-1"></i><?php echo (int)$b['student_count']; ?></span><?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="bk-status"><span class="bk-pill bk-pill--<?php echo bk_h($status); ?>"><?php echo bk_h($status_labels[$status] ?? $status); ?></span></div>

                    <div class="bk-actions">
                        <?php if ($is_pending): ?>
                            <button type="button" class="btn btn-success btn-sm bk-act" data-action="approve"><i class="fas fa-check me-1"></i>อนุมัติ</button>
                            <button type="button" class="btn btn-outline-danger btn-sm bk-act" data-action="reject">ปฏิเสธ</button>
                        <?php else: ?>
                            <button type="button" class="btn btn-outline-secondary btn-sm bk-act" data-action="unapprove"><?php echo $status === 'approved' ? 'ยกเลิกการอนุมัติ' : 'คืนเป็นรออนุมัติ'; ?></button>
                        <?php endif; ?>
                        <div class="dropdown">
                            <button type="button" class="btn btn-light btn-sm" data-bs-toggle="dropdown" aria-expanded="false" aria-label="เมนูเพิ่มเติม"><i class="fas fa-ellipsis-vertical"></i></button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><button type="button" class="dropdown-item bk-open"><i class="fas fa-circle-info fa-fw me-2"></i>ดูรายละเอียด</button></li>
                                <li><button type="button" class="dropdown-item text-danger bk-act" data-action="delete"><i class="fas fa-trash fa-fw me-2"></i>ลบ</button></li>
                            </ul>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
            </ul>

            <div class="bk-bulk" id="bkBulk" hidden>
                <span><strong id="bkSelCount">0</strong> รายการที่เลือก</span>
                <span class="grow"></span>
                <button type="button" class="btn btn-success btn-sm" data-bulk="approve">อนุมัติ</button>
                <button type="button" class="btn btn-outline-light btn-sm" data-bulk="reject">ปฏิเสธ</button>
                <button type="button" class="btn btn-outline-light btn-sm" data-bulk="unapprove">ย้อนสถานะ</button>
                <button type="button" class="btn btn-danger btn-sm" data-bulk="delete">ลบ</button>
                <button type="button" class="btn btn-link btn-sm text-white" id="bkClear">ล้างที่เลือก</button>
            </div>

            <?php if ($total_pages > 1): ?>
            <div class="bk-pager">
                <span class="text-muted small">หน้า <?php echo $current_page; ?> จาก <?php echo $total_pages; ?></span>
                <nav aria-label="เปลี่ยนหน้า">
                    <ul class="pagination pagination-sm">
                        <li class="page-item <?php echo $current_page <= 1 ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo bk_h(bk_url(['page' => $current_page - 1])); ?>">ก่อนหน้า</a></li>
                        <?php
                        $shown = [];
                        for ($p = 1; $p <= $total_pages; $p++) {
                            if ($p === 1 || $p === $total_pages || abs($p - $current_page) <= 2) { $shown[] = $p; }
                        }
                        $prev_p = 0;
                        foreach ($shown as $p) {
                            if ($p - $prev_p > 1) { echo '<li class="page-item disabled"><span class="page-link">…</span></li>'; }
                            echo '<li class="page-item ' . ($p === $current_page ? 'active' : '') . '"><a class="page-link" href="' . bk_h(bk_url(['page' => $p])) . '">' . $p . '</a></li>';
                            $prev_p = $p;
                        }
                        ?>
                        <li class="page-item <?php echo $current_page >= $total_pages ? 'disabled' : ''; ?>"><a class="page-link" href="<?php echo bk_h(bk_url(['page' => $current_page + 1])); ?>">ถัดไป</a></li>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>

<!-- รายละเอียดการจอง -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="bkDrawer" aria-labelledby="bkDrawerTitle" style="width:min(480px,100vw)">
    <div class="offcanvas-header align-items-start">
        <div>
            <h2 class="h5 mb-2" id="bkDrawerTitle" style="overflow-wrap:anywhere"></h2>
            <span id="bkDrawerPill" class="bk-pill"></span>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="ปิด"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column">
        <dl class="bk-dl" id="bkDrawerInfo"></dl>
        <div class="bk-block" id="bkDrawerConflicts" hidden>
            <h3 class="text-danger"><i class="fas fa-triangle-exclamation me-1"></i>เวลาซ้อนกับรายการอื่นในห้องเดียวกัน</h3>
            <ul class="bk-conf-list" id="bkDrawerConfList"></ul>
        </div>
        <div class="bk-block" id="bkDrawerSeries" hidden>
            <h3><i class="fas fa-repeat me-1"></i>การจองซ้ำ</h3>
            <p class="small text-muted mb-2" id="bkDrawerSeriesText"></p>
            <div class="d-flex flex-wrap gap-2" id="bkDrawerSeriesBtns"></div>
        </div>
        <div class="mt-auto pt-4 d-flex flex-wrap gap-2" id="bkDrawerActions"></div>
    </div>
</div>

<?php include 'layouts/admin_footer.php'; ?>
<script>
$(function () {
    const IS_OFFICER = <?php echo is_officer() ? 'true' : 'false'; ?>;
    const CSRF = <?php echo json_encode(function_exists('csrf_token') ? csrf_token() : ''); ?>;
    const API = '../api/update_booking_status.php';
    const drawer = bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('bkDrawer'));

    const ACTIONS = {
        approve:   { title: 'อนุมัติการจอง',            verb: 'อนุมัติ',        done: 'อนุมัติแล้ว',        icon: 'question', color: '#198754', mail: true },
        reject:    { title: 'ปฏิเสธการจอง',            verb: 'ปฏิเสธ',         done: 'ปฏิเสธแล้ว',         icon: 'warning',  color: '#dc3545', mail: true },
        unapprove: { title: 'ย้อนสถานะเป็นรออนุมัติ',   verb: 'ย้อนสถานะ',      done: 'ย้อนสถานะแล้ว',      icon: 'info',     color: '#0d6efd' },
        'delete':  { title: 'ลบการจอง',                verb: 'ลบ',             done: 'ลบแล้ว',             icon: 'warning',  color: '#dc3545' }
    };

    const parseIds = s => String(s).split(',').map(n => parseInt(n, 10)).filter(n => n > 0);
    const uniq = a => Array.from(new Set(a));

    /* ---------- ทำรายการ (ยืนยัน -> เรียก API -> โหลดหน้าใหม่) ---------- */
    function runAction(action, ids, ctx) {
        ctx = ctx || {};
        const cfg = ACTIONS[action];
        ids = uniq(ids);
        if (!cfg || ids.length === 0) { return; }
        const conflicts = (action === 'approve') ? (ctx.conflicts || 0) : 0;

        const lines = [(ctx.scopeLabel || '') + cfg.verb + ' ' + ids.length + ' รายการ'];
        if (cfg.mail) { lines.push('ระบบจะส่งอีเมลแจ้งผลให้ผู้จอง'); }
        if (action === 'delete') { lines.push(IS_OFFICER ? 'ผู้ดูแลระบบสามารถกู้คืนรายการได้' : 'กู้คืนได้ที่เมนู ประวัติการจอง'); }
        let html = lines.map(l => '<div>' + l + '</div>').join('');
        if (conflicts > 0) {
            html += '<div class="mt-2 text-danger fw-semibold">มี ' + conflicts + ' รายการที่เวลาชนกับรายการที่อนุมัติแล้ว</div>';
        }

        Swal.fire({
            title: cfg.title,
            html: html,
            icon: conflicts > 0 ? 'warning' : cfg.icon,
            showCancelButton: true,
            focusCancel: conflicts > 0,
            confirmButtonText: conflicts > 0 ? cfg.verb + ' ทั้งที่เวลาชน' : cfg.verb,
            confirmButtonColor: conflicts > 0 ? '#dc3545' : cfg.color,
            cancelButtonText: 'ไม่ทำรายการ'
        }).then(function (r) {
            if (!r.isConfirmed) { return; }
            Swal.fire({ title: 'กำลังดำเนินการ…', allowOutsideClick: false, allowEscapeKey: false, didOpen: () => Swal.showLoading() });
            $.ajax({
                url: API, type: 'POST', dataType: 'json', timeout: 180000,
                data: { booking_ids: ids, action: action, csrf_token: CSRF, force: (action === 'approve' && conflicts > 0) ? 1 : 0 },
                success: function (res) {
                    if (res.success) {
                        Swal.fire({ icon: 'success', title: cfg.done, text: res.message, timer: 1300, showConfirmButton: false })
                            .then(() => location.reload());
                    } else {
                        Swal.fire('ทำรายการไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error');
                    }
                },
                error: function () { Swal.fire('ทำรายการไม่สำเร็จ', 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ตรวจสอบรายการแล้วลองใหม่อีกครั้ง', 'error'); }
            });
        });
    }

    /* ---------- ปุ่มในแต่ละแถว ---------- */
    $('#bookingsList').on('click', '.bk-act', function () {
        const $row = $(this).closest('.bk-row');
        runAction($(this).data('action'), parseIds($row.data('ids')), { conflicts: parseInt($row.data('conflicts'), 10) || 0 });
    });

    /* ---------- เลือกหลายรายการ ---------- */
    function updateBulk() {
        const $all = $('.booking-checkbox');
        const $checked = $all.filter(':checked');
        const n = $checked.length;
        $('.bk-row').removeClass('is-selected');
        $checked.closest('.bk-row').addClass('is-selected');
        $('#bkSelCount').text(n);
        $('#bkBulk').prop('hidden', n === 0);
        const st = new Set($checked.closest('.bk-row').map(function () { return $(this).data('status'); }).get());
        $('[data-bulk=approve],[data-bulk=reject]').toggle(n > 0 && st.size === 1 && st.has('pending'));
        $('[data-bulk=unapprove]').toggle(n > 0 && !st.has('pending'));
        $('#selectAll').prop('checked', n > 0 && n === $all.length).prop('indeterminate', n > 0 && n < $all.length);
    }
    $('#selectAll').on('change', function () { $('.booking-checkbox').prop('checked', this.checked); updateBulk(); });
    $('#bookingsList').on('change', '.booking-checkbox', updateBulk);
    $('#bkClear').on('click', function () { $('.booking-checkbox, #selectAll').prop('checked', false); updateBulk(); });
    $('#bkBulk').on('click', '[data-bulk]', function () {
        const $rows = $('.booking-checkbox:checked').closest('.bk-row');
        let ids = [], conflicts = 0;
        $rows.each(function () { ids = ids.concat(parseIds($(this).data('ids'))); conflicts += parseInt($(this).data('conflicts'), 10) || 0; });
        runAction($(this).data('bulk'), ids, { conflicts: conflicts });
    });

    /* ---------- หน้าต่างรายละเอียด ---------- */
    function fillDrawer(d) {
        $('#bkDrawerTitle').text(d.title);
        $('#bkDrawerPill').attr('class', 'bk-pill bk-pill--' + d.status).text(d.status_label);

        const info = [
            ['ห้อง', d.room], ['วันที่', d.date_text],
            ['เวลา', d.time_text + (d.slots > 1 ? ' (รวม ' + d.slots + ' ช่วงเวลาในวันเดียวกัน)' : '')],
            ['ผู้จอง', d.user], ['ส่วนงาน', d.department], ['อาจารย์ผู้สอน', d.instructor],
            ['จำนวนนักศึกษา', d.students], ['โทรศัพท์', d.phone, 'tel'], ['เลขที่หนังสือ', d.doc],
            ['หมายเหตุ', d.description], ['สถานะคำขอ', d.waiting_text]
        ];
        const $dl = $('#bkDrawerInfo').empty();
        info.forEach(function (it) {
            const v = it[1];
            if (v === null || v === undefined || String(v).trim() === '' || String(v).trim() === '-') { return; }
            const $dd = $('<dd>');
            if (it[2] === 'tel') {
                $dd.append($('<a>').attr('href', 'tel:' + String(v).replace(/[^0-9+]/g, '')).text(v));
            } else { $dd.text(v); }
            $dl.append($('<dt>').text(it[0]), $dd);
        });

        const $cl = $('#bkDrawerConfList').empty();
        (d.conflicts || []).forEach(function (c) {
            $cl.append($('<li>').text((c.kind === 'approved' ? 'อนุมัติแล้ว: ' : 'รออนุมัติ: ') + c.text));
        });
        $('#bkDrawerConflicts').prop('hidden', !(d.conflicts && d.conflicts.length));

        const $sb = $('#bkDrawerSeriesBtns').empty();
        const s = d.series;
        if (s) {
            $('#bkDrawerSeriesText').text('รายการนี้เป็นครั้งที่ ' + s.nth + ' จากทั้งหมด ' + s.total + ' ครั้ง' +
                (s.pending_ids.length ? ' ยังรออนุมัติ ' + s.pending_ids.length + ' ครั้ง' : ''));
            if (s.other_pending > 0) {
                $sb.append(
                    $('<button type="button" class="btn btn-outline-success btn-sm">').text('อนุมัติทั้งชุด (' + s.pending_ids.length + ')')
                        .on('click', function () { runAction('approve', s.pending_ids, { conflicts: s.conflicts, scopeLabel: 'ทั้งชุด ' }); }),
                    $('<button type="button" class="btn btn-outline-danger btn-sm">').text('ปฏิเสธทั้งชุด (' + s.pending_ids.length + ')')
                        .on('click', function () { runAction('reject', s.pending_ids, { scopeLabel: 'ทั้งชุด ' }); })
                );
            }
        }
        $('#bkDrawerSeries').prop('hidden', !s);

        const $a = $('#bkDrawerActions').empty();
        const hardCount = (d.conflicts || []).filter(c => c.kind === 'approved').length;
        if (d.status === 'pending') {
            $a.append(
                $('<button type="button" class="btn btn-success">').text('อนุมัติ').on('click', function () { runAction('approve', d.ids, { conflicts: hardCount }); }),
                $('<button type="button" class="btn btn-outline-danger">').text('ปฏิเสธ').on('click', function () { runAction('reject', d.ids); })
            );
        } else {
            $a.append($('<button type="button" class="btn btn-outline-secondary">')
                .text(d.status === 'approved' ? 'ยกเลิกการอนุมัติ' : 'คืนเป็นรออนุมัติ')
                .on('click', function () { runAction('unapprove', d.ids); }));
        }
        $a.append($('<button type="button" class="btn btn-link text-danger ms-auto">').text('ลบ').on('click', function () { runAction('delete', d.ids); }));
    }
    function openDrawer($row) {
        try { fillDrawer(JSON.parse($row.attr('data-detail'))); drawer.show(); }
        catch (e) { Swal.fire('เปิดรายละเอียดไม่ได้', 'ข้อมูลของรายการนี้อ่านไม่ได้ ลองโหลดหน้าใหม่อีกครั้ง', 'error'); }
    }
    $('#bookingsList').on('click', '.bk-row', function (e) {
        if ($(e.target).closest('.bk-check, .bk-actions, a').length) { return; }
        openDrawer($(this));
    });
    $('#bookingsList').on('click', '.bk-open', function () { openDrawer($(this).closest('.bk-row')); });

    /* ---------- ตัวกรอง ---------- */
    const form = document.getElementById('bkFilters');
    $('#bkFilters select, #bkFilters input[type=date]').on('change', function () { form.submit(); });
    $('#bkFilters input[type=search]').on('search', function () { form.submit(); });
    $('[data-range]').on('click', function () {
        const pad = n => String(n).padStart(2, '0');
        const fmt = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
        const t = new Date(); let a = new Date(t), b = new Date(t);
        if (this.dataset.range === 'next7') { b.setDate(b.getDate() + 7); }
        if (this.dataset.range === 'month') { a = new Date(t.getFullYear(), t.getMonth(), 1); b = new Date(t.getFullYear(), t.getMonth() + 1, 0); }
        $('#start_date').val(fmt(a)); $('#end_date').val(fmt(b));
        form.submit();
    });
});
</script>
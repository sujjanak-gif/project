<?php
// Start session at the very beginning of the script
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once 'includes/db.php';
include_once 'includes/functions.php';

// ห้องสำหรับตัวเลือกกรอง (สีใช้ตามที่ตั้งไว้ในระบบ ถ้าไม่มีให้ใช้สีสำรอง)
$palette = ['#2f6fd6', '#d9534f', '#7a4bd1', '#0f9d8a', '#e07b00', '#c2185b'];
$rooms = $pdo->query("SELECT id, name, color FROM rooms ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$rooms_js = [];
foreach ($rooms as $i => $r) {
    $color = preg_match('/^#[0-9a-fA-F]{6}$/', (string)$r['color']) ? $r['color'] : $palette[$i % count($palette)];
    $lum = (0.299 * hexdec(substr($color, 1, 2)) + 0.587 * hexdec(substr($color, 3, 2)) + 0.114 * hexdec(substr($color, 5, 2))) / 255;
    $rooms_js[] = ['id' => (int)$r['id'], 'name' => $r['name'], 'color' => $color, 'ink' => ($lum > 0.62 ? '#1c2733' : '#ffffff')];
}

$page_title = "ปฏิทินการจองห้อง";
include 'includes/header.php';
?>

<style>
.cal-page { --ink:#1c2733; --muted:#667587; --line:#e3e8ee; --navy:#123456; --brand:#003399;
    --ok-bg:#e3f4ea; --ok-fg:#14613a; --wait-bg:#fff3d1; --wait-fg:#7a5200; color:var(--ink); }
.cal-card { background:#fff; border:1px solid var(--line); border-radius:16px; padding:22px; box-shadow:0 1px 3px rgba(18,52,86,.06); }
.cal-top { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-start; gap:12px; margin-bottom:16px; }
.cal-h1 { font-size:1.6rem; font-weight:500; margin:0; }
.cal-sub { margin:2px 0 0; color:var(--muted); }
.cal-rooms { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:18px; }
.room-chip { display:inline-flex; align-items:center; gap:8px; max-width:100%; padding:6px 14px; border:1px solid #d6dde6; border-radius:999px; background:#fff; color:var(--ink); font-size:.88rem; cursor:pointer; }
.room-chip:hover { border-color:#aab6c4; }
.room-chip .dot { flex:none; width:10px; height:10px; border-radius:50%; background:var(--room, #9aa7b6); }
.room-chip .txt { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:320px; }
.room-chip.is-active { background:var(--navy); border-color:var(--navy); color:#fff; }
.room-chip:focus-visible, .cal-btn:focus-visible, .cal-item:focus-visible, .cal-today-item:focus-visible { outline:2px solid var(--brand); outline-offset:2px; }
.cal-bar { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:12px; margin-bottom:14px; }
.cal-title { font-size:1.7rem; font-weight:500; margin:0; }
.cal-ctrl { display:flex; flex-wrap:wrap; align-items:center; gap:8px; }
.cal-btn { display:inline-flex; align-items:center; justify-content:center; min-width:38px; height:38px; padding:0 12px; border:1px solid #d6dde6; border-radius:10px; background:#fff; color:var(--ink); font-size:.92rem; cursor:pointer; }
.cal-btn:hover { background:#f3f6fa; }
.cal-ctrl .form-select { width:auto; height:38px; border-radius:10px; }

/* ----- แถบ nav (ชิปห้อง + เดือน/ปี + ปุ่มควบคุม) ไม่มีสีพื้นหลังของแถบ ----- */
.cal-nav { padding:0 0 16px; color:var(--ink); }
.cal-nav .cal-rooms { margin-bottom:18px; }
.cal-nav .cal-bar { margin-bottom:0; }
.cal-nav .cal-title { color:var(--ink); font-size:2rem; font-weight:700; letter-spacing:.2px; }

/* ปุ่มข้อความชื่อห้อง: พื้นหลังเป็นสีอ่อนของห้องนั้น เมื่อเลือกจะเป็นสีห้องเต็ม */
.cal-nav .room-chip { background:#f3f6fb; border:1px solid #cfd9e8; font-weight:500; }
.cal-nav .room-chip:hover { filter:brightness(.96); }
.cal-nav .room-chip .dot { box-shadow:0 0 0 2px #fff, 0 0 0 3px rgba(0,0,0,.12); }
@supports (background: color-mix(in srgb, red 10%, white)) {
    .cal-nav .room-chip[data-room]:not([data-room="all"]) { background:color-mix(in srgb, var(--room) 16%, #fff); border-color:color-mix(in srgb, var(--room) 60%, #fff); }
}
.cal-nav .room-chip[data-room="all"] { background:#e3ecfb; border-color:#b9cdee; color:var(--brand); font-weight:600; }
.cal-nav .room-chip[data-room].is-active { background:var(--room, var(--brand)); border-color:var(--room, var(--brand)); color:var(--room-ink, #fff); font-weight:700; box-shadow:none; }
.cal-nav .room-chip[data-room].is-active .dot { background:var(--room-ink, #fff); box-shadow:none; }

/* ปุ่ม nav: เดือนก่อนหน้า / เดือนถัดไป / วันนี้ */
.cal-nav .cal-btn { background:#e3ecfb; border:1px solid #b9cdee; color:var(--brand); font-weight:600; }
.cal-nav .cal-btn:hover { background:var(--brand); border-color:var(--brand); color:#fff; }
.cal-nav #calToday { background:#ffc83d; border-color:#ffc83d; color:#3d2a00; font-weight:700; }
.cal-nav #calToday:hover { background:#ffd76b; border-color:#ffd76b; color:#3d2a00; }
.cal-nav .cal-ctrl .form-select { color:var(--ink); font-weight:600; }

/* ----- FullCalendar ----- */
.cal-page #calendar { --fc-border-color:#e3e8ee; --fc-today-bg-color:#eef4ff; --fc-event-bg-color:transparent; --fc-event-border-color:transparent; --fc-event-text-color:inherit; font-family:inherit; position:relative; }
.cal-page #calendar.is-loading { opacity:.6; }
.cal-page .fc .fc-scrollgrid { border-radius:12px; overflow:hidden; }
.cal-page .fc .fc-col-header-cell { background: #4d71a3; border-color:#c3d4ee; }
.cal-page .fc .fc-col-header-cell-cushion { padding:12px 4px; font-weight:600; font-size:1rem; color: #ffffff; text-decoration:none; }
.cal-page .fc .fc-col-header-cell.fc-day-sun .fc-col-header-cell-cushion { color:#c0182f; }
.cal-page .fc .fc-col-header-cell.fc-day-sat .fc-col-header-cell-cushion { color:#5b3bb0; }
.cal-page .fc .fc-daygrid-day-frame { min-height:116px; }
.cal-page .fc .fc-daygrid-day-top { flex-direction:row; padding:6px 8px 2px; }
.cal-page .fc .fc-daygrid-day.fc-day-sat, .cal-page .fc .fc-daygrid-day.fc-day-sun { background:#fafbfd; }
.cal-page .fc .fc-daygrid-day.fc-day-other { background:#f3f5f8; }
.cal-page .fc .fc-daygrid-day:not(.fc-day-other):hover { background:#f2f6ff; cursor:pointer; }
.cal-page .fc .fc-daygrid-day.fc-day-today { background:#eef4ff; }
.cal-num { display:inline-flex; align-items:center; justify-content:center; min-width:30px; height:30px; border-radius:50%; font-weight:500; color:var(--ink); }
.fc-day-sun .cal-num { color:#c62839; }
.fc-day-sat .cal-num { color:#6b4bb8; }
.fc-day-today .cal-num { background:var(--navy); color:#fff !important; }
.cal-page .fc .fc-daygrid-event { margin:2px 5px 0; }
.cal-page .fc .fc-daygrid-more-link { margin:3px 8px 0; font-size:.78rem; font-weight:500; color:var(--brand); }
.cal-ev { display:flex; align-items:center; gap:6px; width:100%; padding:2px 6px 2px 8px; border-radius:0; font-size:.78rem; line-height:1.4; border-left:4px solid var(--room, #9aa7b6); overflow:hidden; white-space:nowrap; cursor:pointer; }
.cal-ev.is-approved { background:var(--ok-bg); color:var(--ok-fg); }
.cal-ev.is-pending { background:var(--wait-bg); color:var(--wait-fg); }
.cal-ev-time { flex:none; font-weight:600; font-variant-numeric:tabular-nums; }
.cal-ev-title { overflow:hidden; text-overflow:ellipsis; }
.cal-ev-ico { flex:none; font-size:.68rem; }
.cal-page .fc-event.past-event .cal-ev { opacity:.55; }

/* ----- โครงหน้า: ปฏิทินกว้าง แถบข้างแคบ ----- */
.cal-layout { display:grid; grid-template-columns:minmax(0, 1fr); gap:20px; }
.cal-main { min-width:0; }
@media (min-width: 1200px) { .cal-layout { grid-template-columns:minmax(0, 1fr) 250px; } }

/* ----- แถบด้านข้าง (กระชับ) ----- */
.cal-side { background:#fff; border:1px solid var(--line); border-radius:14px; padding:12px 14px; margin-bottom:12px; box-shadow:0 1px 3px rgba(18,52,86,.06); font-size:.88rem; }
.cal-side h2 { font-size:.95rem; font-weight:500; margin:0 0 8px; }
.cal-today-date { color:var(--muted); font-size:.8rem; margin:-4px 0 8px; }
.cal-today-item { display:flex; gap:8px; width:100%; text-align:left; padding:6px 8px; margin-bottom:6px; border:1px solid var(--line); border-left:4px solid var(--room, #9aa7b6); border-radius:0; background:#fff; }
.cal-today-item:hover { background:#f6f9ff; }
.cal-today-item .t { flex:none; font-weight:600; font-size:.8rem; font-variant-numeric:tabular-nums; }
.cal-today-item .n { min-width:0; font-size:.82rem; overflow-wrap:anywhere; }
.cal-today-item .r { display:block; color:var(--muted); font-size:.74rem; }
.cal-muted { color:var(--muted); font-size:.84rem; }
.cal-legend { display:flex; align-items:center; gap:8px; margin-bottom:6px; font-size:.84rem; }
.cal-legend .sw { width:26px; height:16px; border-radius:0; flex:none; }
.cal-legend .sw.ok { background:var(--ok-bg); border-left:4px solid #2e9d62; }
.cal-legend .sw.wait { background:var(--wait-bg); border-left:4px solid #e0a100; }
.cal-notice { background:#fff7e0; border:1px solid #f1d78a; color:#6b4a00; }
.cal-notice h2 { color:#6b4a00; }
.cal-contact { display:flex; align-items:center; gap:8px; margin-bottom:6px; font-size:.84rem; }
.cal-contact i { color:var(--brand); width:18px; text-align:center; }
.cal-contact a { color:inherit; text-decoration:none; }

/* ----- รายการของวัน / รายละเอียด ----- */
.cal-item { display:block; width:100%; text-align:left; padding:12px 14px; margin-bottom:10px; border:1px solid var(--line); border-left:5px solid var(--room, #9aa7b6); border-radius:0; background:#fff; }
.cal-item:hover { background:#f6f9ff; }
.cal-item .t { font-weight:600; font-variant-numeric:tabular-nums; }
.cal-item .ti { font-weight:500; overflow-wrap:anywhere; }
.cal-item .m { color:var(--muted); font-size:.86rem; overflow-wrap:anywhere; }
.cal-pill { display:inline-flex; align-items:center; gap:6px; padding:2px 10px; border-radius:999px; font-size:.78rem; font-weight:500; white-space:nowrap; }
.cal-pill::before { content:""; width:6px; height:6px; border-radius:50%; background:currentColor; }
.cal-pill.ok { background:var(--ok-bg); color:var(--ok-fg); }
.cal-pill.wait { background:var(--wait-bg); color:var(--wait-fg); }

/* ----- หน้าต่างรายละเอียดการจอง ----- */
.cal-modal-dialog { max-width:min(860px, calc(100vw - 24px)); }
.cal-modal { border:0; border-radius:20px; overflow:hidden; box-shadow:0 20px 50px rgba(18,52,86,.28); }
.cal-modal.is-ok   { --hd1:#14683f; --hd2:#2e9d62; --hd-ink:#fff; --tint:#eaf6ef; --tint-line:#bfe3cf; --accent:#1f8a52; }
.cal-modal.is-wait { --hd1:#d99200; --hd2:#f4c04d; --hd-ink:#3d2a00; --tint:#fff6dc; --tint-line:#f1d78a; --accent:#b97a00; }
.cal-mh { position:relative; padding:24px 28px 20px; background:linear-gradient(135deg, var(--hd1), var(--hd2)); color:var(--hd-ink); border-bottom:6px solid var(--room, #9aa7b6); }
.cal-mh-kicker { font-size:.82rem; opacity:.9; margin-bottom:4px; }
.cal-mh-title { font-size:1.5rem; font-weight:600; line-height:1.3; margin:0; overflow-wrap:anywhere; }
.cal-mh-status { display:inline-flex; align-items:center; margin-top:12px; padding:4px 14px; border-radius:999px; background:rgba(255,255,255,.92); color:var(--accent); font-size:.86rem; font-weight:600; }
.cal-modal.is-wait .cal-mh-close { filter:none; }
.cal-mb { padding:24px 28px 10px; }
.cal-hero { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px; }
.cal-hero-item, .cal-roombox { display:flex; gap:12px; align-items:flex-start; padding:12px 14px; border-radius:14px; background:var(--tint); border:1px solid var(--tint-line); }
.cal-roombox { margin-bottom:16px; }
.cal-modal .ico { flex:none; display:inline-flex; align-items:center; justify-content:center; width:38px; height:38px; border-radius:12px; background:var(--accent); color:#fff; font-size:1rem; }
.cal-modal .k { font-size:.78rem; color:#667587; margin-bottom:1px; }
.cal-modal .v { font-weight:500; overflow-wrap:anywhere; line-height:1.5; }
.cal-modal .v.big { font-size:1.3rem; font-weight:600; line-height:1.2; font-variant-numeric:tabular-nums; }
.cal-modal .s { font-size:.8rem; color:#667587; margin-top:2px; }
.cal-people { display:grid; gap:10px; }
.cal-prow { display:flex; gap:14px; align-items:flex-start; padding:10px 4px; border-bottom:1px solid #eef1f5; }
.cal-prow:last-child { border-bottom:0; }
.cal-prow .ico { background:#eef1f6; color:#445468; width:34px; height:34px; border-radius:10px; font-size:.92rem; }
.cal-mf { border-top:0; padding:10px 28px 20px; }
.cal-day-dialog { max-width:min(680px, calc(100vw - 24px)); }
.cal-dh { padding:24px 28px 20px; background:linear-gradient(135deg, #123456, #2a64a8); color:#fff; }
.cal-dh-count { display:inline-flex; margin-top:12px; padding:4px 14px; border-radius:999px; background:rgba(255,255,255,.92); color:#123456; font-size:.86rem; font-weight:600; }
.cal-dh-count.is-free { color:#14683f; }
.cal-dayempty { text-align:center; padding:26px 10px; color:#14683f; }
.cal-dayempty i { display:block; font-size:2.3rem; margin-bottom:8px; }
@media (max-width: 575.98px) { .cal-hero { grid-template-columns:1fr; } .cal-mh, .cal-dh, .cal-mb, .cal-mf { padding-left:18px; padding-right:18px; } }

@media (max-width: 767.98px) {
    .cal-card { padding:14px; }
    .cal-title { font-size:1.35rem; }
    .cal-nav .cal-title { font-size:1.5rem; }
    .cal-page .fc .fc-daygrid-day-frame { min-height:84px; }
    .cal-page .fc .fc-col-header-cell-cushion { padding:8px 2px; font-size:.85rem; }
}
@media (max-width: 575.98px) {
    .cal-ev-title, .cal-ev-ico { display:none; }
    .cal-ev { padding:1px 4px; font-size:.7rem; }
    .cal-page .fc .fc-daygrid-event { margin:2px 3px 0; }
    .cal-page .fc .fc-daygrid-day-frame { min-height:70px; }
}
@media (prefers-reduced-motion: reduce) { .cal-page * { transition:none !important; } }
</style>

<div class="container-fluid py-4 px-lg-4 cal-page">
    <div class="cal-layout">

        <div class="cal-main">
            <section class="cal-card">
                <div class="cal-top">
                    <div>
                        <h1 class="cal-h1">ปฏิทินการจองห้อง</h1>
                        <p class="cal-sub">งานเทคโนโลยีดิจิทัล</p>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="year-view.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-calendar-week me-1"></i> ดูภาพรวมรายปี</a>
                        <a href="#" id="addBookingBtn" class="btn btn-primary btn-sm"><i class="fas fa-plus me-1"></i> เพิ่มการจอง</a>
                    </div>
                </div>

                <div class="cal-nav">
                <div class="cal-rooms" id="roomChips" role="group" aria-label="เลือกห้องที่จะแสดง">
                    <button type="button" class="room-chip is-active" data-room="all" aria-pressed="true"><span class="txt">ทุกห้อง</span></button>
                    <?php foreach ($rooms_js as $r): ?>
                        <button type="button" class="room-chip" data-room="<?php echo (int)$r['id']; ?>" aria-pressed="false" style="--room:<?php echo htmlspecialchars($r['color']); ?>;--room-ink:<?php echo htmlspecialchars($r['ink']); ?>" title="<?php echo htmlspecialchars($r['name']); ?>">
                            <span class="dot"></span><span class="txt"><?php echo htmlspecialchars($r['name']); ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>

                <div class="cal-bar">
                    <h2 class="cal-title" id="calTitle" aria-live="polite"></h2>
                    <div class="cal-ctrl">
                        <button type="button" class="cal-btn" id="calPrev" aria-label="เดือนก่อนหน้า"><i class="fas fa-chevron-left"></i></button>
                        <button type="button" class="cal-btn" id="calNext" aria-label="เดือนถัดไป"><i class="fas fa-chevron-right"></i></button>
                        <button type="button" class="cal-btn" id="calToday">วันนี้</button>
                        <select id="monthSel" class="form-select form-select-sm" aria-label="เลือกเดือน"></select>
                        <select id="yearSel" class="form-select form-select-sm" aria-label="เลือกปี พ.ศ."></select>
                    </div>
                </div>
                </div>

                <div id="calendar"></div>
            </section>
        </div>

        <aside class="cal-aside">
            <section class="cal-side" aria-labelledby="todayHead">
                <h2 id="todayHead">วันนี้ <span id="todayCount" class="cal-muted"></span></h2>
                <div class="cal-today-date" id="todayDate"></div>
                <div id="todayList"><div class="cal-muted">กำลังโหลด…</div></div>
            </section>

            <section class="cal-side">
                <h2>คำอธิบายสี</h2>
                <div class="cal-legend"><span class="sw ok"></span><span>อนุมัติแล้ว</span></div>
                <div class="cal-legend"><span class="sw wait"></span><span>รออนุมัติ</span></div>
                <div class="cal-muted mt-2">แถบสีด้านซ้ายของแต่ละรายการคือสีของห้อง</div>
            </section>

            <section class="cal-side cal-notice">
                <h2><i class="fas fa-triangle-exclamation me-2"></i>ประกาศ</h2>
                <p class="mb-0">ระบบยังไม่เปิดให้มีการจองออนไลน์ เพียงแต่ให้ท่านสามารถดูวัน-เวลา ที่สามารถจองได้เท่านั้น</p>
            </section>

            <section class="cal-side">
                <a href="manual1.jpg" target="_blank" rel="noopener" download class="btn btn-info btn-sm w-100"><i class="fas fa-book me-2"></i>ดาวน์โหลดคู่มือจองห้อง</a>
            </section>

            <section class="cal-side">
                <h2>ติดต่อสอบถาม</h2>
                <div class="cal-contact"><i class="fas fa-phone"></i><span>พญาไท <a href="tel:022015814">02 201 5814</a></span></div>
                <div class="cal-contact mb-0"><i class="fas fa-phone"></i><span>ศาลายา โทรภายใน 1106</span></div>
            </section>
        </aside>
    </div>
</div>

<!-- รายการจองของวันที่เลือก (popup กลางจอ) -->
<div class="modal fade" id="dayModal" tabindex="-1" aria-labelledby="dayPanelTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable cal-day-dialog">
    <div class="modal-content cal-modal">
      <div class="cal-dh">
        <div class="d-flex justify-content-between align-items-start gap-3">
          <div style="min-width:0">
            <div class="cal-mh-kicker"><i class="far fa-calendar me-1"></i>รายการจองประจำวัน</div>
            <h2 class="cal-mh-title" id="dayPanelTitle"></h2>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="ปิด"></button>
        </div>
        <span class="cal-dh-count" id="dayCount"></span>
      </div>
      <div class="modal-body cal-mb" id="dayPanelList"></div>
      <div class="modal-footer cal-mf" id="dayPanelFoot"></div>
    </div>
  </div>
</div>

<!-- รายละเอียดการจอง -->
<div class="modal fade" id="eventDetailModal" tabindex="-1" aria-labelledby="eventDetailModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable cal-modal-dialog">
    <div class="modal-content cal-modal" id="evContent">
      <div class="cal-mh">
        <div class="d-flex justify-content-between align-items-start gap-3">
          <div style="min-width:0">
            <div class="cal-mh-kicker"><i class="far fa-calendar-check me-1"></i>รายละเอียดการจอง</div>
            <h2 class="cal-mh-title" id="eventDetailModalLabel"></h2>
          </div>
          <button type="button" class="btn-close btn-close-white cal-mh-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
        </div>
        <span class="cal-mh-status" id="eventStatusPill"></span>
      </div>

      <div class="modal-body cal-mb">
        <div class="cal-hero">
          <div class="cal-hero-item">
            <span class="ico"><i class="far fa-calendar"></i></span>
            <div><div class="k">วันที่</div><div class="v" id="evDate"></div></div>
          </div>
          <div class="cal-hero-item">
            <span class="ico"><i class="far fa-clock"></i></span>
            <div><div class="k">เวลา</div><div class="v big" id="evTime"></div><div class="s" id="evDur"></div></div>
          </div>
        </div>

        <div class="cal-roombox">
          <span class="ico"><i class="fas fa-location-dot"></i></span>
          <div><div class="k">ห้อง</div><div class="v" id="evRoom"></div></div>
        </div>

        <div class="cal-people" id="evPeople"></div>
      </div>

      <div class="modal-footer cal-mf">
        <button type="button" class="btn btn-outline-secondary px-3 me-auto d-none" id="evBack"><i class="fas fa-arrow-left me-1"></i>กลับไปรายการของวัน</button>
        <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">ปิด</button>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const LOGGED_IN = <?php echo is_logged_in() ? 'true' : 'false'; ?>;
    const ROOMS = <?php echo json_encode($rooms_js, JSON_UNESCAPED_UNICODE); ?>;
    const ROOM_COLOR = {};
    ROOMS.forEach(r => { ROOM_COLOR[r.name] = r.color; });

    /* ---------- ปฏิทินไทย: ชื่อเดือน/วัน และปี พ.ศ. ---------- */
    const MONTHS = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
    const DOW_FULL = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
    const DOW_SHORT = ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'];
    const be = y => y + 543;
    const pad = n => String(n).padStart(2, '0');
    const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
    const hm = d => pad(d.getHours()) + ':' + pad(d.getMinutes());
    const thDateLong = d => 'วัน' + DOW_FULL[d.getDay()] + 'ที่ ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + be(d.getFullYear());
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const parseLocal = s => new Date(String(s).replace(' ', 'T'));
    const el = id => document.getElementById(id);

    let roomId = 'all';
    const mq = window.matchMedia('(max-width: 767.98px)');

    /* ---------- สถานะการล็อกอิน / ปุ่มจอง ---------- */
    function askLogin() {
        Swal.fire({
            icon: 'info', title: 'กรุณาเข้าสู่ระบบ', text: 'คุณต้องเข้าสู่ระบบก่อนทำการจองห้อง',
            confirmButtonText: 'ตกลง', footer: '<a href="login.php">ไปที่หน้าเข้าสู่ระบบ</a>'
        });
    }
    function bookFor(dateStr) {
        if (!LOGGED_IN) { askLogin(); return; }
        window.location.href = 'booking-form.php' + (dateStr ? '?date=' + encodeURIComponent(dateStr) : '');
    }
    el('addBookingBtn').addEventListener('click', function (e) { e.preventDefault(); bookFor(''); });

    /* ---------- รายละเอียดการจอง ---------- */
    const detailModal = new bootstrap.Modal(el('eventDetailModal'));
    function durationText(start, end) {
        if (!end) { return ''; }
        const mins = Math.round((end - start) / 60000);
        if (mins <= 0) { return ''; }
        const h = Math.floor(mins / 60), m = mins % 60;
        return 'ระยะเวลา ' + (h ? h + ' ชั่วโมง' : '') + (h && m ? ' ' : '') + (m ? m + ' นาที' : '');
    }
    function showDetail(d, fromDay) {
        el('evBack').classList.toggle('d-none', !fromDay);
        const ok = d.status === 'approved';
        const box = el('evContent');
        box.classList.toggle('is-ok', ok);
        box.classList.toggle('is-wait', !ok);
        box.style.setProperty('--room', ROOM_COLOR[d.room] || '#9aa7b6');

        el('eventDetailModalLabel').textContent = d.title;
        el('eventStatusPill').innerHTML = ok
            ? '<i class="fas fa-circle-check me-1"></i>อนุมัติแล้ว'
            : '<i class="fas fa-hourglass-half me-1"></i>รออนุมัติ';
        el('evDate').textContent = thDateLong(d.start);
        el('evTime').textContent = hm(d.start) + (d.end ? ' - ' + hm(d.end) : '') + ' น.';
        el('evDur').textContent = durationText(d.start, d.end);
        el('evRoom').textContent = d.room || '-';

        const people = [
            ['fa-user', 'ผู้จอง', d.user],
            ['fa-user-tie', 'อาจารย์ผู้สอน', d.instructor],
            ['fa-users', 'จำนวนนักศึกษา', (d.students === null || d.students === undefined || String(d.students).trim() === '') ? '' : d.students + ' คน'],
            ['fa-building', 'ส่วนงาน/ภาควิชา', d.department]
        ];
        const wrap = el('evPeople');
        wrap.innerHTML = '';
        people.forEach(function (r) {
            if (r[2] === null || r[2] === undefined || String(r[2]).trim() === '') { return; }
            const row = document.createElement('div');
            row.className = 'cal-prow';
            const ico = document.createElement('span');
            ico.className = 'ico';
            ico.innerHTML = '<i class="fas ' + r[0] + '"></i>';
            const txt = document.createElement('div');
            const k = document.createElement('div'); k.className = 'k'; k.textContent = r[1];
            const v = document.createElement('div'); v.className = 'v'; v.textContent = r[2];
            txt.appendChild(k); txt.appendChild(v);
            row.appendChild(ico); row.appendChild(txt);
            wrap.appendChild(row);
        });
        detailModal.show();
    }
    const fromEvent = e => ({
        title: e.title, room: e.extendedProps.room_name, start: e.start, end: e.end, status: e.extendedProps.status,
        user: e.extendedProps.user_name, instructor: e.extendedProps.instructor_name,
        students: e.extendedProps.student_count, department: e.extendedProps.department
    });
    const fromApi = e => ({
        title: e.title, room: e.extendedProps.room_name, start: parseLocal(e.start), end: e.end ? parseLocal(e.end) : null,
        status: e.extendedProps.status, user: e.extendedProps.user_name, instructor: e.extendedProps.instructor_name,
        students: e.extendedProps.student_count, department: e.extendedProps.department
    });

    /* ---------- รายการของวันที่เลือก ---------- */
    const dayModal = new bootstrap.Modal(el('dayModal'));
    let currentDay = null, pendingDetail = null, backToDay = false;

    function itemButton(d) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'cal-item';
        b.style.setProperty('--room', ROOM_COLOR[d.room] || '#9aa7b6');
        const ok = d.status === 'approved';
        b.innerHTML = '<div class="d-flex justify-content-between align-items-start gap-2">' +
            '<span class="t">' + hm(d.start) + (d.end ? ' - ' + hm(d.end) : '') + '</span>' +
            '<span class="cal-pill ' + (ok ? 'ok' : 'wait') + '">' + (ok ? 'อนุมัติแล้ว' : 'รออนุมัติ') + '</span></div>' +
            '<div class="ti">' + esc(d.title) + '</div>' +
            '<div class="m">' + esc(d.room) + '</div>';
        // ปิด popup ของวันก่อน แล้วเปิดรายละเอียด (กัน modal ซ้อนกัน)
        b.addEventListener('click', function () { pendingDetail = d; dayModal.hide(); });
        return b;
    }
    el('dayModal').addEventListener('hidden.bs.modal', function () {
        if (pendingDetail) { const d = pendingDetail; pendingDetail = null; showDetail(d, true); }
    });
    el('eventDetailModal').addEventListener('hidden.bs.modal', function () {
        if (backToDay && currentDay) { backToDay = false; openDay(currentDay); }
    });
    el('evBack').addEventListener('click', function () { backToDay = true; detailModal.hide(); });

    function openDay(date) {
        const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        const dayEnd = new Date(dayStart.getTime() + 86400000);
        currentDay = dayStart;
        const list = calendar.getEvents()
            .filter(e => e.start < dayEnd && (e.end || e.start) > dayStart)
            .sort((a, b) => a.start - b.start);

        el('dayPanelTitle').textContent = thDateLong(dayStart);
        const count = el('dayCount');
        count.textContent = list.length ? list.length + ' รายการ' : 'ว่างทั้งวัน';
        count.classList.toggle('is-free', list.length === 0);

        const box = el('dayPanelList');
        box.innerHTML = '';
        if (list.length === 0) {
            box.innerHTML = '<div class="cal-dayempty"><i class="far fa-circle-check"></i>' +
                '<div class="fw-medium">' + (roomId === 'all' ? 'ยังไม่มีการจองในวันนี้' : 'ห้องที่เลือกยังว่าง') + '</div>' +
                '<div class="cal-muted">' + (roomId === 'all' ? 'ห้องว่างทุกห้องตลอดทั้งวัน' : 'ว่างตลอดทั้งวัน') + '</div></div>';
        } else {
            list.forEach(e => box.appendChild(itemButton(fromEvent(e))));
        }

        const foot = el('dayPanelFoot');
        foot.innerHTML = '<button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">ปิด</button>';
        const today = new Date(); today.setHours(0, 0, 0, 0);
        if (dayStart >= today) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn-primary px-4';
            btn.innerHTML = '<i class="fas fa-plus me-1"></i> จองห้องในวันนี้';
            btn.addEventListener('click', function () { bookFor(ymd(dayStart)); });
            foot.appendChild(btn);
        }
        dayModal.show();
    }

    /* ---------- ส่วนหัวปฏิทิน (เดือน/ปี พ.ศ.) ---------- */
    const monthSel = el('monthSel'), yearSel = el('yearSel');
    MONTHS.forEach((m, i) => { const o = document.createElement('option'); o.value = i; o.textContent = m; monthSel.appendChild(o); });
    function syncHeader(info) {
        const cs = info.view.currentStart;
        el('calTitle').textContent = MONTHS[cs.getMonth()] + ' ' + be(cs.getFullYear());
        monthSel.value = cs.getMonth();
        const nowY = new Date().getFullYear();
        const from = Math.min(nowY - 2, cs.getFullYear()), to = Math.max(nowY + 2, cs.getFullYear());
        yearSel.innerHTML = '';
        for (let y = from; y <= to; y++) { const o = document.createElement('option'); o.value = y; o.textContent = be(y); yearSel.appendChild(o); }
        yearSel.value = cs.getFullYear();
    }
    function jump() { calendar.gotoDate(new Date(parseInt(yearSel.value, 10), parseInt(monthSel.value, 10), 1)); }
    monthSel.addEventListener('change', jump);
    yearSel.addEventListener('change', jump);
    el('calPrev').addEventListener('click', () => calendar.prev());
    el('calNext').addEventListener('click', () => calendar.next());
    el('calToday').addEventListener('click', () => calendar.today());

    /* ---------- ปฏิทิน ---------- */
    function renderEvent(arg) {
        const ev = arg.event, p = ev.extendedProps;
        const color = ROOM_COLOR[p.room_name] || '#9aa7b6';
        const pending = p.status !== 'approved';
        return {
            html: '<div class="cal-ev ' + (pending ? 'is-pending' : 'is-approved') + '" style="--room:' + esc(color) + '" title="' + esc(ev.title) + '">' +
                (pending ? '<i class="fas fa-hourglass-half cal-ev-ico" aria-hidden="true"></i>' : '') +
                '<span class="cal-ev-time">' + (ev.start ? hm(ev.start) : '') + '</span>' +
                '<span class="cal-ev-title">' + esc(ev.title) + '</span></div>'
        };
    }

    const calendarEl = el('calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        locale: 'th',
        initialView: 'dayGridMonth',
        headerToolbar: false,
        firstDay: 0,
        showNonCurrentDates: false,
        fixedWeekCount: false,
        height: 'auto',
        eventDisplay: 'block',
        dayMaxEvents: mq.matches ? 2 : 3,
        moreLinkContent: a => '+' + a.num + ' รายการ',
        moreLinkClick: function (a) { openDay(a.date); },
        dayHeaderContent: a => (mq.matches ? DOW_SHORT : DOW_FULL)[a.date.getDay()],
        dayCellContent: a => ({ html: '<span class="cal-num">' + a.date.getDate() + '</span>' }),
        events: {
            url: 'api/get_events.php',
            extraParams: function () { return { room_id: roomId }; }
        },
        eventDataTransform: function (e) { delete e.backgroundColor; delete e.borderColor; delete e.textColor; return e; },
        eventContent: renderEvent,
        datesSet: syncHeader,
        loading: function (isLoading) { calendarEl.classList.toggle('is-loading', isLoading); },
        dateClick: function (info) { openDay(info.date); },
        eventClick: function (info) { info.jsEvent.preventDefault(); showDetail(fromEvent(info.event)); }
    });
    calendar.render();
    mq.addEventListener('change', function () {
        calendar.setOption('dayMaxEvents', mq.matches ? 2 : 3);
        calendar.render();
    });

    /* ---------- เลือกห้อง ---------- */
    el('roomChips').addEventListener('click', function (e) {
        const chip = e.target.closest('.room-chip');
        if (!chip) { return; }
        roomId = chip.dataset.room;
        this.querySelectorAll('.room-chip').forEach(function (c) {
            const on = (c === chip);
            c.classList.toggle('is-active', on);
            c.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        calendar.refetchEvents();
        loadToday();
    });

    /* ---------- การจองวันนี้ (แถบด้านข้าง) ---------- */
    function loadToday() {
        const now = new Date();
        const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const dayEnd = new Date(dayStart.getTime() + 86400000);
        el('todayDate').textContent = thDateLong(dayStart);
        const url = 'api/get_events.php?room_id=' + encodeURIComponent(roomId) + '&start=' + ymd(dayStart) + '&end=' + ymd(dayEnd);
        fetch(url)
            .then(r => r.json())
            .then(function (data) {
                const rows = data
                    .filter(e => parseLocal(e.start) < dayEnd && (e.end ? parseLocal(e.end) : parseLocal(e.start)) > dayStart)
                    .sort((a, b) => parseLocal(a.start) - parseLocal(b.start));
                const box = el('todayList');
                box.innerHTML = '';
                el('todayCount').textContent = rows.length ? '(' + rows.length + ' รายการ)' : '';
                if (rows.length === 0) {
                    box.innerHTML = '<div class="cal-muted">วันนี้ยังไม่มีการจอง</div>';
                    return;
                }
                rows.slice(0, 8).forEach(function (e) {
                    const d = fromApi(e);
                    const b = document.createElement('button');
                    b.type = 'button';
                    b.className = 'cal-today-item';
                    b.style.setProperty('--room', ROOM_COLOR[d.room] || '#9aa7b6');
                    b.innerHTML = '<span class="t">' + hm(d.start) + '</span><span class="n">' + esc(d.title) + '<span class="r">' + esc(d.room) + '</span></span>';
                    b.addEventListener('click', function () { showDetail(d); });
                    box.appendChild(b);
                });
                if (rows.length > 8) {
                    const more = document.createElement('div');
                    more.className = 'cal-muted';
                    more.textContent = 'และอีก ' + (rows.length - 8) + ' รายการ';
                    box.appendChild(more);
                }
            })
            .catch(function () { el('todayList').innerHTML = '<div class="cal-muted">โหลดรายการวันนี้ไม่สำเร็จ</div>'; });
    }
    loadToday();
});
</script>
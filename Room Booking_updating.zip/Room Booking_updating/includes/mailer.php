<?php
// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require '../vendor/autoload.php';
include_once 'config.php'; // Include your config file

function send_booking_notification($booking_id, $new_status) {
    global $pdo;

    // Fetch booking details and user email
    $stmt = $pdo->prepare("
        SELECT b.title, r.name as room_name, b.start_time, b.end_time, u.email, u.full_name
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN rooms r ON b.room_id = r.id
        WHERE b.id = ?
    ");
    $stmt->execute([$booking_id]);
    $details = $stmt->fetch();

    if (!$details) {
        return; // Booking not found
    }

    $subject = '';
    $body = '';
    $recipient_email = $details['email'];
    $recipient_name = $details['full_name'];
    $start_formatted = date('d/m/Y H:i', strtotime($details['start_time']));
    $end_formatted = date('H:i', strtotime($details['end_time']));

    if ($new_status === 'approved') {
        $subject = '✔️ การจองห้องของคุณได้รับการอนุมัติแล้ว';
        $body = "เรียนคุณ {$recipient_name},<br><br>รายการจองห้องของคุณสำหรับหัวข้อ '<b>{$details['title']}</b>' ในห้อง <b>{$details['room_name']}</b> วันที่ {$start_formatted} - {$end_formatted} ได้รับการ <b>อนุมัติ</b> เรียบร้อยแล้ว";
    } elseif ($new_status === 'rejected') {
        $subject = '❌ การจองห้องของคุณถูกปฏิเสธ';
        $body = "เรียนคุณ {$recipient_name},<br><br>ขออภัย รายการจองห้องของคุณสำหรับหัวข้อ '<b>{$details['title']}</b>' ในห้อง <b>{$details['room_name']}</b> วันที่ {$start_formatted} - {$end_formatted} ถูก <b>ปฏิเสธ</b> กรุณาติดต่อผู้ดูแลระบบเพื่อสอบถามข้อมูลเพิ่มเติม";
    } else {
        return; // Don't send email for other statuses for now
    }

    // Send the email
    send_email($recipient_email, $recipient_name, $subject, $body);
}

function send_email($recipient_email, $recipient_name, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = 'UTF-8';

        //Recipients
        $mail->setFrom(SMTP_USER, 'ระบบจองห้อง');
        $mail->addAddress($recipient_email, $recipient_name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
    } catch (Exception $e) {
        // Log the error, don't display it to the user
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }
}
?>
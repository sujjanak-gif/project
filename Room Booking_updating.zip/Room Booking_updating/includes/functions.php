<?php
// Start session at the top of the functions file if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return is_logged_in() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Checks if the logged-in user has the 'officer' role.
 * @return bool
 */
function is_officer() {
    return is_logged_in() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'officer';
}

/**
 * Checks if the logged-in user has permission to manage bookings (admin or officer).
 * @return bool
 */
function can_manage_bookings() {
    return is_admin() || is_officer();
}


function require_login() {
    if (!is_logged_in()) {
        $path_prefix = (basename(dirname($_SERVER['PHP_SELF'])) !== 'room-booking-system') ? '../' : '';
        header('Location: ' . $path_prefix . 'login.php');
        exit();
    }
}

function require_admin() {
    if (!is_admin()) {
         $path_prefix = '../';
        header('Location: ' . $path_prefix . 'error.php?code=403');
        exit();
    }
}

/**
 * Requires user to be an admin or officer to access a page.
 */
function require_panel_access() {
    if (!can_manage_bookings()) { // ใช้ฟังก์ชัน can_manage_bookings() ที่เราสร้างไว้
        $path_prefix = '../';
        header('Location: ' . $path_prefix . 'error.php?code=403');
        exit();
    }
}

function get_redirect_url() {
    if (isset($_SESSION['user_role'])) {
        if ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'officer') {
            return 'admin/index.php';
        } else {
            return 'user/index.php';
        }
    }
    return 'index.php'; // Fallback
}

function format_status_badge($status) {
    switch ($status) {
        case 'approved':
            return '<span class="badge bg-success">อนุมัติ</span>';
        case 'pending':
            return '<span class="badge bg-warning text-dark">รออนุมัติ</span>';
        case 'rejected':
            return '<span class="badge bg-danger">ปฏิเสธ</span>';
        case 'cancelled':
            return '<span class="badge bg-secondary">ยกเลิก</span>';
        default:
            return '<span class="badge bg-light text-dark">ไม่ทราบ</span>';
    }
}

function format_user_status_badge($status) {
    switch ($status) {
        case 'approved':
            return '<span class="badge bg-success">อนุมัติแล้ว</span>';
        case 'pending':
            return '<span class="badge bg-warning text-dark">รออนุมัติ</span>';
        case 'inactive': // <-- Added case for inactive
            return '<span class="badge bg-secondary">ไม่ใช้งาน</span>';
        case 'suspended': // Added for suspended status
            return '<span class="badge bg-danger">ถูกระงับ</span>';
        default:
            return '<span class="badge bg-light text-dark">ไม่ทราบ</span>';
    }
}

function format_user_role($role) {
    $roles = [
        'admin' => 'Admin',
        'officer' => 'Officer',
        'author' => 'Author',
        'contributor' => 'Contributor',
        'user' => 'User'
    ];
    return $roles[$role] ?? ucfirst($role);
}

/**
 * CSRF token helpers (สร้างโทเคนต่อ session และตรวจสอบตอนรับ POST)
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify($token) {
    return !empty($_SESSION['csrf_token'])
        && is_string($token)
        && hash_equals($_SESSION['csrf_token'], $token);
}
?>

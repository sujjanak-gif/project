<?php
// Determine the base path prefix
$path_prefix = '';
if (strpos($_SERVER['PHP_SELF'], '/admin/') !== false || strpos($_SERVER['PHP_SELF'], '/user/') !== false) {
    $path_prefix = '../';
}

// **ปรับปรุง: กำหนดลิงก์ปลายทางตามสิทธิ์ผู้ใช้**
$home_url = $path_prefix . 'index.php';
if (function_exists('can_manage_bookings') && can_manage_bookings()) {
    $home_url = $path_prefix . 'admin/index.php';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' : ''; ?>Room Booking System</title>
    <link rel="icon" href="<?php echo $path_prefix; ?>assets/images/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:wght@300;400;500;700&display=swap" rel="stylesheet">
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar/locales/th.js'></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <link rel="stylesheet" href="<?php echo $path_prefix; ?>assets/css/style.css">
</head>
<body class="d-flex flex-column min-vh-100">

<header class="bg-dark-blue text-white shadow-sm">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="<?php echo $home_url; ?>">
                <img src="<?php echo $path_prefix; ?>assets/images/logo_mu_th_2.png.png" alt="Logo" width="230" height="60" class="d-inline-block align-text-top me-2">
       			งานเทคโนโลยีดิจิทัล
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (is_logged_in()): ?>
                         <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle me-1"></i> 
                                <?php echo isset($_SESSION['user_fullname']) ? htmlspecialchars($_SESSION['user_fullname']) : 'ผู้ใช้งาน'; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <?php if(can_manage_bookings()): ?>
                                <li><a class="dropdown-item" href="<?php echo $path_prefix; ?>admin/index.php">แผงควบคุมหลัก</a></li>
                                <?php else: ?>
                                <li><a class="dropdown-item" href="<?php echo $path_prefix; ?>user/index.php">แดชบอร์ดของฉัน</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo $path_prefix; ?>logout.php">ออกจากระบบ</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $path_prefix; ?>index.php"><i class="fas fa-home me-1"></i> กลับหน้าปฏิทิน</a>
                        </li>
                        <li class="nav-item">
                             <a class="nav-link" href="<?php echo $path_prefix; ?>login.php">เข้าสู่ระบบ</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>

<main class="flex-shrink-0">
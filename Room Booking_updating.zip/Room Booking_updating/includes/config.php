<?php
// Database credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'roombooking');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Email settings (สำหรับขั้นตอนการแจ้งเตือนในอนาคต)
define('SMTP_HOST', 'smtp-mail.outlook.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'sujja.nak@mahidol.ac.th');
define('SMTP_PASS', 'ilovejj007');
?>
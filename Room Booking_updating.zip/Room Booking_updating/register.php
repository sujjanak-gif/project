<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once 'includes/db.php';
include_once 'includes/functions.php';

// ถ้า includes/functions.php ยังไม่ได้อัปเดตเป็นเวอร์ชันใหม่ ให้ข้ามการจำกัดการลองผิดแทนที่จะเกิด Fatal error
if (!function_exists('auth_client_ip')) {
    function auth_client_ip() { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }
}
if (!function_exists('auth_throttle_wait')) {
    function auth_throttle_wait($pdo, $action, $ident, $max_ident = 5, $max_ip = 20, $window_min = 15) { return 0; }
}
if (!function_exists('auth_throttle_fail')) {
    function auth_throttle_fail($pdo, $action, $ident) { }
}
if (!function_exists('auth_throttle_clear')) {
    function auth_throttle_clear($pdo, $action, $ident) { }
}

if (is_logged_in()) {
    header('Location: ' . get_redirect_url());
    exit();
}

/* =====================================================================
   ตั้งค่า: จำกัดโดเมนอีเมลที่สมัครได้ (เช่น ['mahidol.ac.th', 'mahidol.edu'])
   เว้นว่างไว้ = ไม่จำกัด (ตรงกับพฤติกรรมเดิม)
   ===================================================================== */
$allowed_email_domains = [];

function reg_str($key, $max) {
    $v = isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : '';
    return function_exists('mb_substr') ? mb_substr($v, 0, $max) : substr($v, 0, $max);
}

$departments = [];
try {
    $departments = $pdo->query("SELECT DISTINCT department FROM users WHERE department IS NOT NULL AND department <> '' ORDER BY department")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) { /* ไม่มีรายการแนะนำก็ใช้งานได้ */ }

$errors = [];
$success = false;
$old = ['full_name' => '', 'username' => '', 'email' => '', 'department' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = reg_str('full_name', 255);
    $username = reg_str('username', 50);
    $email = reg_str('email', 255);
    $department = reg_str('department', 255);
    $password = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) && is_string($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    $terms = isset($_POST['terms']);
    $old = ['full_name' => $full_name, 'username' => $username, 'email' => $email, 'department' => $department];

    if (function_exists('csrf_verify') && !csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors[] = 'หน้านี้หมดอายุ กรุณาลองลงทะเบียนอีกครั้ง';
    } elseif (!empty($_POST['website'])) {
        // ช่องดักบอท (มนุษย์มองไม่เห็นและไม่กรอก) แกล้งทำเป็นสำเร็จโดยไม่บันทึกอะไร
        $success = true;
    } else {
        $ident = hash('sha256', auth_client_ip());
        $wait = auth_throttle_wait($pdo, 'register', $ident, 5, 5, 60);
        if ($wait > 0) {
            $errors[] = 'ลงทะเบียนบ่อยเกินไป กรุณาลองใหม่ในอีก ' . max(1, (int)ceil($wait / 60)) . ' นาที';
        } else {
            if ($full_name === '') { $errors[] = 'กรุณากรอกชื่อ-สกุล'; }

            if ($username === '') {
                $errors[] = 'กรุณากรอกชื่อผู้ใช้';
            } elseif (!preg_match('/^[\p{L}\p{N}._-]{3,50}$/u', $username)) {
                $errors[] = 'ชื่อผู้ใช้ต้องยาว 3-50 ตัวอักษร ใช้ได้เฉพาะตัวอักษร ตัวเลข จุด ขีดกลาง และขีดล่าง (ไม่มีช่องว่าง)';
            }

            if ($password === '' || $confirm_password === '') {
                $errors[] = 'กรุณากรอกรหัสผ่าน';
            } elseif ($password !== $confirm_password) {
                $errors[] = 'รหัสผ่านไม่ตรงกัน';
            } elseif (strlen($password) < 8) {
                $errors[] = 'รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร';
            } elseif (strlen($password) > 72) {
                $errors[] = 'รหัสผ่านยาวเกินไป (ไม่เกิน 72 ตัวอักษร)';
            } elseif (strcasecmp($password, $username) === 0) {
                $errors[] = 'รหัสผ่านต้องไม่เหมือนชื่อผู้ใช้';
            }

            if ($email === '') {
                $errors[] = 'กรุณากรอกอีเมล';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'รูปแบบอีเมลไม่ถูกต้อง';
            } elseif (!empty($allowed_email_domains)) {
                $dom = strtolower(substr($email, strrpos($email, '@') + 1));
                $ok_dom = false;
                foreach ($allowed_email_domains as $d) {
                    if ($dom === $d || substr($dom, -(strlen($d) + 1)) === '.' . $d) { $ok_dom = true; break; }
                }
                if (!$ok_dom) { $errors[] = 'กรุณาใช้อีเมลของหน่วยงาน (' . implode(', ', $allowed_email_domains) . ')'; }
            }

            if ($department === '') { $errors[] = 'กรุณากรอกส่วนงาน/ภาควิชา'; }
            if (!$terms) { $errors[] = 'กรุณายอมรับข้อกำหนดและเงื่อนไข'; }

            if (empty($errors)) {
                try {
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                    $stmt->execute([$username, $email]);
                    if ($stmt->fetch()) {
                        $errors[] = 'ชื่อผู้ใช้หรืออีเมลนี้มีอยู่ในระบบแล้ว';
                    }
                } catch (PDOException $e) {
                    error_log("Database error during user check: " . $e->getMessage());
                    $errors[] = 'เกิดข้อผิดพลาดในการตรวจสอบข้อมูล กรุณาลองใหม่อีกครั้ง';
                }
            }

            if (empty($errors)) {
                try {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO users (full_name, username, password, email, department, role, status) VALUES (?, ?, ?, ?, ?, 'user', 'pending')");
                    $stmt->execute([$full_name, $username, $hashed_password, $email, $department]);
                    auth_throttle_fail($pdo, 'register', $ident); // นับเป็นการลงทะเบียน 1 ครั้งของ IP นี้
                    $success = true;
                } catch (PDOException $e) {
                    error_log("Database error during registration: " . $e->getMessage());
                    $errors[] = ($e->getCode() == '23000')
                        ? 'ชื่อผู้ใช้หรืออีเมลนี้มีอยู่ในระบบแล้ว'
                        : 'เกิดข้อผิดพลาดในการลงทะเบียน กรุณาลองใหม่อีกครั้ง';
                }
            }
        }
    }
}

$page_title = "ลงทะเบียน";
include 'includes/header.php';
?>

<style>
.au-wrap { max-width:640px; margin:40px auto; }
.au-card { background:#fff; border:1px solid #e3e8ee; border-radius:18px; box-shadow:0 6px 24px rgba(18,52,86,.10); overflow:hidden; }
.au-head { padding:26px 28px 20px; background:#003399; color:#fff; }
.au-head .ic { width:48px; height:48px; border-radius:14px; background:rgba(255,255,255,.18); display:flex; align-items:center; justify-content:center; font-size:1.3rem; margin-bottom:12px; }
.au-head h1 { font-size:1.45rem; font-weight:600; margin:0; }
.au-head p { margin:4px 0 0; opacity:.85; font-size:.92rem; }
.au-body { padding:26px 28px 8px; }
.au-foot { padding:14px 28px 22px; text-align:center; font-size:.92rem; color:#667587; }
.au-foot a { text-decoration:none; }
.au-body .form-label { font-weight:500; }
.au-body .form-control { padding:.6rem .8rem; }
.au-hp { position:absolute; left:-9999px; width:1px; height:1px; overflow:hidden; }
.au-note { font-size:.84rem; color:#667587; margin-top:4px; }
.au-success { text-align:center; padding:10px 0 22px; }
.au-success .ok { width:64px; height:64px; margin:0 auto 14px; border-radius:50%; background:#dcf2e5; color:#14613a; display:flex; align-items:center; justify-content:center; font-size:1.8rem; }
</style>

<div class="au-wrap px-3">
    <div class="au-card">
        <div class="au-head">
            <div class="ic"><i class="fas fa-user-plus"></i></div>
            <h1>สร้างบัญชีใหม่</h1>
            <p>ผู้ดูแลระบบจะตรวจสอบและอนุมัติบัญชีก่อนเข้าใช้งาน</p>
        </div>
        <div class="au-body">
            <?php if ($success): ?>
                <div class="au-success">
                    <div class="ok"><i class="fas fa-check"></i></div>
                    <h2 class="h5">ลงทะเบียนสำเร็จ</h2>
                    <p class="text-muted mb-3">บัญชีของคุณถูกสร้างแล้ว กรุณารอผู้ดูแลระบบอนุมัติเพื่อเข้าใช้งาน ประมาณ 3 วันทำการ</p>
                    <a href="login.php" class="btn btn-primary">กลับไปหน้าเข้าสู่ระบบ</a>
                </div>
            <?php else: ?>
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?><li><?php echo htmlspecialchars($err); ?></li><?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="POST" action="register.php" autocomplete="on">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(function_exists('csrf_token') ? csrf_token() : ''); ?>">
                    <div class="au-hp" aria-hidden="true">
                        <label>เว็บไซต์ (ห้ามกรอก)<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
                    </div>

                    <div class="mb-3">
                        <label for="full_name" class="form-label">ชื่อ-สกุล <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="full_name" name="full_name" maxlength="255" autocomplete="name" required value="<?php echo htmlspecialchars($old['full_name']); ?>">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">ชื่อผู้ใช้ <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="username" name="username" maxlength="50" autocomplete="username" required value="<?php echo htmlspecialchars($old['username']); ?>">
                            <div class="au-note">3-50 ตัวอักษร ไม่มีช่องว่าง</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">อีเมล <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email" maxlength="255" autocomplete="email" required value="<?php echo htmlspecialchars($old['email']); ?>">
                            <?php if (!empty($allowed_email_domains)): ?><div class="au-note">ใช้อีเมลของหน่วยงาน</div><?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">รหัสผ่าน <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required>
                            <div class="au-note">อย่างน้อย 8 ตัวอักษร</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="confirm_password" class="form-label">ยืนยันรหัสผ่าน <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="8" maxlength="72" autocomplete="new-password" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="department" class="form-label">ส่วนงาน/ภาควิชา <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="department" name="department" maxlength="255" list="deptList" required value="<?php echo htmlspecialchars($old['department']); ?>">
                        <datalist id="deptList">
                            <?php foreach ($departments as $d): ?><option value="<?php echo htmlspecialchars($d); ?>"><?php endforeach; ?>
                        </datalist>
                        <div class="au-note">เลือกจากรายการที่แนะนำถ้ามี เพื่อให้ชื่อส่วนงานตรงกัน</div>
                    </div>
                    <div class="mb-4 form-check">
                        <input type="checkbox" class="form-check-input" id="terms" name="terms" required <?php echo isset($_POST['terms']) ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="terms">ฉันยอมรับ<a href="terms_and_conditions.php" target="_blank" rel="noopener">ข้อกำหนดและเงื่อนไข</a></label>
                    </div>
                    <div class="d-grid mb-3">
                        <button type="submit" class="btn btn-primary btn-lg">ลงทะเบียน</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
        <div class="au-foot">
            <a href="index.php"><i class="fas fa-home me-1"></i>กลับหน้าปฏิทิน</a>
            <hr class="my-3">
            มีบัญชีอยู่แล้ว? <a href="login.php">เข้าสู่ระบบที่นี่</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
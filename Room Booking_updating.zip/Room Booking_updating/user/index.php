<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Bangkok');
include_once '../includes/db.php';
include_once '../includes/functions.php';

// Require user to be logged in
if (!is_logged_in()) {
    header('Location: ../login.php');
    exit();
}

$page_title = "แดชบอร์ดของฉัน";
include '../includes/header.php'; // Use header from root includes

$user_id = $_SESSION['user_id'];

// Fetch bookings for the current user
$stmt = $pdo->prepare("SELECT b.*, r.name as room_name FROM bookings b JOIN rooms r ON b.room_id = r.id WHERE b.user_id = ? AND b.is_deleted = 0 ORDER BY b.start_time DESC");
$stmt->execute([$user_id]);
$my_bookings = $stmt->fetchAll();

// ห้องสำหรับ dropdown ในหน้าต่างแก้ไข
$rooms = $pdo->query("SELECT id, name FROM rooms ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$is_staff = can_manage_bookings();
$min_date_for_user = $is_staff ? date('Y-m-d') : date('Y-m-d', strtotime('+7 days'));
$now_ts = time();
?>

<div class="container my-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">แดชบอร์ดของฉัน</h2>
            <p class="text-muted mb-0">ยินดีต้อนรับ, <strong><?php echo htmlspecialchars($_SESSION['user_fullname']); ?></strong></p>
        </div>
        <a href="profile.php" class="btn btn-outline-primary">
            <i class="fas fa-user-edit me-1"></i> แก้ไขข้อมูลส่วนตัว
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-list-alt me-2"></i>รายการจองของฉัน</h5>
            <div>
                <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-calendar-alt me-2"></i>กลับหน้าปฏิทิน</a>
                <a href="../booking-form.php" class="btn btn-primary btn-sm"><i class="fas fa-plus me-2"></i>จองห้องเพิ่ม</a>
            </div>
        </div>
        <div class="card-body">
            <p class="text-muted small mb-3">
                <i class="fas fa-info-circle me-1"></i>คุณสามารถแก้ไขหรือลบรายการได้ก่อนที่เจ้าหน้าที่จะอนุมัติ (สถานะ "รออนุมัติ")
            </p>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>หัวข้อ</th>
                            <th>ห้อง</th>
                            <th>วัน-เวลาที่จอง</th>
                            <th>สถานะ</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody id="myBookingsTable">
                        <?php if (empty($my_bookings)): ?>
                            <tr><td colspan="5" class="text-center py-4">คุณยังไม่มีรายการจอง</td></tr>
                        <?php else: ?>
                            <?php foreach ($my_bookings as $booking): ?>
                                <?php
                                    $start_ts   = strtotime($booking['start_time']);
                                    $is_pending = ($booking['status'] == 'pending');
                                    $can_edit   = $is_pending && $start_ts > $now_ts;
                                    $payload = [
                                        'id'              => (int)$booking['id'],
                                        'room_id'         => (int)$booking['room_id'],
                                        'title'           => $booking['title'],
                                        'instructor_name' => $booking['instructor_name'],
                                        'student_count'   => $booking['student_count'],
                                        'doc_number'      => $booking['doc_number'],
                                        'contact_person'  => $booking['contact_person'],
                                        'contact_phone'   => $booking['contact_phone'],
                                        'description'     => $booking['description'],
                                        'date'            => date('Y-m-d', $start_ts),
                                        'start'           => date('H:i', $start_ts),
                                        'end'             => date('H:i', strtotime($booking['end_time'])),
                                        'in_series'       => !empty($booking['event_group_id']),
                                    ];
                                ?>
                                <tr id="booking-row-<?php echo (int)$booking['id']; ?>">
                                    <td><?php echo htmlspecialchars($booking['title']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['room_name']); ?></td>
                                    <td><?php echo date('d M Y, H:i', $start_ts); ?> - <?php echo date('H:i', strtotime($booking['end_time'])); ?></td>
                                    <td class="status-cell"><?php echo format_status_badge($booking['status']); ?></td>
                                    <td class="action-cell">
                                        <?php if ($is_pending): ?>
                                            <?php if ($can_edit): ?>
                                                <button class="btn btn-sm btn-primary btn-edit"
                                                        data-booking="<?php echo htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'); ?>"
                                                        title="แก้ไขการจอง"><i class="fas fa-edit"></i> แก้ไข</button>
                                            <?php endif; ?>
                                            <button class="btn btn-sm btn-danger btn-delete"
                                                    data-id="<?php echo (int)$booking['id']; ?>"
                                                    data-in-series="<?php echo $payload['in_series'] ? '1' : '0'; ?>"
                                                    title="ลบการจอง"><i class="fas fa-trash-alt"></i> ลบ</button>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal แก้ไขการจอง -->
<div class="modal fade" id="editBookingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <form id="editBookingForm">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>แก้ไขการจอง</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit_id">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">

                    <div id="edit_series_note" class="alert alert-info py-2 small d-none">
                        รายการนี้เป็นส่วนหนึ่งของการจองแบบเกิดซ้ำ การแก้ไขจะมีผลเฉพาะรายการนี้รายการเดียว
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="edit_room_id">ห้อง <span class="text-danger">*</span></label>
                            <select class="form-select" name="room_id" id="edit_room_id" required>
                                <?php foreach ($rooms as $room): ?>
                                    <option value="<?php echo (int)$room['id']; ?>"><?php echo htmlspecialchars($room['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="edit_title">หัวข้อ/รายวิชา <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="title" id="edit_title" maxlength="255" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="edit_instructor_name">อาจารย์ผู้สอน <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="instructor_name" id="edit_instructor_name" maxlength="255" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="edit_student_count">จำนวนนักศึกษา</label>
                            <input type="number" min="0" class="form-control" name="student_count" id="edit_student_count">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="edit_doc_number">เลขที่หนังสือ (ถ้ามี)</label>
                        <input type="text" class="form-control" name="doc_number" id="edit_doc_number" maxlength="100">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="edit_contact_person">ชื่อผู้จอง <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="contact_person" id="edit_contact_person" maxlength="255" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="edit_contact_phone">เบอร์ติดต่อ <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="contact_phone" id="edit_contact_phone" maxlength="50" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="edit_booking_date">วันที่ <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="booking_date" id="edit_booking_date" required>
                            <?php if (!$is_staff): ?>
                                <div class="form-text">ต้องจองล่วงหน้าอย่างน้อย 7 วัน (เมื่อเปลี่ยนวัน/เวลา)</div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="edit_start_time_only">เวลาเริ่มต้น <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" name="start_time_only" id="edit_start_time_only" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label" for="edit_end_time_only">เวลาสิ้นสุด <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" name="end_time_only" id="edit_end_time_only" required>
                        </div>
                    </div>

                    <div class="mb-1">
                        <label class="form-label" for="edit_description">รายละเอียดเพิ่มเติม/หมายเหตุ</label>
                        <textarea class="form-control" name="description" id="edit_description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                    <button type="submit" class="btn btn-primary" id="editSubmitBtn">
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                        บันทึกการแก้ไข
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
$(document).ready(function(){
    const CSRF_TOKEN = <?php echo json_encode(csrf_token()); ?>;
    const MIN_DATE   = <?php echo json_encode($min_date_for_user); ?>;
    const editModal  = bootstrap.Modal.getOrCreateInstance(document.getElementById('editBookingModal'));

    function showError(msg) { Swal.fire('เกิดข้อผิดพลาด!', msg, 'error'); }

    // ---------- เปิดหน้าต่างแก้ไข ----------
    $('#myBookingsTable').on('click', '.btn-edit', function() {
        const b = $(this).data('booking');
        $('#edit_id').val(b.id);
        $('#edit_room_id').val(b.room_id);
        $('#edit_title').val(b.title);
        $('#edit_instructor_name').val(b.instructor_name || '');
        $('#edit_student_count').val(b.student_count === null ? '' : b.student_count);
        $('#edit_doc_number').val(b.doc_number || '');
        $('#edit_contact_person').val(b.contact_person);
        $('#edit_contact_phone').val(b.contact_phone);
        $('#edit_booking_date').val(b.date);
        $('#edit_start_time_only').val(b.start);
        $('#edit_end_time_only').val(b.end);
        $('#edit_description').val(b.description || '');
        // ถ้าวันเดิมใกล้กว่า 7 วัน ให้ยังบันทึกข้อมูลอื่นได้ (เซิร์ฟเวอร์ตรวจกติกาซ้ำอยู่แล้ว)
        $('#edit_booking_date').attr('min', b.date < MIN_DATE ? b.date : MIN_DATE);
        $('#edit_series_note').toggleClass('d-none', !b.in_series);
        editModal.show();
    });

    // ---------- บันทึกการแก้ไข ----------
    $('#editBookingForm').on('submit', function(e) {
        e.preventDefault();
        if ($('#edit_end_time_only').val() <= $('#edit_start_time_only').val()) {
            showError('เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น');
            return;
        }
        const btn = $('#editSubmitBtn');
        btn.prop('disabled', true).find('.spinner-border').removeClass('d-none');

        $.ajax({
            url: '../api/update_booking.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    editModal.hide();
                    Swal.fire({ icon: 'success', title: 'สำเร็จ', text: response.message, timer: 1500, showConfirmButton: false })
                        .then(() => window.location.reload());
                } else {
                    showError(response.message);
                }
            },
            error: function() { showError('ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้'); },
            complete: function() { btn.prop('disabled', false).find('.spinner-border').addClass('d-none'); }
        });
    });

    // ---------- ลบการจอง ----------
    $('#myBookingsTable').on('click', '.btn-delete', function() {
        const bookingId = $(this).data('id');
        const inSeries  = String($(this).data('in-series')) === '1';

        const options = inSeries ? {
            title: 'ลบรายการจอง',
            text: 'รายการนี้เป็นการจองแบบเกิดซ้ำ ต้องการลบอย่างไร?',
            icon: 'warning',
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: 'ลบเฉพาะรายการนี้',
            denyButtonText: 'ลบทั้งชุด (ที่ยังรออนุมัติ)',
            cancelButtonText: 'ไม่ลบ',
            confirmButtonColor: '#d33',
            denyButtonColor: '#b02a37'
        } : {
            title: 'ยืนยันการลบ',
            text: 'คุณต้องการลบรายการจองนี้ใช่หรือไม่?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'ใช่, ลบเลย',
            cancelButtonText: 'ไม่'
        };

        Swal.fire(options).then((result) => {
            if (!result.isConfirmed && !result.isDenied) { return; }
            const scope = result.isDenied ? 'series' : 'single';

            $.ajax({
                url: '../api/update_booking_status.php',
                type: 'POST',
                data: { id: bookingId, action: 'delete_own', scope: scope, csrf_token: CSRF_TOKEN },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({ icon: 'success', title: 'สำเร็จ', text: response.message, timer: 1500, showConfirmButton: false });
                        (response.deleted_ids || [bookingId]).forEach(function(id) {
                            $('#booking-row-' + id).fadeOut(300, function() { $(this).remove(); });
                        });
                    } else {
                        showError(response.message);
                    }
                },
                error: function() { showError('ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้'); }
            });
        });
    });
});
</script>

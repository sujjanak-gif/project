<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../includes/db.php';
include_once '../includes/functions.php';

if (!is_logged_in()) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$alert_script = ""; 

// สร้างสคริปต์แจ้งเตือน (escape ด้วย json_encode กันข้อความแทรกเข้าไปในสคริปต์)
function profile_alert($title, $text, $icon) {
    $f = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE;
    return 'Swal.fire(' . json_encode($title, $f) . ', ' . json_encode($text, $f) . ', ' . json_encode($icon, $f) . ');';
}
function profile_post($key, $max) {
    $v = isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : '';
    return function_exists('mb_substr') ? mb_substr($v, 0, $max) : substr($v, 0, $max);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = profile_post('full_name', 255);
    $email = profile_post('email', 255);
    $current_password = isset($_POST['current_password']) && is_string($_POST['current_password']) ? $_POST['current_password'] : '';
    $new_password = isset($_POST['new_password']) && is_string($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm_password = isset($_POST['confirm_password']) && is_string($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    $me = $pdo->prepare("SELECT email, password FROM users WHERE id = ?");
    $me->execute([$user_id]);
    $me = $me->fetch();

    $changing_email = ($me && strcasecmp($email, $me['email']) !== 0);
    $changing_password = ($new_password !== '');

    if (function_exists('csrf_verify') && !csrf_verify($_POST['csrf_token'] ?? null)) {
        $alert_script = profile_alert('หน้านี้หมดอายุ', 'กรุณารีเฟรชหน้าแล้วลองใหม่อีกครั้ง', 'warning');
    } elseif ($full_name === '' || $email === '') {
        $alert_script = profile_alert('แจ้งเตือน', 'กรุณากรอกชื่อและอีเมล', 'warning');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $alert_script = profile_alert('แจ้งเตือน', 'รูปแบบอีเมลไม่ถูกต้อง', 'warning');
    } elseif (($changing_email || $changing_password) && !($me && password_verify($current_password, $me['password']))) {
        // การเปลี่ยนอีเมลหรือรหัสผ่านต้องยืนยันด้วยรหัสผ่านปัจจุบันเสมอ
        $alert_script = profile_alert('ยืนยันตัวตนไม่สำเร็จ', 'กรุณากรอกรหัสผ่านปัจจุบันให้ถูกต้อง เมื่อต้องการเปลี่ยนอีเมลหรือรหัสผ่าน', 'error');
    } elseif ($changing_password && $new_password !== $confirm_password) {
        $alert_script = profile_alert('ผิดพลาด', 'รหัสผ่านใหม่ไม่ตรงกัน', 'error');
    } elseif ($changing_password && (strlen($new_password) < 8 || strlen($new_password) > 72)) {
        $alert_script = profile_alert('ผิดพลาด', 'รหัสผ่านใหม่ต้องยาว 8-72 ตัวอักษร', 'error');
    } else {
        try {
            if ($changing_password) {
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, password = ? WHERE id = ?");
                $stmt->execute([$full_name, $email, password_hash($new_password, PASSWORD_DEFAULT), $user_id]);
                session_regenerate_id(true); // เปลี่ยนรหัสผ่านแล้วออก session id ใหม่
            } else {
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?");
                $stmt->execute([$full_name, $email, $user_id]);
            }
            $_SESSION['user_fullname'] = $full_name;

            $alert_script = "
                Swal.fire({
                    title: 'บันทึกสำเร็จ!',
                    text: 'ทำการเปลี่ยนแปลงข้อมูลเรียบร้อยแล้ว',
                    icon: 'success',
                    confirmButtonText: 'ตกลง',
                    confirmButtonColor: '#28a745'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'profile.php';
                    }
                });
            ";
        } catch (PDOException $e) {
            error_log('profile update error: ' . $e->getMessage());
            if ($e->getCode() == 23000) {
                $alert_script = profile_alert('ข้อมูลซ้ำ', 'อีเมลนี้มีผู้ใช้งานแล้ว', 'error');
            } else {
                $alert_script = profile_alert('เกิดข้อผิดพลาด', 'บันทึกข้อมูลไม่สำเร็จ กรุณาลองใหม่อีกครั้ง', 'error');
            }
        }
    }
}

$stmt = $pdo->prepare("SELECT username, full_name, email, role, department FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$page_title = "แก้ไขข้อมูลส่วนตัว";
include '../includes/header.php'; 
?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-user-cog me-2"></i>แก้ไขข้อมูลส่วนตัว</h5>
                </div>
                <div class="card-body p-4">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(function_exists('csrf_token') ? csrf_token() : ''); ?>">
                        
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label text-muted">Username</label>
                                <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label text-muted">สิทธิ์</label>
                                <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars(strtoupper($user['role'])); ?>" readonly>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label text-muted">แผนก</label>
                                <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($user['department']); ?>" readonly>
                            </div>
                        </div>

                        <hr class="my-4">

                        <div class="mb-3">
                            <label for="full_name" class="form-label">ชื่อ-นามสกุล <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="full_name" id="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">อีเมล <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>

                        <hr class="my-4">
                        <h6 class="text-secondary"><i class="fas fa-key me-2"></i>เปลี่ยนรหัสผ่าน</h6>

                        <div class="mb-3">
                            <label for="current_password" class="form-label">รหัสผ่านปัจจุบัน</label>
                            <input type="password" class="form-control" name="current_password" id="current_password" autocomplete="current-password" placeholder="จำเป็นเมื่อเปลี่ยนอีเมลหรือรหัสผ่าน">
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="new_password" class="form-label">รหัสผ่านใหม่</label>
                                <input type="password" class="form-control" name="new_password" id="new_password" minlength="8" maxlength="72" autocomplete="new-password" placeholder="เว้นว่างไว้ถ้าไม่เปลี่ยน (อย่างน้อย 8 ตัวอักษร)">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="confirm_password" class="form-label">ยืนยันรหัสผ่านใหม่</label>
                                <input type="password" class="form-control" name="confirm_password" id="confirm_password" maxlength="72" autocomplete="new-password" placeholder="ยืนยันรหัสผ่านใหม่">
                            </div>
                        </div>

                        <div class="d-flex justify-content-between mt-3">
                            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>กลับหน้าหลัก</a>
                            <button type="submit" class="btn btn-success"><i class="fas fa-save me-2"></i>บันทึกการเปลี่ยนแปลง</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($alert_script)): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                <?php echo $alert_script; ?>
            }, 100);
        });
    </script>
<?php endif; ?>
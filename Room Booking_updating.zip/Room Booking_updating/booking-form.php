<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
date_default_timezone_set('Asia/Bangkok');
include_once 'includes/db.php';
include_once 'includes/functions.php';

if (!is_logged_in()) {
    header('Location: login.php');
    exit();
}

// ห้อง (สีใช้ตามที่ตั้งไว้ในระบบ ถ้าไม่มีให้ใช้สีสำรอง)
$palette = ['#2f6fd6', '#d9534f', '#7a4bd1', '#0f9d8a', '#e07b00', '#c2185b'];
$rooms = $pdo->query("SELECT id, name, color FROM rooms ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$rooms_js = [];
foreach ($rooms as $i => $r) {
    $rooms_js[(int)$r['id']] = [
        'name' => $r['name'],
        'color' => preg_match('/^#[0-9a-fA-F]{6}$/', (string)$r['color']) ? $r['color'] : $palette[$i % count($palette)],
    ];
}

$user_stmt = $pdo->prepare("SELECT full_name, department FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$current_user = $user_stmt->fetch(PDO::FETCH_ASSOC) ?: ['full_name' => '', 'department' => ''];

// กติกาเดียวกับฝั่งเซิร์ฟเวอร์: ผู้ใช้ทั่วไปต้องจองล่วงหน้า 7 วัน ผู้ดูแล/เจ้าหน้าที่จองได้ตั้งแต่วันนี้
$is_staff = can_manage_bookings();
$advance_days = $is_staff ? 0 : 7;
$min_date = date('Y-m-d', strtotime('+' . $advance_days . ' days'));

// วันที่ที่ส่งมาจากปฏิทิน (?date=YYYY-MM-DD)
$prefill_date = '';
$prefill_too_early = false;
if (isset($_GET['date']) && is_string($_GET['date']) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $_GET['date'], $mm) && checkdate((int)$mm[2], (int)$mm[3], (int)$mm[1])) {
    if ($_GET['date'] >= $min_date) { $prefill_date = $_GET['date']; } else { $prefill_too_early = true; }
}

$page_title = "แบบฟอร์มการจองห้อง";
include 'includes/header.php';
?>

<style>
.bf-page { --ink:#1c2733; --muted:#667587; --line:#e3e8ee; --brand:#003399; color:var(--ink); }
.bf-hero h1 { font-size:1.6rem; font-weight:500; margin:0; }
.bf-hero p { color:var(--muted); margin:2px 0 14px; }
.bf-card { background:#fff; border:1px solid var(--line); border-radius:16px; padding:20px 22px; margin-bottom:18px; box-shadow:0 1px 3px rgba(18,52,86,.06); }
.bf-step { display:flex; align-items:center; gap:12px; margin-bottom:16px; }
.bf-step .n { flex:none; width:32px; height:32px; border-radius:50%; background:var(--brand); color:#fff; display:flex; align-items:center; justify-content:center; font-weight:600; }
.bf-step h2 { font-size:1.1rem; font-weight:500; margin:0; }
.bf-step small { display:block; color:var(--muted); font-weight:400; font-size:.84rem; }
.bf-page .form-label { font-weight:500; margin-bottom:4px; }
.bf-seg { display:flex; flex-wrap:wrap; gap:8px; }
.bf-seg input { position:absolute; opacity:0; pointer-events:none; }
.bf-seg label { padding:8px 18px; border:1px solid #cfd9e8; border-radius:999px; background:#f3f6fb; cursor:pointer; font-weight:500; }
.bf-seg input:checked + label { background:var(--brand); border-color:var(--brand); color:#fff; }
.bf-seg input:focus-visible + label { outline:2px solid var(--brand); outline-offset:2px; }
.bf-wd { display:flex; flex-wrap:wrap; gap:6px; }
.bf-wd input { position:absolute; opacity:0; pointer-events:none; }
.bf-wd label { width:46px; height:42px; display:flex; align-items:center; justify-content:center; border:1px solid #cfd9e8; border-radius:12px; background:#fff; cursor:pointer; font-weight:500; }
.bf-wd input:checked + label { background:#e3ecfb; border-color:var(--brand); color:var(--brand); box-shadow:0 0 0 1px var(--brand); }
.bf-wd input:focus-visible + label { outline:2px solid var(--brand); outline-offset:2px; }
.bf-preview { margin-top:14px; padding:12px 14px; background:#f6f8fb; border:1px solid var(--line); border-radius:12px; font-size:.92rem; }
.bf-preview.is-bad { background:#fdeaec; border-color:#f3b9c0; color:#9a1b30; }
.bf-dates { display:flex; flex-wrap:wrap; gap:6px; margin-top:8px; }
.bf-date-chip { padding:2px 10px; border-radius:999px; background:#fff; border:1px solid #d6dde6; font-size:.82rem; }
.bf-warn { margin-top:10px; padding:10px 14px; border-radius:12px; font-size:.9rem; }
.bf-warn.danger { background:#fdeaec; border:1px solid #f3b9c0; color:#9a1b30; }
.bf-warn.soft { background:#fff6dc; border:1px solid #f1d78a; color:#7a5200; }
.bf-warn.ok { background:#e6f6ec; border:1px solid #a9d9bb; color:#14613a; }
.bf-side { position:sticky; top:16px; }
.bf-sum { list-style:none; margin:0; padding:0; font-size:.94rem; }
.bf-sum li { display:flex; gap:10px; padding:8px 0; border-bottom:1px solid #eef1f5; }
.bf-sum li:last-child { border-bottom:0; }
.bf-sum .k { flex:0 0 74px; color:var(--muted); }
.bf-sum .v { min-width:0; overflow-wrap:anywhere; font-weight:500; }
.bf-sum .v.empty { color:#9aa7b6; font-weight:400; }
.bf-dot { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:6px; }
.bf-day { list-style:none; margin:0; padding:0; }
.bf-day li { padding:8px 10px; margin-bottom:6px; border:1px solid var(--line); border-left:4px solid var(--c, #9aa7b6); font-size:.88rem; }
.bf-day li.hit { background:#fdeaec; border-color:#f3b9c0; border-left-color:#d33a4e; }
.bf-day .t { font-weight:600; font-variant-numeric:tabular-nums; }
.bf-day .s { float:right; font-size:.76rem; color:var(--muted); }
.bf-muted { color:var(--muted); font-size:.88rem; }
.bf-actions { display:flex; justify-content:flex-end; gap:8px; flex-wrap:wrap; }
@media (max-width: 991.98px) { .bf-side { position:static; } }
@media (prefers-reduced-motion: reduce) { .bf-page * { transition:none !important; } }
</style>

<div class="container my-4 bf-page">
    <div class="bf-hero">
        <h1><i class="fas fa-calendar-plus me-2"></i>สร้างรายการจองใหม่</h1>
        <p>กรอกข้อมูลให้ครบ ระบบจะส่งคำขอให้เจ้าหน้าที่พิจารณา และแจ้งผลทางอีเมล</p>
    </div>

    <?php if ($prefill_too_early): ?>
        <div class="alert alert-warning">วันที่ที่เลือกจากปฏิทินยังจองไม่ได้ ผู้ใช้ทั่วไปต้องจองล่วงหน้าอย่างน้อย <?php echo (int)$advance_days; ?> วัน กรุณาเลือกวันที่ใหม่</div>
    <?php endif; ?>

    <form id="bookingForm" autocomplete="off">
        <div class="row g-4">
            <div class="col-lg-8">

                <section class="bf-card">
                    <div class="bf-step"><span class="n">1</span><h2>ห้องและกิจกรรม</h2></div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="room_id" class="form-label">เลือกห้อง <span class="text-danger">*</span></label>
                            <select class="form-select" id="room_id" name="room_id" required>
                                <option value="">-- กรุณาเลือกห้อง --</option>
                                <?php foreach ($rooms as $room): ?>
                                    <option value="<?php echo (int)$room['id']; ?>"><?php echo htmlspecialchars($room['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="title" class="form-label">หัวข้อ/รายวิชา <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title" maxlength="255" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="instructor_name" class="form-label">อาจารย์ผู้สอน <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="instructor_name" name="instructor_name" maxlength="255" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="student_count" class="form-label">จำนวนนักศึกษา</label>
                            <input type="number" min="0" class="form-control" id="student_count" name="student_count">
                        </div>
                    </div>
                    <div class="mb-1">
                        <label for="doc_number" class="form-label">เลขที่หนังสือ (ถ้ามี)</label>
                        <input type="text" class="form-control" id="doc_number" name="doc_number" maxlength="100">
                    </div>
                </section>

                <section class="bf-card">
                    <div class="bf-step">
                        <span class="n">2</span>
                        <h2>วันและเวลา
                            <small><?php echo $is_staff ? 'เลือกจองได้ตั้งแต่วันนี้' : 'จองล่วงหน้าก่อนวันใช้งานอย่างน้อย 7 วัน (เริ่มได้ตั้งแต่ ' . htmlspecialchars(date('d/m/', strtotime($min_date)) . (date('Y', strtotime($min_date)) + 543)) . ')'; ?></small>
                        </h2>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="booking_date" class="form-label">วันที่ <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="booking_date" name="booking_date" min="<?php echo htmlspecialchars($min_date); ?>" value="<?php echo htmlspecialchars($prefill_date); ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="start_time_only" class="form-label">เวลาเริ่มต้น <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="start_time_only" name="start_time_only" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="end_time_only" class="form-label">เวลาสิ้นสุด <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="end_time_only" name="end_time_only" required>
                        </div>
                    </div>
                    <div id="timeWarn" aria-live="polite"></div>
                </section>

                <section class="bf-card">
                    <div class="bf-step"><span class="n">3</span><h2>การเกิดซ้ำ <small>ใช้เมื่อต้องการจองห้องเดิม เวลาเดิม ต่อเนื่องหลายครั้ง (สูงสุด 120 ครั้ง)</small></h2></div>
                    <div class="bf-seg mb-3" role="radiogroup" aria-label="รูปแบบการเกิดซ้ำ">
                        <input type="radio" name="rec_type" id="rec_none" value="none" checked><label for="rec_none">ไม่เกิดซ้ำ</label>
                        <input type="radio" name="rec_type" id="rec_daily" value="daily"><label for="rec_daily">รายวัน</label>
                        <input type="radio" name="rec_type" id="rec_weekly" value="weekly"><label for="rec_weekly">รายสัปดาห์</label>
                        <input type="radio" name="rec_type" id="rec_monthly" value="monthly"><label for="rec_monthly">รายเดือน</label>
                    </div>

                    <div id="recOptions" style="display:none">
                        <div id="weeklyBox" class="mb-3" style="display:none">
                            <div class="form-label">ทุกสัปดาห์ในวัน</div>
                            <div class="bf-wd" role="group" aria-label="วันในสัปดาห์">
                                <?php foreach ([1 => 'จ.', 2 => 'อ.', 3 => 'พ.', 4 => 'พฤ.', 5 => 'ศ.', 6 => 'ส.', 0 => 'อา.'] as $v => $lab): ?>
                                    <input type="checkbox" class="rec-wd" id="wd<?php echo $v; ?>" value="<?php echo $v; ?>"><label for="wd<?php echo $v; ?>"><?php echo $lab; ?></label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5">
                                <label for="rec_end" class="form-label">สิ้นสุดการเกิดซ้ำในวันที่ <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="rec_end">
                            </div>
                        </div>
                        <div class="bf-muted mt-2" id="monthlyHint" style="display:none">รายเดือนจะจองวันที่เดิมของทุกเดือน ถ้าเดือนนั้นไม่มีวันที่นั้น (เช่น วันที่ 31) จะใช้วันสุดท้ายของเดือน</div>
                    </div>
                    <div class="bf-preview" id="recPreview" style="display:none" aria-live="polite"></div>
                </section>

                <section class="bf-card">
                    <div class="bf-step"><span class="n">4</span><h2>ข้อมูลผู้จอง</h2></div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="contact_person" class="form-label">ชื่อผู้จอง <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="contact_person" name="contact_person" maxlength="255" value="<?php echo htmlspecialchars($current_user['full_name']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="department" class="form-label">ส่วนงาน/ภาควิชา</label>
                            <input type="text" class="form-control bg-light" id="department" name="department" value="<?php echo htmlspecialchars($current_user['department']); ?>" readonly>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="contact_phone" class="form-label">เบอร์ติดต่อ <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="contact_phone" name="contact_phone" maxlength="50" required>
                    </div>
                    <div class="mb-1">
                        <label for="description" class="form-label">รายละเอียดเพิ่มเติม/หมายเหตุ</label>
                        <textarea class="form-control" id="description" name="description" rows="3" maxlength="5000"></textarea>
                    </div>
                </section>

                <div class="bf-actions mb-4">
                    <a href="index.php" class="btn btn-secondary px-4">ยกเลิก</a>
                    <button type="submit" class="btn btn-primary px-4" id="submitBtn">
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                        ส่งคำขอจอง
                    </button>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="bf-side">
                    <section class="bf-card">
                        <div class="bf-step mb-2"><h2><i class="far fa-clipboard me-2"></i>สรุปคำขอ</h2></div>
                        <ul class="bf-sum">
                            <li><span class="k">ห้อง</span><span class="v empty" id="sumRoom">ยังไม่ได้เลือก</span></li>
                            <li><span class="k">วันที่</span><span class="v empty" id="sumDate">ยังไม่ได้เลือก</span></li>
                            <li><span class="k">เวลา</span><span class="v empty" id="sumTime">ยังไม่ได้เลือก</span></li>
                            <li><span class="k">จำนวนครั้ง</span><span class="v" id="sumCount">1 ครั้ง</span></li>
                        </ul>
                    </section>
                    <section class="bf-card">
                        <div class="bf-step mb-2"><h2><i class="far fa-calendar-check me-2"></i>ห้องว่างหรือไม่</h2></div>
                        <div class="bf-muted mb-2" id="dayHead">เลือกห้องและวันที่เพื่อดูรายการที่มีผู้จองแล้ว</div>
                        <ul class="bf-day" id="dayList"></ul>
                    </section>
                </div>
            </div>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>

<script>
$(function () {
    const IS_STAFF = <?php echo $is_staff ? 'true' : 'false'; ?>;
    const ADVANCE_DAYS = <?php echo (int)$advance_days; ?>;
    const MAX_OCC = 120;
    const CSRF = <?php echo json_encode(function_exists('csrf_token') ? csrf_token() : ''); ?>;
    const ROOMS = <?php echo json_encode($rooms_js, JSON_UNESCAPED_UNICODE); ?>;

    const MONTHS = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
    const MONTHS_S = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    const DOW_FULL = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
    const DOW_S = ['อา.', 'จ.', 'อ.', 'พ.', 'พฤ.', 'ศ.', 'ส.'];
    const pad = n => String(n).padStart(2, '0');
    const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
    const be = y => y + 543;
    const dateLong = d => 'วัน' + DOW_FULL[d.getDay()] + 'ที่ ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + be(d.getFullYear());
    const dateChip = d => DOW_S[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS_S[d.getMonth()] + ' ' + String(be(d.getFullYear())).slice(-2);
    const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const parseDay = s => new Date(s + 'T00:00:00');
    const parseLocal = s => new Date(String(s).replace(' ', 'T'));

    let dayEvents = [];      // การจองของห้อง/วันที่เลือก (ใช้ตรวจเวลาชน)
    let availToken = 0;

    const recType = () => $('input[name="rec_type"]:checked').val();
    const weekdays = () => $('.rec-wd:checked').map(function () { return parseInt(this.value, 10); }).get();

    /* ---------- สร้างรายการวันที่ตามการเกิดซ้ำ (ตรงกับกติกาฝั่งเซิร์ฟเวอร์) ---------- */
    function buildDates() {
        const d = $('#booking_date').val();
        if (!d) { return []; }
        const start = parseDay(d);
        const type = recType();
        if (type === 'none') { return [start]; }
        const endStr = $('#rec_end').val();
        if (!endStr) { return []; }
        const end = new Date(endStr + 'T23:59:59');
        const out = [];
        if (type === 'daily' || type === 'weekly') {
            const wd = weekdays();
            if (type === 'weekly' && wd.length === 0) { return []; }
            const cur = new Date(start);
            while (cur <= end && out.length <= MAX_OCC) {
                if (type === 'daily' || wd.indexOf(cur.getDay()) >= 0) { out.push(new Date(cur)); }
                cur.setDate(cur.getDate() + 1);
            }
        } else {
            const dom = start.getDate();
            for (let i = 0; i <= MAX_OCC; i++) {
                const first = new Date(start.getFullYear(), start.getMonth() + i, 1);
                const dim = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
                const dd = new Date(first.getFullYear(), first.getMonth(), Math.min(dom, dim));
                if (dd > end) { break; }
                out.push(dd);
            }
        }
        return out;
    }

    function renderRecurrence() {
        const type = recType();
        $('#recOptions').toggle(type !== 'none');
        $('#weeklyBox').toggle(type === 'weekly');
        $('#monthlyHint').toggle(type === 'monthly');
        const $p = $('#recPreview');
        if (type === 'none') { $p.hide(); return 1; }
        $p.show().removeClass('is-bad');
        if (!$('#booking_date').val()) { $p.html('เลือกวันที่เริ่มในขั้นตอนที่ 2 ก่อน'); return 0; }
        if (type === 'weekly' && weekdays().length === 0) { $p.html('เลือกวันในสัปดาห์อย่างน้อย 1 วัน'); return 0; }
        if (!$('#rec_end').val()) { $p.html('เลือกวันที่สิ้นสุดการเกิดซ้ำ'); return 0; }
        const dates = buildDates();
        if (dates.length === 0) { $p.addClass('is-bad').html('ไม่พบวันที่ตรงตามเงื่อนไขในช่วงที่เลือก'); return 0; }
        if (dates.length > MAX_OCC) { $p.addClass('is-bad').html('เกิน ' + MAX_OCC + ' ครั้ง กรุณาลดช่วงวันที่หรือแบ่งเป็นหลายคำขอ'); return dates.length; }
        const show = dates.slice(0, 6).map(d => '<span class="bf-date-chip">' + esc(dateChip(d)) + '</span>').join('');
        const more = dates.length > 6 ? '<span class="bf-date-chip">…ถึง ' + esc(dateChip(dates[dates.length - 1])) + '</span>' : '';
        $p.html('จะสร้างคำขอทั้งหมด <strong>' + dates.length + ' ครั้ง</strong><div class="bf-dates">' + show + more + '</div>');
        return dates.length;
    }

    /* ---------- สรุปคำขอด้านขวา ---------- */
    function renderSummary(count) {
        const room = ROOMS[$('#room_id').val()];
        const set = (id, html, empty) => { $(id).html(html).toggleClass('empty', !!empty); };
        if (room) { set('#sumRoom', '<span class="bf-dot" style="background:' + esc(room.color) + '"></span>' + esc(room.name), false); }
        else { set('#sumRoom', 'ยังไม่ได้เลือก', true); }
        const d = $('#booking_date').val();
        if (d) { set('#sumDate', esc(dateLong(parseDay(d))), false); } else { set('#sumDate', 'ยังไม่ได้เลือก', true); }
        const s = $('#start_time_only').val(), e = $('#end_time_only').val();
        if (s && e) { set('#sumTime', esc(s + ' - ' + e + ' น.'), false); } else { set('#sumTime', 'ยังไม่ได้เลือก', true); }
        $('#sumCount').text((count || 1) + ' ครั้ง');
    }

    /* ---------- ตรวจเวลาชนกับรายการที่มีอยู่ของวันแรก ---------- */
    function overlapInfo() {
        const d = $('#booking_date').val(), s = $('#start_time_only').val(), e = $('#end_time_only').val();
        if (!d || !s || !e || e <= s) { return { hard: [], soft: [] }; }
        const a = new Date(d + 'T' + s), b = new Date(d + 'T' + e);
        const hard = [], soft = [];
        dayEvents.forEach(function (ev) {
            if (ev.start < b && ev.end > a) { (ev.status === 'approved' ? hard : soft).push(ev); }
        });
        return { hard: hard, soft: soft };
    }

    function renderTimeWarn() {
        const s = $('#start_time_only').val(), e = $('#end_time_only').val();
        const box = $('#timeWarn').empty();
        if (s && e && e <= s) { box.html('<div class="bf-warn danger">เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น</div>'); return; }
        if (!$('#room_id').val() || !$('#booking_date').val() || !s || !e) { return; }
        const o = overlapInfo();
        if (o.hard.length) {
            box.html('<div class="bf-warn danger"><i class="fas fa-triangle-exclamation me-1"></i>ช่วงเวลานี้มีผู้จองแล้ว (อนุมัติแล้ว) กรุณาเลือกเวลาอื่น</div>');
        } else if (o.soft.length) {
            box.html('<div class="bf-warn soft"><i class="fas fa-hourglass-half me-1"></i>มีคำขออื่นรออนุมัติในช่วงเวลานี้ คุณยังส่งคำขอได้ แต่เจ้าหน้าที่จะอนุมัติได้เพียงรายการเดียว</div>');
        } else {
            box.html('<div class="bf-warn ok"><i class="fas fa-circle-check me-1"></i>ช่วงเวลานี้ว่าง</div>');
        }
    }

    function renderDayList() {
        const d = $('#booking_date').val(), room = ROOMS[$('#room_id').val()];
        const $list = $('#dayList').empty();
        if (!room || !d) { $('#dayHead').text('เลือกห้องและวันที่เพื่อดูรายการที่มีผู้จองแล้ว'); return; }
        $('#dayHead').text(room.name + ' ' + dateLong(parseDay(d)));
        if (dayEvents.length === 0) { $list.append('<li class="bf-muted" style="border:0;padding:0">ยังไม่มีการจองในวันนี้ ห้องว่างทั้งวัน</li>'); return; }
        const o = overlapInfo();
        dayEvents.forEach(function (ev) {
            const hit = o.hard.indexOf(ev) >= 0 || o.soft.indexOf(ev) >= 0;
            $list.append('<li class="' + (hit ? 'hit' : '') + '" style="--c:' + esc(room.color) + '"><span class="s">' + (ev.status === 'approved' ? 'อนุมัติแล้ว' : 'รออนุมัติ') + '</span><div class="t">' +
                esc(pad(ev.start.getHours()) + ':' + pad(ev.start.getMinutes()) + ' - ' + pad(ev.end.getHours()) + ':' + pad(ev.end.getMinutes())) + '</div><div>' + esc(ev.title) + '</div></li>');
        });
    }

    function loadAvailability() {
        const roomId = $('#room_id').val(), d = $('#booking_date').val();
        const token = ++availToken;
        if (!roomId || !d) { dayEvents = []; renderDayList(); renderTimeWarn(); return; }
        const next = new Date(parseDay(d).getTime() + 86400000);
        $('#dayHead').text('กำลังโหลด…');
        fetch('api/get_events.php?room_id=' + encodeURIComponent(roomId) + '&start=' + d + '&end=' + ymd(next))
            .then(r => r.json())
            .then(function (data) {
                if (token !== availToken) { return; }
                const dayStart = parseDay(d), dayEnd = next;
                dayEvents = (Array.isArray(data) ? data : [])
                    .map(e => ({ title: e.title, status: (e.extendedProps || {}).status, start: parseLocal(e.start), end: e.end ? parseLocal(e.end) : parseLocal(e.start) }))
                    .filter(e => e.start < dayEnd && e.end > dayStart)
                    .sort((a, b) => a.start - b.start);
                renderDayList(); renderTimeWarn();
            })
            .catch(function () {
                if (token !== availToken) { return; }
                dayEvents = [];
                $('#dayHead').text('โหลดรายการของวันนี้ไม่สำเร็จ ระบบจะตรวจอีกครั้งตอนส่งคำขอ');
                $('#dayList').empty();
            });
    }

    function refreshAll() {
        const count = renderRecurrence();
        renderSummary(count);
        renderDayList();
        renderTimeWarn();
    }

    /* ---------- เหตุการณ์ ---------- */
    $('#room_id, #booking_date').on('change', function () {
        $('#rec_end').attr('min', $('#booking_date').val() || '');
        loadAvailability();
        refreshAll();
    });
    $('#start_time_only, #end_time_only').on('input change', refreshAll);
    $('input[name="rec_type"], .rec-wd, #rec_end').on('input change', refreshAll);

    /* ---------- ส่งคำขอ ---------- */
    $('#bookingForm').on('submit', function (e) {
        e.preventDefault();
        const date = $('#booking_date').val(), s = $('#start_time_only').val(), en = $('#end_time_only').val();
        const type = recType();
        const fail = (title, text) => Swal.fire(title, text, 'error');

        if (!IS_STAFF) {
            const today = new Date(); today.setHours(0, 0, 0, 0);
            const min = new Date(today); min.setDate(today.getDate() + ADVANCE_DAYS);
            if (parseDay(date) < min) { return fail('ไม่สามารถจองได้', 'ผู้ใช้งานทั่วไปต้องจองล่วงหน้าอย่างน้อย ' + ADVANCE_DAYS + ' วัน'); }
        }
        if (new Date(date + 'T' + en) <= new Date(date + 'T' + s)) { return fail('เวลาไม่ถูกต้อง', 'เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น'); }
        if (new Date(date + 'T' + s) <= new Date()) { return fail('เวลาไม่ถูกต้อง', 'ไม่สามารถจองเวลาที่ผ่านมาแล้วได้'); }

        if (type !== 'none') {
            if (!$('#rec_end').val()) { return fail('ข้อมูลไม่ครบ', 'กรุณาเลือกวันที่สิ้นสุดการเกิดซ้ำ'); }
            if (type === 'weekly' && weekdays().length === 0) { return fail('ข้อมูลไม่ครบ', 'กรุณาเลือกวันในสัปดาห์ที่ต้องการจองซ้ำ'); }
            const n = buildDates().length;
            if (n === 0) { return fail('ข้อมูลไม่ถูกต้อง', 'ไม่พบวันที่ตรงตามเงื่อนไขการเกิดซ้ำ'); }
            if (n > MAX_OCC) { return fail('จองซ้ำมากเกินไป', 'จองซ้ำได้สูงสุด ' + MAX_OCC + ' ครั้งต่อหนึ่งคำขอ'); }
        }
        if (overlapInfo().hard.length) { return fail('ช่วงเวลาไม่ว่าง', 'ช่วงเวลานี้มีผู้จองแล้ว กรุณาเลือกเวลาอื่น'); }

        const data = {
            csrf_token: CSRF,
            room_id: $('#room_id').val(), title: $('#title').val(), instructor_name: $('#instructor_name').val(),
            student_count: $('#student_count').val(), doc_number: $('#doc_number').val(),
            contact_person: $('#contact_person').val(), department: $('#department').val(),
            contact_phone: $('#contact_phone').val(), description: $('#description').val(),
            start_time: date + 'T' + s, end_time: date + 'T' + en
        };
        if (type !== 'none') {
            data.is_recurring = 1;
            data.recurrence_type = type;
            data.recurrence_end_date = $('#rec_end').val();
            if (type === 'weekly') { data.weekdays = weekdays().join(','); }
        }

        const $btn = $('#submitBtn').attr('disabled', true);
        $btn.find('.spinner-border').removeClass('d-none');
        $.ajax({
            url: 'api/create_booking.php', type: 'POST', data: data, dataType: 'json',
            success: function (res) {
                if (res.success) {
                    Swal.fire({ icon: 'success', title: 'ส่งคำขอสำเร็จ', text: res.message, timer: 2000, showConfirmButton: false })
                        .then(() => { window.location.href = 'index.php'; });
                } else { Swal.fire('ส่งคำขอไม่สำเร็จ', res.message || 'กรุณาลองใหม่อีกครั้ง', 'error'); }
            },
            error: function () { Swal.fire('ส่งคำขอไม่สำเร็จ', 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาลองใหม่อีกครั้ง', 'error'); },
            complete: function () { $btn.attr('disabled', false).find('.spinner-border').addClass('d-none'); }
        });
    });

    $('#rec_end').attr('min', $('#booking_date').val() || '');
    refreshAll();
    if ($('#booking_date').val()) { loadAvailability(); }
});
</script>
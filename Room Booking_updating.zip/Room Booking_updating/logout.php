<?php
// เริ่ม session เพื่อเข้าถึงข้อมูล
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ล้างค่า session ทั้งหมด
$_SESSION = array();

// ทำลาย session
session_destroy();

// ส่งผู้ใช้กลับไปที่หน้า login
header('Location: login.php');
exit();
?>
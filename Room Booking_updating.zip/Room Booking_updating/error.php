<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once 'includes/db.php'; // To ensure session is handled correctly with header
include_once 'includes/functions.php';

$code = $_GET['code'] ?? '404'; // Default to 404 if no code is provided
$messages = [
    '403' => [
        'title' => 'ปฏิเสธการเข้าถึง (Access Denied)',
        'message' => 'ขออภัย คุณไม่มีสิทธิ์ในการเข้าถึงหน้านี้',
        'icon' => 'fa-face-sad-cry'
    ],
    '404' => [
        'title' => 'ไม่พบหน้า (Not Found)',
        'message' => 'ขออภัย ไม่พบหน้าที่คุณกำลังค้นหา',
        'icon' => 'fa-ghost'
    ],
];

$error = $messages[$code] ?? $messages['404'];

$page_title = $code . ' ' . $error['title'];
include 'includes/header.php';
?>

<style>
    .error-page-container {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 70vh;
    }
</style>

<div class="container error-page-container">
    <div class="row justify-content-center">
        <!-- Updated column classes for better width -->
        <div class="col-md-12 col-lg-15 text-center">
            <div class="card shadow-lg border-0">
                <div class="card-body p-5">
                    <i class="fas <?php echo $error['icon']; ?> fa-5x text-danger mb-4"></i>
                    <h1 class="display-1 fw-bold"><?php echo $code; ?></h1>
                    <h2 class="h3 mb-3"><?php echo htmlspecialchars($error['title']); ?></h2>
                    <p class="lead text-muted"><?php echo htmlspecialchars($error['message']); ?></p>
                    <div class="mt-4">
                        <!-- <a href="javascript:history.back()" class="btn btn-secondary me-2"><i class="fas fa-arrow-left me-2"></i>กลับไปหน้าก่อนหน้า</a>--> 
                        <a href="index.php" class="btn btn-primary"><i class="fas fa-home me-2"></i>กลับหน้าหลัก</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include 'includes/footer.php';
?>